class ThisLayerValueNode extends Node {
    constructor() {
        super("This Layer/Value", {
            width: 160,
            headerBgClass: "bg-surface-variant/80",
            headerBorderClass: "border-outline-variant/30",
            headerTextClass: "text-on-surface"
        });

        this.timePort = this.addInput("Time", "1D");
        
        this.timeInputEl = document.createElement("input");
        this.timeInputEl.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-0.5 mt-1 font-mono-label text-mono-label text-on-surface focus:border-secondary focus:outline-none text-[11px] placeholder-on-surface-variant/50";
        this.timeInputEl.type = "text";
        this.timeInputEl.placeholder = "Time (optional)";
        
        const container = document.createElement("div");
        container.className = "pl-4";
        container.appendChild(this.timeInputEl);
        this.timePort.el.appendChild(container);

        this.addOutput("Value", "ANY");
        this.addOutput("Index", "1D");
    }

    onConnectionChanged(port) {
        if (port === this.timePort) {
            if (port.wires.length > 0) {
                this.timeInputEl.classList.add("hidden");
            } else {
                this.timeInputEl.classList.remove("hidden");
            }
        }
    }
}
