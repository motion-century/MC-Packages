/* Bootstrap the ExtendScript runtime before sending owner-bound requests. */
class HostBridge {
    constructor(csInterface) {
        this.csInterface = csInterface;
        this.ready = false;
        this.initializing = false;
        this.waiters = [];
        this.errorPrefix = "EXPRESSION_NODE_HOST_ERROR:";
    }

    evaluate(script, callback) {
        // Return host exceptions without depending on the host's JSON implementation.
        const wrapped = "(function(){try{return eval(" + JSON.stringify(script) +
            ");}catch(e){return " + JSON.stringify(this.errorPrefix) +
            "+String(e)+(e.line ? ' (line '+e.line+')' : '');}})()";
        const receive = result => {
            let error = null;
            if (typeof result !== "string" || !result.trim()) {
                error = "CEP evalScript returned an empty response. Restart After Effects and retry Sync.";
            } else if (result.indexOf(this.errorPrefix) === 0) {
                error = result.slice(this.errorPrefix.length);
            } else if (result === "EvalScript error.") {
                error = "CEP could not evaluate the host script. Restart After Effects and retry Sync.";
            }
            callback(error, result);
        };
        try { this.csInterface.evalScript(wrapped, receive); }
        catch (error) { callback(error.message); }
    }

    initialize(callback) {
        if (this.ready) { callback(null); return; }
        this.waiters.push(callback);
        if (this.initializing) return;
        this.initializing = true;
        const finish = error => {
            this.initializing = false;
            this.ready = !error;
            const waiters = this.waiters.splice(0);
            if (error) console.error("Host bootstrap failed:", error);
            else console.log("Expression Node host bridge ready.");
            waiters.forEach(waiter => waiter(error));
        };
        try {
            const root = this.csInterface.getSystemPath(SystemPath.EXTENSION).replace(/\\/g, "/");
            // evalFile loads JSON and host functions into the shared host engine.
            const script =
                "if(typeof JSON==='undefined'||typeof JSON.parse!=='function'||typeof JSON.stringify!=='function')" +
                "{$.evalFile(" + JSON.stringify(root + "/jsx/vendor/json2.jsxbin") + ");}" +
                "$.evalFile(" + JSON.stringify(root + "/jsx/hostscript.jsxbin") + ");" +
                "if(typeof getGraphSelection!=='function'||typeof writeGraphSnapshot!=='function')" +
                "{throw Error('Expression Node host functions were not loaded');}" +
                "JSON.stringify({expressionNodeReady:true});";
            this.evaluate(script, (error, result) => {
                if (!error) {
                    try {
                        if (JSON.parse(result).expressionNodeReady !== true) throw Error("Unexpected host bootstrap response");
                    } catch (parseError) { error = "Invalid host bootstrap response: " + String(result).slice(0, 160); }
                }
                finish(error);
            });
        } catch (error) { finish(error.message); }
    }

    request(script, callback) {
        const fail = error => callback(JSON.stringify({error: error}));
        this.initialize(error => {
            if (error) { fail(error); return; }
            this.evaluate(script, (requestError, result) => {
                if (requestError) { fail(requestError); return; }
                try { JSON.parse(result); }
                catch (parseError) {
                    fail("Invalid JSON from ExtendScript: " + String(result).slice(0, 160));
                    return;
                }
                callback(result);
            });
        });
    }
}
