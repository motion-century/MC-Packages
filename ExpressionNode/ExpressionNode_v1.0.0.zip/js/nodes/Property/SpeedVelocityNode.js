class SpeedVelocityNode extends Node {
    constructor() {
        super("Speed/Velocity", {
            width: 160,
            headerBgClass: "bg-node-math/20",
            headerBorderClass: "border-node-math/30",
            headerTextClass: "text-node-math"
        });

        const controlDiv = document.createElement("div");
        controlDiv.className = "mt-2 mb-2";
        controlDiv.innerHTML = `
            <select class="w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none">
                <option value="Speed">Speed</option>
                <option value="Velocity">Velocity</option>
            </select>
        `;
        this.bodyEl.appendChild(controlDiv);

        this.propPort = this.addInput("Property", "ANY_NUM");
        this.propPort.acceptsOnlyNode = "SourceLayerNode";

        this.timePort = this.addInput("Time", "1D");
        this.timeInputEl = document.createElement("input");
        this.timeInputEl.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-0.5 mt-1 font-mono-label text-mono-label text-on-surface focus:border-secondary focus:outline-none text-[11px] placeholder-on-surface-variant/50";
        this.timeInputEl.type = "text";
        this.timeInputEl.placeholder = "Time (optional)";
        
        const container = document.createElement("div");
        container.className = "pl-4";
        container.appendChild(this.timeInputEl);
        this.timePort.el.appendChild(container);

        this.addOutput("Out", "ANY_NUM");
    }

    onConnectionChanged(port) {
        if (port === this.timePort) {
            if (port.wires.length > 0) {
                this.timeInputEl.classList.add("hidden");
            } else {
                this.timeInputEl.classList.remove("hidden");
            }
        }
    }
}
