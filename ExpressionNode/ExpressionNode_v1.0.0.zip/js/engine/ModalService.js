class ModalService {
    static _keydownHandler = null;

    static init() {
        // Tạo container chứa Modal nếu chưa có
        if (!document.getElementById("modal-container")) {
            const container = document.createElement("div");
            container.id = "modal-container";
            // Lớp vỏ bao ngoài
            container.className = "fixed inset-0 z-[9999] hidden flex items-center justify-center p-4 pointer-events-none";
            
            container.innerHTML = `
                <!-- Overlay Backdrop -->
                <div id="modal-backdrop" class="fixed inset-0 bg-[#0f0d16]/80 backdrop-blur-sm transition-opacity pointer-events-auto"></div>
                
                <!-- Modal Box -->
                <div id="modal-box" class="relative z-50 w-full max-w-md transform overflow-hidden rounded-xl bg-[#2b2833]/40 backdrop-blur-xl p-8 text-left align-middle shadow-2xl transition-all border border-[#494455]/30 flex flex-col gap-6 scale-95 opacity-0 pointer-events-auto">
                    <!-- Header -->
                    <div class="flex items-start gap-4">
                        <div class="flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-[#93000a]/20 border border-[#93000a]/50">
                            <span class="material-symbols-outlined text-[#ffb4ab]" style="font-variation-settings: 'FILL' 1;">warning</span>
                        </div>
                        <div class="flex-1 pt-1">
                            <h3 class="font-headline-md text-headline-md text-[#ffb4ab]" id="modal-title">Title</h3>
                        </div>
                    </div>
                    
                    <!-- Body Content -->
                    <div class="pl-16">
                        <p class="font-body-md text-body-md text-[#e6e0ee]" id="modal-message">Message</p>
                    </div>
                    
                    <!-- Actions -->
                    <div class="mt-4 flex flex-row-reverse gap-3">
                        <button id="modal-btn-confirm" class="inline-flex justify-center items-center gap-2 rounded-lg bg-[#ffb4ab] px-6 py-2.5 font-headline-sm text-headline-sm text-[#690005] hover:bg-[#ffb4ab]/90 hover:shadow-[0_0_12px_rgba(255,180,171,0.3)] transition-all duration-200 active:scale-95 focus:outline-none" type="button">
                            Confirm <span class="material-symbols-outlined text-[14px] opacity-70 font-bold" style="font-variation-settings: 'wght' 600;">keyboard_return</span>
                        </button>
                        <button id="modal-btn-cancel" class="inline-flex justify-center items-center gap-2 rounded-lg border border-[#494455] bg-transparent px-6 py-2.5 font-headline-sm text-headline-sm text-[#cac3d8] hover:text-[#e6e0ee] hover:bg-[#36333e] transition-all duration-200 active:scale-95 focus:outline-none" type="button">
                            Cancel <span class="text-[10px] font-mono-label opacity-60 border border-[#cac3d8]/50 rounded px-1 leading-none py-[2px]">Esc</span>
                        </button>
                    </div>
                    <!-- Dummy Input to capture focus and intercept AE shortcuts -->
                    <input type="text" id="modal-dummy-input" class="opacity-0 absolute w-0 h-0 pointer-events-none" autocomplete="off" />
                </div>
            `;
            document.body.appendChild(container);
            
            // Events
            document.getElementById("modal-backdrop").addEventListener("click", () => ModalService.hide());
            document.getElementById("modal-btn-cancel").addEventListener("click", () => ModalService.hide());
        }
    }

    static confirm(title, message, onConfirm) {
        this.init();
        this._previousFocus = document.activeElement;
        const container = document.getElementById("modal-container");
        const box = document.getElementById("modal-box");
        const titleEl = document.getElementById("modal-title");
        const messageEl = document.getElementById("modal-message");
        const btnConfirm = document.getElementById("modal-btn-confirm");
        
        titleEl.innerText = title;
        messageEl.innerText = message;
        
        // Reset old click event by cloning
        const newBtnConfirm = btnConfirm.cloneNode(true);
        btnConfirm.parentNode.replaceChild(newBtnConfirm, btnConfirm);
        
        const generation = window.graphSession ? window.graphSession.generation : 0;
        newBtnConfirm.addEventListener("click", () => {
            if (window.graphSession && (generation !== window.graphSession.generation || !window.canEditGraph())) return;
            onConfirm();
            ModalService.hide();
        });

        // Show
        container.classList.remove("hidden");
        // Animation
        setTimeout(() => {
            box.classList.remove("scale-95", "opacity-0");
            box.classList.add("scale-100", "opacity-100");
        }, 10);

        // Focus dummy input to trap keys in CEP
        const dummyInput = document.getElementById("modal-dummy-input");
        if (dummyInput) {
            dummyInput.focus();
            
            // Bind Keyboard Event to the dummy input instead of document
            if (ModalService._keydownHandler) {
                dummyInput.removeEventListener("keydown", ModalService._keydownHandler);
            }
            
            ModalService._keydownHandler = (e) => {
                if (e.key === "Enter") {
                    e.preventDefault();
                    newBtnConfirm.click();
                } else if (e.key === "Escape") {
                    e.preventDefault();
                    ModalService.hide();
                }
            };
            
            dummyInput.addEventListener("keydown", ModalService._keydownHandler);
        }

        // Register key interest for CEP so AE doesn't hijack Enter and Esc
        if (window.updateCEPKeyInterests) window.updateCEPKeyInterests(true);
    }
    
    static hide() {
        const container = document.getElementById("modal-container");
        const box = document.getElementById("modal-box");
        if (container && box) {
            box.classList.remove("scale-100", "opacity-100");
            box.classList.add("scale-95", "opacity-0");
            setTimeout(() => {
                container.classList.add("hidden");
            }, 200); // match transition duration
        }
        
        // Remove Keyboard Event
        const dummyInput = document.getElementById("modal-dummy-input");
        if (ModalService._keydownHandler && dummyInput) {
            dummyInput.removeEventListener("keydown", ModalService._keydownHandler);
            ModalService._keydownHandler = null;
        }

        // Do not leave keyboard focus in the invisible key-capture input.
        if (container && container.contains(document.activeElement)) {
            const previous = this._previousFocus;
            if (previous && previous.isConnected && previous.tabIndex >= 0) previous.focus();
            else {
                const canvas = document.getElementById("canvas-container");
                if (canvas) { canvas.tabIndex = -1; canvas.focus(); }
            }
        }
        this._previousFocus = null;

        // Restore the editor's reserved keys instead of clearing the entire list.
        if (window.updateCEPKeyInterests) window.updateCEPKeyInterests(false);
    }
}
