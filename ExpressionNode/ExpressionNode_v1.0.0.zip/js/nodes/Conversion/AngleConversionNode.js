class AngleConversionNode extends Node {
  constructor() {
    super("Angle Conversion", {
      width: 180,
      headerBgClass: "bg-node-math/20",
      headerBorderClass: "border-node-math/30",
      headerTextClass: "text-node-math",
    });

    const portA = this.addInput("", "1D");
    this.addOutput("", "1D");

    portA.el.remove();

    const container = document.createElement("div");
    container.className = "flex flex-col space-y-2 mb-2 gap-2";

    this.funcSelect = document.createElement("select");
    this.funcSelect.className =
      "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none";

    const funcs = ["degreesToRadians", "radiansToDegrees"];
    const texts = ["Degrees to Radians", "Radians to Degrees"];
    funcs.forEach((f, i) => {
      const opt = document.createElement("option");
      opt.value = f;
      opt.innerText = texts[i];
      this.funcSelect.appendChild(opt);
    });

    container.appendChild(this.funcSelect);

    // Input A
    this.inputAContainer = document.createElement("div");
    this.inputAContainer.className = "w-full flex items-center relative";
    portA.el.className = "relative flex items-center";
    this.inputAContainer.appendChild(portA.el);

    this.inputA = document.createElement("input");
    this.inputA.className =
      "flex-1 min-w-0 bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
    this.inputA.type = "text";
    this.inputA.value = "0";
    this.inputAContainer.appendChild(this.inputA);

    this.unitLabel = document.createElement("span");
    this.unitLabel.className =
      "font-mono-label text-mono-label text-on-surface-variant ml-2 w-6 text-center";
    this.unitLabel.innerText = "°";
    this.inputAContainer.appendChild(this.unitLabel);

    container.appendChild(this.inputAContainer);

    this.bodyEl.insertBefore(container, this.bodyEl.lastElementChild);

    UIUtils.makeInputDraggable(this.inputA);

    this.funcSelect.addEventListener("change", () => {
      this.updateUnitLabel();
      if (window.triggerAutoSave) window.triggerAutoSave();
    });
  }

  updateUnitLabel() {
    if (this.funcSelect.value === "degreesToRadians") {
      this.unitLabel.innerText = "°";
    } else {
      this.unitLabel.innerText = "rad";
    }
  }

  onConnectionChanged(port) {
    if (port === this.inputs[0]) {
      if (port.wires.length > 0) this.inputA.classList.add("hidden");
      else this.inputA.classList.remove("hidden");
    }
    this.updatePosition();
  }

  getValues() {
    return [this.inputA.value, this.funcSelect.value];
  }

  setValues(values) {
    if (values && values.length >= 2) {
      this.inputA.value = values[0];
      this.funcSelect.value = values[1];
      this.updateUnitLabel();
    }
  }
}
