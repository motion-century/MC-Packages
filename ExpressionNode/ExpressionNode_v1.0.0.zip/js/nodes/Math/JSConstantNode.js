class JSConstantNode extends Node {
    constructor() {
        super("JS Constant", {
            width: 160,
            headerBgClass: "bg-node-math/20",
            headerBorderClass: "border-node-math/30",
            headerTextClass: "text-node-math"
        });

        this.addOutput("", "1D");

        const container = document.createElement("div");
        container.className = "flex flex-col space-y-2 mt-2";

        this.constSelect = document.createElement("select");
        this.constSelect.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none";
        
        const constants = ["PI", "E", "LOG2E", "LOG10E", "LN2", "LN10", "SQRT2", "SQRT1_2"];
        constants.forEach(c => {
            const opt = document.createElement("option");
            opt.value = c;
            opt.innerText = `Math.${c}`;
            this.constSelect.appendChild(opt);
        });
        
        container.appendChild(this.constSelect);
        this.bodyEl.insertBefore(container, this.bodyEl.lastElementChild);

        this.constSelect.addEventListener("change", () => {
            if (window.triggerAutoSave) window.triggerAutoSave();
        });
    }

    getValues() {
        return [this.constSelect.value];
    }

    setValues(values) {
        if (values && values.length > 0) {
            this.constSelect.value = values[0];
        }
    }
}
