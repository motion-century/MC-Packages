class SourceRectAtTimeNode extends Node {
    constructor() {
        super("SourceRect at Time", {
            width: 180,
            headerBgClass: "bg-surface-variant/80",
            headerBorderClass: "border-outline-variant/30",
            headerTextClass: "text-on-surface"
        });

        this.addInput("Layer", "LAYER");

        this.timePort = this.addInput("Time", "1D");
        this.timeInputEl = document.createElement("input");
        this.timeInputEl.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-0.5 mt-1 font-mono-label text-mono-label text-on-surface focus:border-secondary focus:outline-none text-[11px] placeholder-on-surface-variant/50";
        this.timeInputEl.type = "text";
        this.timeInputEl.placeholder = "Time (optional)";
        
        const container = document.createElement("div");
        container.className = "pl-4";
        container.appendChild(this.timeInputEl);
        this.timePort.el.appendChild(container);

        this.addOutput("Left", "1D");
        this.addOutput("Top", "1D");
        this.addOutput("Width", "1D");
        this.addOutput("Height", "1D");
    }

    onConnectionChanged(port) {
        if (port === this.timePort) {
            if (port.wires.length > 0) {
                this.timeInputEl.classList.add("hidden");
            } else {
                this.timeInputEl.classList.remove("hidden");
            }
        }
    }
}
