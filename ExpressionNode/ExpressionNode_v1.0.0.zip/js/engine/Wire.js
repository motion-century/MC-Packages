/**
 * Wire - Xử lý vẽ dây nối (Bezier Curve)
 */
class Wire {
    constructor(sourcePort, targetPort) {
        this.sourcePort = sourcePort;
        this.targetPort = targetPort; // Có thể null lúc đang kéo dây ảo
        this.el = this.createDOM();
    }

    createDOM() {
        const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
        path.setAttribute("class", "wire-path opacity-60 pointer-events-auto cursor-pointer");
        
        this.pathEl = path;
        this.updateColor();
        
        // Hover vào dây sẽ highlight
        path.addEventListener("mouseenter", () => path.classList.add("selected"));
        path.addEventListener("mouseleave", () => path.classList.remove("selected"));

        // Click vào dây để xóa
        path.addEventListener("mousedown", (e) => {
            if (e.button === 0) {
                e.stopPropagation();
                if (this.sourcePort.node.graph) {
                    this.sourcePort.node.graph.removeWire(this);
                }
            }
        });

        return path;
    }

    updateColor() {
        const colors = {
            "1D": "#ac9caf",
            "2D": "#A855F7",
            "3D": "#F200D9",
            "COLOR": "#eab308",
            "COLOR_HSL": "#eab308",
            "COLOR_LAB": "#eab308",
            "STRING": "#82FAFF",
            "PATH": "#FF6554",
            "ANY": "#948ea1",
            "ANY_NUM": "#3b82f6",
            "LAYER": "#ef4444",
            "ERROR": "#ef4444"
        };
        // Dây mang màu của cổng Output (sourcePort)
        if (this.sourcePort && this.sourcePort.type) {
            const hex = this.sourcePort.displayColor || colors[this.sourcePort.type.toUpperCase()] || "#9ca3af";
            this.pathEl.setAttribute("stroke", hex);
        } else {
            this.pathEl.setAttribute("stroke", "#9ca3af");
        }
    }

    updatePath(overrideStart = null, overrideEnd = null) {
        const p1 = overrideStart || (this.sourcePort ? this.sourcePort.getGlobalPosition() : {x:0, y:0});
        const p2 = overrideEnd || (this.targetPort ? this.targetPort.getGlobalPosition() : {x:0, y:0});

        // Tính Bezier curve
        // Tùy theo độ xa gần của 2 điểm mà điều chỉnh độ cong (offset)
        const dx = Math.abs(p2.x - p1.x);
        const offset = Math.max(50, dx * 0.5);

        // Control points
        const cp1x = p1.x + offset;
        const cp1y = p1.y;
        const cp2x = p2.x - offset;
        const cp2y = p2.y;

        const d = `M ${p1.x} ${p1.y} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p2.x} ${p2.y}`;
        this.pathEl.setAttribute("d", d);
    }
}
