class TimeNode extends Node {
    constructor() {
        super("Time", {
            width: 100,
            headerBgClass: "bg-surface-variant/80",
            headerBorderClass: "border-outline-variant/30",
            headerTextClass: "text-on-surface"
        });
        this.addOutput("Time", "1D");
    }
}
