class AngleNode extends Node {
    constructor() {
        super("Angle", {
            width: 180,
            headerBgClass: "bg-surface-variant/80",
            headerBorderClass: "border-outline-variant/30",
            headerTextClass: "text-on-surface"
        });

        const portOut = this.addOutput("", "1D");
        portOut.el.remove();
        portOut.el.style.position = "absolute";
        portOut.el.style.right = "-6px";
        portOut.el.style.top = "50%";
        portOut.el.style.transform = "translateY(-50%)";
        this.el.appendChild(portOut.el);

        const container = document.createElement("div");
        container.className = "flex flex-col space-y-2 mt-2 gap-2";

        // Angle Dial UI
        this.dialContainer = document.createElement("div");
        this.dialContainer.className = "flex items-center space-x-2";
        
        // SVG Wheel
        const wheelWrapper = document.createElement("div");
        wheelWrapper.className = "relative w-10 h-10 rounded-full bg-surface-dim border border-outline-variant flex items-center justify-center cursor-pointer";
        this.wheelIndicator = document.createElement("div");
        this.wheelIndicator.className = "absolute w-0.5 h-4 bg-primary rounded-full origin-bottom";
        this.wheelIndicator.style.bottom = "50%";
        this.wheelIndicator.style.transform = "rotate(0deg)";
        wheelWrapper.appendChild(this.wheelIndicator);

        // Input Field
        this.inputEl = document.createElement("input");
        this.inputEl.className = "flex-1 min-w-0 bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0 cursor-ew-resize";
        this.inputEl.type = "text";
        this.inputEl.value = "0";

        this.dialContainer.appendChild(wheelWrapper);
        this.dialContainer.appendChild(this.inputEl);
        container.appendChild(this.dialContainer);

        // Msg Container
        this.kfMsg = document.createElement("div");
        this.kfMsg.className = "w-full bg-green-500/20 border border-green-500/50 rounded py-2 text-center text-green-300 font-body-sm hidden";
        this.kfMsg.innerText = "Managed by AE Keyframes";
        container.appendChild(this.kfMsg);

        // Checkboxes Container
        const cbContainer = document.createElement("div");
        cbContainer.className = "flex flex-col space-y-2 mt-2 pt-2 border-t border-outline-variant/30";

        const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
        const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;

        // Control Checkbox
        const rowControl = document.createElement("div");
        rowControl.className = "flex items-center space-x-2 cursor-pointer group";
        this.iconControl = document.createElement("div");
        this.iconControl.innerHTML = inactiveSVG;
        const lblControl = document.createElement("span");
        lblControl.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
        lblControl.innerText = "Use Control";
        rowControl.appendChild(this.iconControl);
        rowControl.appendChild(lblControl);
        cbContainer.appendChild(rowControl);

        // Keyframe Checkbox
        const rowKf = document.createElement("div");
        rowKf.className = "flex items-center space-x-2 cursor-pointer group";
        this.iconKf = document.createElement("div");
        this.iconKf.innerHTML = inactiveSVG;
        const lblKf = document.createElement("span");
        lblKf.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
        lblKf.innerText = "Use Keyframe";
        rowKf.appendChild(this.iconKf);
        rowKf.appendChild(lblKf);
        cbContainer.appendChild(rowKf);

        container.appendChild(cbContainer);
        this.bodyEl.insertBefore(container, this.bodyEl.lastElementChild);

        // State
        this.state = { value: 0, control: false, kf: false };

        // Events
        rowControl.addEventListener("click", () => {
            this.state.control = !this.state.control;
            if (!this.state.control) this.state.kf = false;
            this.updateCheckboxes();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        rowKf.addEventListener("click", () => {
            this.state.kf = !this.state.kf;
            if (this.state.kf) this.state.control = true;
            this.updateCheckboxes();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        // Input drag event
        if (typeof UIUtils !== 'undefined') UIUtils.makeInputDraggable(this.inputEl);
        this.inputEl.addEventListener("change", (e) => {
            this.state.value = parseFloat(e.target.value) || 0;
            this.updateWheel();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        // Wheel drag event
        let isDragging = false;
        let startAngle = 0;
        let startValue = 0;

        wheelWrapper.addEventListener("mousedown", (e) => {
            isDragging = true;
            e.stopPropagation();
            
            const rect = wheelWrapper.getBoundingClientRect();
            const cx = rect.left + rect.width / 2;
            const cy = rect.top + rect.height / 2;
            startAngle = Math.atan2(e.clientY - cy, e.clientX - cx) * 180 / Math.PI;
            startValue = this.state.value;
            
            document.body.style.cursor = 'ew-resize';
        });

        document.addEventListener("mousemove", (e) => {
            if (!isDragging) return;
            const rect = wheelWrapper.getBoundingClientRect();
            const cx = rect.left + rect.width / 2;
            const cy = rect.top + rect.height / 2;
            
            let currentAngle = Math.atan2(e.clientY - cy, e.clientX - cx) * 180 / Math.PI;
            
            // Calculate delta to allow infinite rotation
            let delta = currentAngle - startAngle;
            if (delta > 180) delta -= 360;
            if (delta < -180) delta += 360;
            
            startAngle = currentAngle;
            
            let step = 1;
            if (e.shiftKey) step = 10;
            if (e.ctrlKey) step = 0.1;
            
            let newValue = this.state.value + delta;
            
            if (e.ctrlKey) {
                newValue = Math.round(newValue * 10) / 10;
            } else {
                newValue = Math.round(newValue);
            }
            
            if (newValue !== this.state.value) {
                this.state.value = newValue;
                this.inputEl.value = this.state.value;
                this.updateWheel();
            }
        });

        document.addEventListener("mouseup", () => {
            if (isDragging) {
                isDragging = false;
                document.body.style.cursor = 'default';
                if (window.triggerAutoSave) window.triggerAutoSave();
            }
        });

        this.updateCheckboxes();
        this.updateWheel();
    }

    updateWheel() {
        this.wheelIndicator.style.transform = `rotate(${this.state.value}deg)`;
    }

    updateCheckboxes() {
        const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
        const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;
        
        this.iconControl.innerHTML = this.state.control ? activeSVG : inactiveSVG;
        this.iconKf.innerHTML = this.state.kf ? activeSVG : inactiveSVG;
        
        if (this.state.kf) {
            this.dialContainer.classList.add("hidden");
            this.dialContainer.classList.remove("flex");
            this.kfMsg.classList.remove("hidden");
        } else {
            this.dialContainer.classList.add("flex");
            this.dialContainer.classList.remove("hidden");
            this.kfMsg.classList.add("hidden");
        }
    }

    serialize() {
        const data = super.serialize();
        data.state = this.state;
        return data;
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.state) {
            this.state = data.state;
            this.inputEl.value = this.state.value;
            this.updateWheel();
            this.updateCheckboxes();
        }
    }

    getControlPayload() {
        if (!this.state.control && !this.state.kf) return null;
        return {
            type: "ADBE Angle Control",
            value: this.state.value,
            useKeyframe: this.state.kf
        };
    }
}
