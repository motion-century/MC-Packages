// NodeRegistry.js
const NODE_REGISTRY = [
    // Inputs
    { id: 'SourceLayerNode', name: 'Source Layer', group: 'Root', icon: 'layers', desc: 'Current Layer' },
    { id: 'TargetLayerNode', name: 'Target Layer', group: 'Root', icon: 'my_location', desc: 'Specific Layer' },
    // Property
    { id: 'ThisLayerValueNode', name: 'This Layer/Value', group: 'Property', icon: 'data_object', desc: 'Current Layer Value' },
    { id: 'TimeNode', name: 'Time', group: 'Property', icon: 'schedule', desc: 'Time Variable' },
    { id: 'SpeedVelocityNode', name: 'Speed/Velocity', group: 'Property', icon: 'speed', desc: 'Speed & Velocity' },
    { id: 'SourceRectAtTimeNode', name: 'SourceRect At Time', group: 'Property', icon: 'crop', desc: 'Layer Rect' },
    { id: 'ValueNode', name: 'Value Node', group: 'Input', icon: 'data_object', desc: 'Number/Vector Input', shortcut: 'V' },
    { id: 'AngleNode', name: 'Angle Node', group: 'Input', icon: 'rotate_right', desc: 'Angle Input' },
    { id: 'CheckboxNode', name: 'Checkbox Node', group: 'Input', icon: 'check_box', desc: 'Boolean Input' },
    { id: 'ColorNode', name: 'Color Node', group: 'Input', icon: 'palette', desc: 'Color Input' },
    
    // Math
    { id: 'SimpleMathNode', name: 'Simple Math Node', group: 'Math', icon: 'calculate', desc: 'Basic Operators', shortcut: 'M' },
    { id: 'JSMathNode', name: 'JS Math', group: 'Math', icon: 'functions', desc: 'Math Functions' },
    { id: 'JSConstantNode', name: 'JS Constant Node', group: 'Math', icon: 'pin', desc: 'Math Constants' },
    { id: 'AngleConversionNode', name: 'Angle Conversion Node', group: 'Conversion', icon: 'sync_alt', desc: 'Deg/Rad Conversion' },
    { id: 'ToStringNode', name: 'To String', group: 'Conversion', icon: 'text_fields', desc: 'Convert Value to Text' },
    { id: 'ColorConversionNode', name: 'Color Conversion', group: 'Conversion', icon: 'palette', desc: 'RGB / HEX / HSL / LAB' },
    { id: 'CombineVectorNode', name: 'Combine Vector', group: 'Math', icon: 'merge', desc: 'Combine to Vector' },
    { id: 'SplitVectorNode', name: 'Split Vector', group: 'Math', icon: 'call_split', desc: 'Split Vector' },
    { id: 'InterpolationNode', name: 'Interpolation', group: 'Math', icon: 'animation', desc: 'Linear/Ease' },
    
    // Randomizer
    { id: 'WigglerNode', name: 'Wiggler', group: 'Randomizer', icon: 'waves', desc: 'Wiggle Randomizer' },
    { id: 'RandomNode', name: 'Random', group: 'Randomizer', icon: 'shuffle', desc: 'Random Values' },
    { id: 'NoiseNode', name: 'Noise', group: 'Randomizer', icon: 'graphic_eq', desc: 'Noise Generator' }
];

window.NODE_REGISTRY = NODE_REGISTRY;
