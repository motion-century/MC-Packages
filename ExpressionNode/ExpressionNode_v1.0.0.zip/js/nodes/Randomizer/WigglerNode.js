class WigglerNode extends Node {
  constructor() {
    super("Wiggler", {
      width: 180,
      headerBgClass: "bg-[#e53935]", // Đỏ cho Randomizer
      headerBorderClass: "border-[#e53935]/30",
      headerTextClass: "text-[#ffebee]",
    });

    this.group = "Randomizer";
    this.icon = "waves";

    const portFreq = this.addInput("", "1D");
    const portAmp = this.addInput("", "1D");
    const portOut = this.addOutput("", "ANY");

    portFreq.el.remove();
    portAmp.el.remove();
    portOut.el.remove();

    const container = document.createElement("div");
    container.className = "flex flex-col space-y-2 mb-2 gap-2 mt-2";

    const createInputRow = (port, labelText, defaultValue) => {
        const row = document.createElement("div");
        row.className = "w-full flex items-center relative";
        port.el.className = "relative flex items-center";
        row.appendChild(port.el);
        
        const label = document.createElement("span");
        label.className = "font-label-caps text-label-caps text-on-surface-variant w-10 text-left mx-1";
        label.innerText = labelText;
        row.appendChild(label);

        const input = document.createElement("input");
        input.className = "flex-1 min-w-0 bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
        input.type = "text";
        input.value = defaultValue;
        row.appendChild(input);

        UIUtils.makeInputDraggable(input);
        return { row, input };
    };

    this.rowFreq = createInputRow(portFreq, "Freq", "2");
    this.rowAmp = createInputRow(portAmp, "Amp", "50");

    container.appendChild(this.rowFreq.row);
    container.appendChild(this.rowAmp.row);

    const uiContainer = document.createElement("div");
    uiContainer.className = "flex flex-col space-y-2 mt-2 pt-2 border-t border-outline-variant/30 gap-2";

    this.state = { loop: false, sep: true };

    const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;

    // Loop Checkbox
    const loopWrapper = document.createElement("div");
    loopWrapper.className = "flex items-center space-x-2 cursor-pointer group";
    this.iconLoop = document.createElement("div");
    this.iconLoop.innerHTML = inactiveSVG;
    
    const loopLabel = document.createElement("span");
    loopLabel.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
    loopLabel.innerText = "Loop Mode";
    
    loopWrapper.appendChild(this.iconLoop);
    loopWrapper.appendChild(loopLabel);
    
    // Separate Dimension Checkbox
    const sepWrapper = document.createElement("div");
    sepWrapper.className = "flex items-center space-x-2 cursor-pointer group";
    this.iconSep = document.createElement("div");
    this.iconSep.innerHTML = activeSVG;
    
    const sepLabel = document.createElement("span");
    sepLabel.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
    sepLabel.innerText = "Separate Dimensions";
    
    sepWrapper.appendChild(this.iconSep);
    sepWrapper.appendChild(sepLabel);

    uiContainer.appendChild(loopWrapper);
    uiContainer.appendChild(sepWrapper);

    container.appendChild(uiContainer);

    // Output row
    const outRow = document.createElement("div");
    outRow.className = "w-full flex justify-end items-center relative mt-2 pt-2 border-t border-outline-variant/30";
    portOut.el.className = "relative flex items-center";
    outRow.appendChild(portOut.el);
    container.appendChild(outRow);

    this.bodyEl.appendChild(container);

    const updateCheckboxes = () => {
        this.iconLoop.innerHTML = this.state.loop ? activeSVG : inactiveSVG;
        this.iconSep.innerHTML = this.state.sep ? activeSVG : inactiveSVG;
    };

    loopWrapper.addEventListener("click", () => {
        this.state.loop = !this.state.loop;
        updateCheckboxes();
        if (window.triggerAutoSave) window.triggerAutoSave();
    });
    sepWrapper.addEventListener("click", () => {
        this.state.sep = !this.state.sep;
        updateCheckboxes();
        if (window.triggerAutoSave) window.triggerAutoSave();
    });
  }

  onConnectionChanged(port) {
    if (port === this.inputs[0]) {
        if (port.wires.length > 0) this.rowFreq.input.classList.add("hidden");
        else this.rowFreq.input.classList.remove("hidden");
    } else if (port === this.inputs[1]) {
        if (port.wires.length > 0) this.rowAmp.input.classList.add("hidden");
        else this.rowAmp.input.classList.remove("hidden");
    }
    this.updatePosition();
  }

  getValues() {
    return [
        this.state.loop, 
        this.state.sep,
        this.rowFreq.input.value,
        this.rowAmp.input.value
    ];
  }

  setValues(values) {
    if (values && values.length >= 4) {
      this.state.loop = values[0];
      this.state.sep = values[1];
      this.rowFreq.input.value = values[2];
      this.rowAmp.input.value = values[3];
      
      const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
      const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;
      this.iconLoop.innerHTML = this.state.loop ? activeSVG : inactiveSVG;
      this.iconSep.innerHTML = this.state.sep ? activeSVG : inactiveSVG;
    }
  }
}
