/* Owner-bound persistence and editor lifetime management. */
class GraphSession {
    constructor(graph) {
        this.graph = graph;
        this.owner = null;
        this.generation = 0;
        this.phase = "checking";
        this.revision = 0;
        this.sequence = 0;
        this.pending = 0;
        this.dirty = false;
        this.timer = null;
        this.queue = [];
        this.writing = false;
        this.latest = new Map();
        this.checkVersion = 0;
        this.checking = false;
        this.checkAgain = false;
        this.blocked = true;
        this.writer = Date.now().toString(36) + Math.random().toString(36).slice(2);
    }

    canEdit() { return !this.blocked && this.phase === "ready" && !this.graph.isRestoring; }

    setBlocked(value, message) {
        this.blocked = value;
        const apply = document.getElementById("btn-apply");
        if (apply) apply.disabled = value || this.phase !== "ready";
        const overlay = document.getElementById("graph-loading-overlay");
        if (overlay) {
            overlay.textContent = message || "Loading layer…";
            overlay.classList.toggle("hidden", !value);
        }
    }

    request(script, callback) {
        window.hostBridge.request(script, callback);
    }

    capture(apply) {
        if (!this.owner || this.phase !== "ready" || this.graph.isRestoring) return null;
        if (this.graph.pendingWires.length) throw Error("Unresolved connections: sync references before saving");
        const snapshot = {
            owner: this.owner, writer: this.writer, sequence: ++this.sequence,
            generation: this.generation, revision: this.revision,
            graph: this.graph.serialize(), apply: !!apply, payload: null
        };
        if (apply) {
            try { snapshot.payload = Compiler.compileGraph(this.graph); }
            catch (error) {
                // Preserve edits even when their expression cannot compile yet.
                snapshot.apply = false;
                snapshot.compileError = error.message;
                this.showStatus("Compile failed: " + error.message);
                console.error("Compile failed:", error.message);
            }
        }
        return snapshot;
    }

    markDirty(history = true) {
        if (!this.canEdit()) return;
        if (history) this.graph.pushHistory();
        this.revision++;
        this.dirty = true;
        clearTimeout(this.timer);
        this.timer = setTimeout(() => this.flush(window.isAutoApply), 200);
    }

    flush(apply, force = false) {
        clearTimeout(this.timer);
        if (!this.dirty && !force) return;
        try {
            const snapshot = this.capture(apply);
            if (!snapshot) return;
            this.latest.set(snapshot.owner, snapshot);
            const previous = this.queue.findIndex(item => item.owner === snapshot.owner && item.apply === snapshot.apply);
            if (previous >= 0) this.queue[previous] = snapshot;
            else this.queue.push(snapshot);
            this.dirty = false;
            this.drain();
        } catch (error) { console.error("Save blocked:", error.message); }
    }

    drain() {
        if (this.writing || !this.queue.length) return;
        this.writing = true;
        const snapshot = this.queue.shift();
        this.request("writeGraphSnapshot(" + JSON.stringify(JSON.stringify(snapshot)) + ")", result => {
            this.writing = false;
            try {
                const response = JSON.parse(result);
                if (!response.ok) throw Error(response.error || "Host write rejected");
                const current = this.latest.get(snapshot.owner);
                if (current === snapshot) current.saved = true;
                if (snapshot.owner === this.owner && snapshot.generation === this.generation && !snapshot.compileError) {
                    const status = document.getElementById("graph-status");
                    if (status) status.classList.add("hidden");
                }
                if (snapshot.owner === this.owner && snapshot.generation === this.generation &&
                    snapshot.revision === this.revision && response.applied) {
                    const target = this.graph.nodes.find(node => node instanceof TargetLayerNode);
                    if (target) target.applyTargetColor(true);
                }
            } catch (error) {
                snapshot.failed = true;
                console.error("Owner-bound write failed:", snapshot.owner, error.message);
                if (snapshot.owner === this.owner && snapshot.generation === this.generation) this.showStatus("Save/Apply failed: " + error.message);
            }
            this.drain();
        });
    }

    cancelInteractions() {
        window.dispatchEvent(new Event("graph-session-ending"));
        if (window.ColorPickerModal) ColorPickerModal.hide();
        if (typeof ModalService !== "undefined") ModalService.hide();
        if (typeof hideAddNodeMenu === "function") hideAddNodeMenu();
        if (typeof hideRenameModal === "function") hideRenameModal();
        this.graph.isPanning = false;
        this.graph.isBoxSelecting = false;
        this.graph.selectionBoxEl.classList.add("hidden");
        document.body.style.cursor = "default";
    }

    check(force = false, urgent = false) {
        if (!window.csInterface) return;
        if (urgent) {
            this.flush(window.isAutoApply);
            this.setBlocked(true);
            this.cancelInteractions();
        }
        this.forceCheck = this.forceCheck || force;
        if (this.checking) {
            // A slow host must not have every reply invalidated by the poll timer.
            if (urgent || force) {
                this.checkAgain = true;
                this.checkVersion++;
            }
            return;
        }
        this.checking = true;
        const version = ++this.checkVersion;
        const requestedPin = window.pinnedLayerUID || "";
        this.request("getGraphSelection(" + JSON.stringify(requestedPin) + ")", result => {
            this.checking = false;
            if (this.checkAgain || version !== this.checkVersion || requestedPin !== (window.pinnedLayerUID || "")) {
                this.checkAgain = false;
                this.check(this.forceCheck);
                return;
            }
            try {
                const state = JSON.parse(result);
                if (!state || typeof state !== "object") throw Error("Invalid layer selection response");
                if (state.error) throw Error(state.error);
                if (typeof state.count !== "number" || (state.count === 1 && !state.owner)) {
                    throw Error("Incomplete layer selection response");
                }
                if (state.isDeleted && window.pinnedLayerUID) {
                    window.pinnedLayerUID = null;
                    const pin = document.getElementById("btn-pin-layer");
                    if (pin) { pin.classList.remove("text-primary", "bg-primary/20"); pin.classList.add("text-on-surface-variant"); }
                    this.check(true, true);
                    return;
                }
                const forceLoad = this.forceCheck;
                this.forceCheck = false;
                const label = document.getElementById("current-layer-name");
                if (label) label.textContent = state.count === 1 ? state.name : state.count ? "Multiple Layers" : "No Layer";
                if (this.owner === state.owner && this.owner && !forceLoad) {
                    this.setBlocked(this.phase === "loading" || this.phase === "error");
                    return;
                }
                this.load(state, forceLoad);
            } catch (error) {
                this.setBlocked(true, "Layer unavailable — click Sync to retry");
                this.showStatus(error.message);
                console.error("Layer check failed:", error.message);
            }
        });
    }

    load(state, forceRead = false) {
        this.flush(window.isAutoApply);
        this.cancelInteractions();
        this.generation++;
        this.historyRestore = false;
        this.initializeAfterLoad = false;
        this.pending = 0;
        this.owner = state.owner || null;
        window.currentLayerUID = this.owner || (state.count ? "MULTIPLE" : "NONE");
        this.phase = "loading";
        this.setBlocked(true);
        this.graph.isRestoring = true;
        this.graph.clearAll();
        const status = document.getElementById("graph-status");
        if (status) status.classList.add("hidden");
        this.graph.history = [];
        this.graph.historyIndex = -1;
        this.revision = 0;
        const local = this.latest.get(this.owner);
        const comment = local && (!forceRead || !local.saved) ? local.graph : state.comment;
        for (const id of ["use-node-overlay", "no-layer-overlay", "multiple-layer-overlay"]) {
            const element = document.getElementById(id);
            if (element) element.classList.add("hidden");
        }
        try {
            if (this.owner && comment) {
                const data = JSON.parse(comment);
                if (!data || !Array.isArray(data.nodes) || !Array.isArray(data.wires)) throw Error("Invalid saved graph");
                this.building = true;
                this.graph.deserialize(comment);
                this.building = false;
                this.finishLoad();
            } else {
                this.phase = this.owner ? "empty" : "unavailable";
                this.graph.isRestoring = false;
                this.setBlocked(false);
                const id = this.owner ? "use-node-overlay" : state.count ? "multiple-layer-overlay" : "no-layer-overlay";
                const overlay = document.getElementById(id);
                if (overlay) overlay.classList.remove("hidden");
                const button = document.getElementById("btn-use-node");
                const generation = this.generation;
                if (button) button.onclick = () => {
                    if (this.blocked || this.phase !== "empty" || generation !== this.generation) return;
                    this.phase = "loading";
                    this.graph.isRestoring = true;
                    this.building = true;
                    const target = new TargetLayerNode();
                    const position = this.graph.screenToWorld(window.innerWidth / 2 - 100, window.innerHeight / 2 - 100);
                    target.x = position.x; target.y = position.y;
                    this.graph.addNode(target);
                    this.building = false;
                    this.initializeAfterLoad = true;
                    if (overlay) overlay.classList.add("hidden");
                    this.setBlocked(true);
                    this.finishLoad();
                };
            }
        } catch (error) { this.failLoad(error); }
    }

    failLoad(error) {
        this.building = false;
        this.phase = "error";
        this.setBlocked(true, "Cannot load graph — click Sync to retry");
        console.error("Graph load failed:", error.message);
    }

    finishLoad() {
        if (this.phase !== "loading" || this.pending || this.building) return;
        this.graph.resolvePendingWires();
        if (this.graph.pendingWires.length) {
            this.failLoad(Error("Missing property ports; original graph retained on layer"));
            return;
        }
        this.graph.isRestoring = false;
        this.phase = "ready";
        if (!this.historyRestore) this.graph.pushHistory();
        this.setBlocked(false);
        if (this.historyRestore) {
            this.historyRestore = false;
            this.markDirty(false);
        }
        if (this.initializeAfterLoad) {
            this.initializeAfterLoad = false;
            this.markDirty();
        }
    }

    nodeRequest(node, script, callback) {
        const generation = this.generation;
        const requestVersion = node.requestVersion;
        this.pending++;
        this.request(script, result => {
            if (generation !== this.generation) return;
            try {
                if (!node.disposed && requestVersion === node.requestVersion) callback(result);
            } catch (error) { this.failLoad(error); }
            finally { this.pending--; this.finishLoad(); }
        });
    }

    restoreHistory(json) {
        clearTimeout(this.timer);
        this.cancelInteractions();
        this.generation++;
        this.pending = 0;
        this.phase = "loading";
        this.historyRestore = true;
        this.graph.isRestoring = true;
        this.setBlocked(true);
        this.building = true;
        try {
            this.graph.deserialize(json, true);
            this.building = false;
            this.finishLoad();
        } catch (error) { this.failLoad(error); }
    }

    showStatus(message) {
        const status = document.getElementById("graph-status");
        if (status) { status.textContent = message; status.classList.remove("hidden"); }
    }
}

window.canEditGraph = () => !window.graphSession || window.graphSession.canEdit();
