class ColorPickerModal {
    static init() {
        if (document.getElementById("color-picker-container")) return;

        const container = document.createElement("div");
        container.id = "color-picker-container";
        container.className = "fixed inset-0 z-[9999] hidden pointer-events-none";

        // HTML từ mẫu (bỏ body/html tags)
        container.innerHTML = `
            <!-- Transparent Overlay Backdrop (Click to close) -->
            <div id="color-picker-backdrop" class="fixed inset-0 bg-transparent pointer-events-auto"></div>
            
            <!-- Color Picker Panel -->
            <div id="color-picker-panel" class="absolute pointer-events-auto bg-surface-container-low border border-surface-bright rounded-xl shadow-2xl flex flex-col backdrop-blur-xl z-10 transition-opacity duration-200" style="width: 272px; max-width: calc(100vw - 20px); padding: 16px; gap: 16px; box-sizing: border-box; max-height: calc(100vh - 20px); overflow-y: auto;">
                
                <!-- Top Section: Wheel & Vertical Sliders -->
                <div class="flex h-48" style="gap: 12px;">
                    <!-- Color Wheel Area -->
                    <div id="cp-wheel" class="relative w-48 h-48 rounded-full overflow-hidden shrink-0 border border-surface-bright cursor-crosshair" style="background: conic-gradient(red, yellow, lime, aqua, blue, magenta, red); flex-shrink: 1; min-width: 0;">
                        <div class="absolute inset-0 rounded-full" style="background: radial-gradient(circle closest-side, white, transparent);"></div>
                        <!-- Selector Reticle -->
                        <div id="cp-reticle" class="absolute w-4 h-4 border-2 border-white rounded-full shadow-sm" style="top: 20%; left: 60%; transform: translate(-50%, -50%); pointer-events: none;"></div>
                    </div>
                    <!-- Vertical Sliders -->
                    <div class="flex" style="flex: 0 0 24px; margin-right: 4px;">
                        <!-- Value Slider -->
                        <div id="cp-val-track" class="w-6 h-full rounded-full border border-surface-bright relative bg-gradient-to-b from-white to-black cursor-pointer">
                            <div id="cp-val-handle" class="absolute w-8 h-2 bg-white rounded-sm -left-1 shadow-sm border border-surface-container-lowest pointer-events-none" style="top: 20%;"></div>
                        </div>
                    </div>
                </div>

                <!-- Middle Section: Mode Toggle & Current Color -->
                <div class="flex items-center justify-between">
                    <div class="flex bg-surface-container-highest rounded-lg p-1 border border-surface-bright">
                        <button id="cp-btn-hsv" class="px-4 py-1 rounded-md bg-surface-container-low text-primary-container font-label-caps text-label-caps shadow-sm">HSV</button>
                        <button id="cp-btn-rgb" class="px-4 py-1 rounded-md text-on-surface-variant font-label-caps text-label-caps hover:text-on-surface transition-colors">RGB</button>
                    </div>
                    <div class="w-12 h-8 rounded-lg border border-surface-bright relative overflow-hidden" style="background-image: linear-gradient(45deg, #3b3743 25%, transparent 25%, transparent 75%, #3b3743 75%, #3b3743), linear-gradient(45deg, #3b3743 25%, transparent 25%, transparent 75%, #3b3743 75%, #3b3743); background-size: 8px 8px; background-position: 0 0, 4px 4px;">
                        <div id="cp-swatch" class="absolute inset-0" style="background-color: #7C4DFF;"></div>
                    </div>
                </div>

                <!-- Bottom Section: Fine-tuning Sliders -->
                <div id="cp-sliders-hsv" class="flex flex-col gap-4">
                    <div class="flex items-center gap-3">
                        <span class="font-label-caps text-label-caps text-on-surface-variant w-8">HUE</span>
                        <input id="cp-hue-slider" class="flex-1 track-hue" style="-webkit-appearance: none; background: transparent; height: 4px; border-radius: 2px; background-image: linear-gradient(to right, #ff0000 0%, #ffff00 17%, #00ff00 33%, #00ffff 50%, #0000ff 67%, #ff00ff 83%, #ff0000 100%);" max="360" min="0" type="range" value="260">
                        <span id="cp-hue-val" class="font-mono-label text-mono-label text-on-surface w-10 text-right">260</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="font-label-caps text-label-caps text-on-surface-variant w-8">SAT</span>
                        <input id="cp-sat-slider" class="flex-1 track-sat" style="-webkit-appearance: none; background: transparent; height: 4px; border-radius: 2px; background-image: linear-gradient(to right, #808080, #7c4dff);" max="100" min="0" type="range" value="70">
                        <span id="cp-sat-val" class="font-mono-label text-mono-label text-on-surface w-10 text-right">0.70</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="font-label-caps text-label-caps text-on-surface-variant w-8">VAL</span>
                        <input id="cp-val-slider" class="flex-1 track-val" style="-webkit-appearance: none; background: transparent; height: 4px; border-radius: 2px; background-image: linear-gradient(to right, #000000, #ffffff);" max="100" min="0" type="range" value="100">
                        <span id="cp-val-val" class="font-mono-label text-mono-label text-on-surface w-10 text-right">1.00</span>
                    </div>
                </div>

                <div id="cp-sliders-rgb" class="flex flex-col gap-4 hidden">
                    <div class="flex items-center gap-3">
                        <span class="font-label-caps text-label-caps text-on-surface-variant w-8">R</span>
                        <input id="cp-r-slider" class="flex-1 track-sat" style="-webkit-appearance: none; background: transparent; height: 4px; border-radius: 2px; background-image: linear-gradient(to right, #000000, #ff0000);" max="255" min="0" type="range" value="128">
                        <span id="cp-r-val" class="font-mono-label text-mono-label text-on-surface w-10 text-right">128</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="font-label-caps text-label-caps text-on-surface-variant w-8">G</span>
                        <input id="cp-g-slider" class="flex-1 track-sat" style="-webkit-appearance: none; background: transparent; height: 4px; border-radius: 2px; background-image: linear-gradient(to right, #000000, #00ff00);" max="255" min="0" type="range" value="128">
                        <span id="cp-g-val" class="font-mono-label text-mono-label text-on-surface w-10 text-right">128</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="font-label-caps text-label-caps text-on-surface-variant w-8">B</span>
                        <input id="cp-b-slider" class="flex-1 track-sat" style="-webkit-appearance: none; background: transparent; height: 4px; border-radius: 2px; background-image: linear-gradient(to right, #000000, #0000ff);" max="255" min="0" type="range" value="128">
                        <span id="cp-b-val" class="font-mono-label text-mono-label text-on-surface w-10 text-right">128</span>
                    </div>
                </div>
                    <div class="h-px w-full bg-outline-variant/30 my-1"></div>
                    <div class="flex items-center justify-between mt-1">
                        <div class="flex items-center gap-3 flex-1">
                            <span class="font-label-caps text-label-caps text-on-surface-variant w-8">HEX</span>
                            <div class="bg-surface-container-highest border border-surface-bright rounded-md px-3 py-1.5 flex-1 flex items-center">
                                <span class="font-mono-label text-mono-label text-on-surface-variant mr-1">#</span>
                                <input id="cp-hex" class="bg-transparent border-none text-on-surface font-mono-label text-mono-label w-full focus:ring-0 p-0 uppercase" type="text" value="7C4DFF">
                            </div>
                        </div>
                    </div>
            </div>
            <style>
                #cp-sliders-hsv, #cp-sliders-rgb { gap: 12px; }
                #color-picker-panel input[type="range"] { min-width: 0; width: 0; flex: 1 1 0%; }
                #cp-sliders-hsv > div, #cp-sliders-rgb > div { gap: 8px; }
                #cp-sliders-hsv > div > span, #cp-sliders-rgb > div > span { flex-shrink: 0; }
                .track-hue::-webkit-slider-thumb { -webkit-appearance: none; height: 16px; width: 16px; border-radius: 50%; background: #ffffff; cursor: pointer; margin-top: -6px; box-shadow: 0 0 0 2px #14121c, 0 0 0 4px #7c4dff; }
                .track-sat::-webkit-slider-thumb { -webkit-appearance: none; height: 16px; width: 16px; border-radius: 50%; background: #ffffff; cursor: pointer; margin-top: -6px; box-shadow: 0 0 0 2px #14121c, 0 0 0 4px #7c4dff; }
                .track-val::-webkit-slider-thumb { -webkit-appearance: none; height: 16px; width: 16px; border-radius: 50%; background: #ffffff; cursor: pointer; margin-top: -6px; box-shadow: 0 0 0 2px #14121c, 0 0 0 4px #7c4dff; }
            </style>
        `;

        document.body.appendChild(container);

        this.container = container;
        this.panel = document.getElementById("color-picker-panel");
        this.backdrop = document.getElementById("color-picker-backdrop");
        
        this.elements = {
            wheel: document.getElementById("cp-wheel"),
            reticle: document.getElementById("cp-reticle"),
            valTrack: document.getElementById("cp-val-track"),
            valHandle: document.getElementById("cp-val-handle"),
            swatch: document.getElementById("cp-swatch"),
            hueSlider: document.getElementById("cp-hue-slider"),
            satSlider: document.getElementById("cp-sat-slider"),
            valSlider: document.getElementById("cp-val-slider"),
            hueVal: document.getElementById("cp-hue-val"),
            satVal: document.getElementById("cp-sat-val"),
            valVal: document.getElementById("cp-val-val"),
            rSlider: document.getElementById("cp-r-slider"),
            gSlider: document.getElementById("cp-g-slider"),
            bSlider: document.getElementById("cp-b-slider"),
            rVal: document.getElementById("cp-r-val"),
            gVal: document.getElementById("cp-g-val"),
            bVal: document.getElementById("cp-b-val"),
            btnHsv: document.getElementById("cp-btn-hsv"),
            btnRgb: document.getElementById("cp-btn-rgb"),
            slidersHsv: document.getElementById("cp-sliders-hsv"),
            slidersRgb: document.getElementById("cp-sliders-rgb"),
            hex: document.getElementById("cp-hex")
        };

        this.state = { h: 0, s: 1, v: 1, a: 1 };
        this.activeMode = 'HSV'; // HSV or RGB
        this.onChangeCb = null;

        this.bindEvents();
    }

    static HSVtoRGB(h, s, v) {
        let r, g, b;
        let i = Math.floor(h * 6);
        let f = h * 6 - i;
        let p = v * (1 - s);
        let q = v * (1 - f * s);
        let t = v * (1 - (1 - f) * s);

        switch (i % 6) {
            case 0: r = v, g = t, b = p; break;
            case 1: r = q, g = v, b = p; break;
            case 2: r = p, g = v, b = t; break;
            case 3: r = p, g = q, b = v; break;
            case 4: r = t, g = p, b = v; break;
            case 5: r = v, g = p, b = q; break;
        }
        return [r, g, b];
    }

    static RGBtoHSV(r, g, b) {
        let max = Math.max(r, g, b), min = Math.min(r, g, b);
        let h, s, v = max;
        let d = max - min;
        s = max === 0 ? 0 : d / max;
        if (max === min) h = 0; // achromatic
        else {
            switch (max) {
                case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                case g: h = (b - r) / d + 2; break;
                case b: h = (r - g) / d + 4; break;
            }
            h /= 6;
        }
        return [h, s, v];
    }

    static rgbToHex(r, g, b) {
        const toHex = x => {
            const hex = Math.round(x * 255).toString(16);
            return hex.length === 1 ? '0' + hex : hex;
        };
        return (toHex(r) + toHex(g) + toHex(b)).toUpperCase();
    }

    static hexToRgb(hex) {
        var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? [
            parseInt(result[1], 16) / 255,
            parseInt(result[2], 16) / 255,
            parseInt(result[3], 16) / 255
        ] : null;
    }

    static updateUI() {
        this.state.a = 1;
        const { h, s, v, a } = this.state;
        const [r, g, b] = this.HSVtoRGB(h, s, v);
        
        // Wheel reticle
        const angle = h * 360 - 90; // shift back to atan2 coordinates for Math.cos/sin
        const radius = s * 50; // 50% max distance
        const cx = 50 + radius * Math.cos(angle * Math.PI / 180);
        const cy = 50 + radius * Math.sin(angle * Math.PI / 180); // dy is positive downwards
        this.elements.reticle.style.left = cx + '%';
        this.elements.reticle.style.top = cy + '%';

        // Val slider
        this.elements.valHandle.style.top = ((1 - v) * 100) + '%';
        

        // Inputs
        this.elements.hueSlider.value = Math.round(h * 360);
        this.elements.hueVal.innerText = Math.round(h * 360);
        this.elements.satSlider.value = Math.round(s * 100);
        this.elements.satVal.innerText = s.toFixed(2);
        this.elements.valSlider.value = Math.round(v * 100);
        this.elements.valVal.innerText = v.toFixed(2);

        // Sat track gradient
        const pureColor = this.HSVtoRGB(h, 1, 1);
        this.elements.satSlider.style.backgroundImage = `linear-gradient(to right, #808080, rgb(${pureColor[0]*255},${pureColor[1]*255},${pureColor[2]*255}))`;

        // RGB sliders update
        const rVal = Math.round(r * 255);
        const gVal = Math.round(g * 255);
        const bVal = Math.round(b * 255);
        this.elements.rSlider.value = rVal;
        this.elements.gSlider.value = gVal;
        this.elements.bSlider.value = bVal;
        this.elements.rVal.innerText = rVal;
        this.elements.gVal.innerText = gVal;
        this.elements.bVal.innerText = bVal;
        this.elements.rSlider.style.backgroundImage = `linear-gradient(to right, rgb(0,${gVal},${bVal}), rgb(255,${gVal},${bVal}))`;
        this.elements.gSlider.style.backgroundImage = `linear-gradient(to right, rgb(${rVal},0,${bVal}), rgb(${rVal},255,${bVal}))`;
        this.elements.bSlider.style.backgroundImage = `linear-gradient(to right, rgb(${rVal},${gVal},0), rgb(${rVal},${gVal},255))`;

        const hex = this.rgbToHex(r, g, b);
        this.elements.hex.value = hex;
        this.elements.swatch.style.backgroundColor = `rgba(${r*255}, ${g*255}, ${b*255}, ${a})`;

        if (this.onChangeCb) {
            this.onChangeCb([r, g, b, a]);
        }
    }

    static bindEvents() {
        this.backdrop.addEventListener('click', () => this.hide());

        // Helper cho drag
        const makeDraggable = (el, onDrag) => {
            let isDragging = false;
            window.addEventListener('graph-session-ending', () => { isDragging = false; });
            el.addEventListener('mousedown', (e) => {
                isDragging = true;
                onDrag(e);
            });
            document.addEventListener('mousemove', (e) => {
                if (this.container.classList.contains("hidden")) return;
                if (isDragging) onDrag(e);
            });
            document.addEventListener('mouseup', () => {
                if (isDragging) {
                    isDragging = false;
                    if (window.triggerAutoSave) window.triggerAutoSave();
                }
            });
        };

        // Wheel drag
        makeDraggable(this.elements.wheel, (e) => {
            const rect = this.elements.wheel.getBoundingClientRect();
            const cx = rect.left + rect.width / 2;
            const cy = rect.top + rect.height / 2;
            let dx = e.clientX - cx;
            let dy = e.clientY - cy;
            
            let dist = Math.sqrt(dx*dx + dy*dy);
            const maxDist = rect.width / 2;
            if (dist > maxDist) dist = maxDist;

            this.state.s = dist / maxDist;
            let angle = Math.atan2(dy, dx) * 180 / Math.PI; // -180 to 180
            angle += 90; // Top is 0, clockwise
            if (angle < 0) angle += 360;
            this.state.h = angle / 360;
            this.updateUI();
        });

        // Val track
        makeDraggable(this.elements.valTrack, (e) => {
            const rect = this.elements.valTrack.getBoundingClientRect();
            let y = e.clientY - rect.top;
            if (y < 0) y = 0;
            if (y > rect.height) y = rect.height;
            this.state.v = 1 - (y / rect.height);
            this.updateUI();
        });


        // Sliders
        const onSliderChange = () => {
            this.state.h = parseInt(this.elements.hueSlider.value) / 360;
            this.state.s = parseInt(this.elements.satSlider.value) / 100;
            this.state.v = parseInt(this.elements.valSlider.value) / 100;
            this.updateUI();
        };

        this.elements.hueSlider.addEventListener('input', onSliderChange);
        this.elements.satSlider.addEventListener('input', onSliderChange);
        this.elements.valSlider.addEventListener('input', onSliderChange);

        this.elements.hueSlider.addEventListener('change', () => { if(window.triggerAutoSave) window.triggerAutoSave(); });
        this.elements.satSlider.addEventListener('change', () => { if(window.triggerAutoSave) window.triggerAutoSave(); });
        this.elements.valSlider.addEventListener('change', () => { if(window.triggerAutoSave) window.triggerAutoSave(); });

        // Hex input
        this.elements.valSlider.addEventListener('input', (e) => {
            this.state.v = parseInt(e.target.value) / 100;
            this.updateUI();
        });

        // RGB Slider events
        const updateFromRGB = () => {
            const r = parseInt(this.elements.rSlider.value) / 255;
            const g = parseInt(this.elements.gSlider.value) / 255;
            const b = parseInt(this.elements.bSlider.value) / 255;
            const hsv = this.RGBtoHSV(r, g, b);
            this.state.h = hsv[0];
            this.state.s = hsv[1];
            this.state.v = hsv[2];
            this.updateUI();
        };

        this.elements.rSlider.addEventListener('input', updateFromRGB);
        this.elements.gSlider.addEventListener('input', updateFromRGB);
        this.elements.bSlider.addEventListener('input', updateFromRGB);

        // Mode Toggles
        this.elements.btnHsv.addEventListener('click', () => {
            this.activeMode = 'HSV';
            this.elements.btnHsv.className = "px-4 py-1 rounded-md bg-surface-container-low text-primary-container font-label-caps text-label-caps shadow-sm";
            this.elements.btnRgb.className = "px-4 py-1 rounded-md text-on-surface-variant font-label-caps text-label-caps hover:text-on-surface transition-colors";
            this.elements.slidersHsv.classList.remove("hidden");
            this.elements.slidersRgb.classList.add("hidden");
        });

        this.elements.btnRgb.addEventListener('click', () => {
            this.activeMode = 'RGB';
            this.elements.btnRgb.className = "px-4 py-1 rounded-md bg-surface-container-low text-primary-container font-label-caps text-label-caps shadow-sm";
            this.elements.btnHsv.className = "px-4 py-1 rounded-md text-on-surface-variant font-label-caps text-label-caps hover:text-on-surface transition-colors";
            this.elements.slidersRgb.classList.remove("hidden");
            this.elements.slidersHsv.classList.add("hidden");
        });

        this.elements.hex.addEventListener('change', (e) => {
            const rgb = this.hexToRgb(e.target.value);
            if (rgb) {
                const hsv = this.RGBtoHSV(rgb[0], rgb[1], rgb[2]);
                this.state.h = hsv[0];
                this.state.s = hsv[1];
                this.state.v = hsv[2];
                this.updateUI();
                if(window.triggerAutoSave) window.triggerAutoSave();
            }
        });
    }

    static show(x, y, initialRGBA, onChange) {
        this.init();
        this.onChangeCb = onChange;
        
        // Parse initial
        const [r, g, b] = initialRGBA;
        const [h, s, v] = this.RGBtoHSV(r, g, b);
        this.state = { h, s, v, a: 1 };
        this.updateUI();

        // Position modal
        this.container.classList.remove("hidden");
        
        // Ensure it stays on screen
        const panelRect = this.panel.getBoundingClientRect();
        let posX = x + 10;
        let posY = y - 100;
        
        posX = Math.max(10, Math.min(posX, window.innerWidth - panelRect.width - 10));
        posY = Math.max(10, Math.min(posY, window.innerHeight - panelRect.height - 10));

        this.panel.style.left = posX + "px";
        this.panel.style.top = posY + "px";
    }

    static hide() {
        this.onChangeCb = null;
        if (this.container) {
            this.container.classList.add("hidden");
        }
    }
}

window.ColorPickerModal = ColorPickerModal;
