/* sRGB / CIELAB D50 conversion. Self-contained for AE expressions. */
function convertNodeColor(input, from, to) {
    function fail(message) { throw Error("Color Conversion: " + message); }
    function finiteNumber(x) { return typeof x === "number" && isFinite(x); }
    function clamp(x) { return Math.max(0, Math.min(1, x)); }
    function triple(x, length) {
        if (!x || typeof x === "string" || x.length !== length) fail("expected " + length + " numeric components");
        for (var i = 0; i < length; i++) if (!finiteNumber(x[i])) fail("components must be finite numbers");
    }
    function multiply(matrix, vector) {
        var result = [];
        for (var i = 0; i < 3; i++) result[i] = matrix[i][0]*vector[0] + matrix[i][1]*vector[1] + matrix[i][2]*vector[2];
        return result;
    }
    function decode(x) {
        var sign = x < 0 ? -1 : 1, a = Math.abs(x);
        return sign * (a <= 0.04045 ? a/12.92 : Math.pow((a+0.055)/1.055, 2.4));
    }
    function encode(x) {
        var sign = x < 0 ? -1 : 1, a = Math.abs(x);
        return sign * (a <= 0.0031308 ? a*12.92 : 1.055*Math.pow(a,1/2.4)-0.055);
    }
    var rgbToXYZ = [[506752/1228815,87881/245763,12673/70218], [87098/409605,175762/245763,12673/175545], [7918/409605,87881/737289,1001167/1053270]];
    var xyzToRGB = [[12831/3959,-329/214,-1974/3959], [-851781/878810,1648619/878810,36519/878810], [705/12673,-2585/12673,705/667]];
    var toD50 = [[1.0479298208405488,0.022946793341019088,-0.05019222954313557], [0.029627815688159344,0.990434484573249,-0.01707382502938514], [-0.009243058152591178,0.015055144896577895,0.7518742814281371]];
    var toD65 = [[0.9554734527042182,-0.023098536874261423,0.0632593086610217], [-0.028369706963208136,1.0099954580058226,0.021041398966943008], [0.012314001688319899,-0.020507696433477912,1.3303659366080753]];
    var white = [0.3457/0.3585,1,(1-0.3457-0.3585)/0.3585];
    var epsilon = 216/24389, kappa = 24389/27;
    function labF(x) { return x > epsilon ? Math.pow(x,1/3) : (kappa*x+16)/116; }
    function labInverse(x) { var cube=x*x*x; return cube > epsilon ? cube : (116*x-16)/kappa; }
    if (input != null && typeof input.value !== "undefined") input = input.value;
    var rgba, i;
    if (from === "RGB") {
        triple(input,4);
        rgba = [input[0],input[1],input[2],input[3]];
    } else if (from === "HEX") {
        if (typeof input !== "string") fail("HEX requires text");
        var hex = input.replace(/^\s+|\s+$/g, "").replace(/^#/, "");
        if (!/^(?:[a-fA-F0-9]{3}|[a-fA-F0-9]{6})$/.test(hex)) fail("use #RGB or #RRGGBB");
        if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
        rgba = [parseInt(hex.substr(0,2),16)/255,parseInt(hex.substr(2,2),16)/255,parseInt(hex.substr(4,2),16)/255,1];
    } else if (from === "HSL") {
        triple(input,3);
        var h = ((input[0]%360)+360)%360, s=input[1], l=input[2];
        if (s<0 || s>1 || l<0 || l>1) fail("HSL saturation/lightness must be 0-1");
        var c = (1-Math.abs(2*l-1))*s, x=c*(1-Math.abs((h/60)%2-1)), m=l-c/2;
        var sectors = [[c,x,0],[x,c,0],[0,c,x],[0,x,c],[x,0,c],[c,0,x]];
        var sector = sectors[Math.floor(h/60)];
        rgba = [sector[0]+m,sector[1]+m,sector[2]+m,1];
    } else if (from === "LAB") {
        triple(input,3);
        if (input[0]<0 || input[0]>100) fail("Lab lightness must be 0-100");
        var fy=(input[0]+16)/116;
        var xyz50=[labInverse(fy+input[1]/500)*white[0],labInverse(fy),labInverse(fy-input[2]/200)*white[2]];
        var linear=multiply(xyzToRGB,multiply(toD65,xyz50));
        rgba=[encode(linear[0]),encode(linear[1]),encode(linear[2]),1];
    } else fail("unknown input format");
    if (to === "RGB") return rgba;
    if (to === "HEX") {
        var out = "#";
        for (i=0;i<3;i++) { var channel=Math.round(clamp(rgba[i])*255).toString(16); out+=(channel.length<2?"0":"")+channel; }
        return out.toUpperCase();
    }
    for (i=0;i<3;i++) {
        if (rgba[i] < -0.000001 || rgba[i] > 1.000001) fail("HSL/LAB output requires RGB in 0-1; use RGB or HEX for out-of-gamut colors");
        rgba[i]=clamp(rgba[i]);
    }
    if (to === "HSL") {
        var r=rgba[0],g=rgba[1],b=rgba[2],max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min;
        var light=(max+min)/2, hue=0, saturation=0;
        if (d>0) {
            saturation=d/(1-Math.abs(2*light-1));
            if (max===r) hue=60*(((g-b)/d)%6);
            else if (max===g) hue=60*((b-r)/d+2);
            else hue=60*((r-g)/d+4);
            hue=(hue+360)%360;
        }
        return [hue,clamp(saturation),clamp(light)];
    }
    if (to === "LAB") {
        var xyz=multiply(toD50,multiply(rgbToXYZ,[decode(rgba[0]),decode(rgba[1]),decode(rgba[2])]));
        var fx=labF(xyz[0]/white[0]), fY=labF(xyz[1]), fz=labF(xyz[2]/white[2]);
        return [Math.max(0,Math.min(100,116*fY-16)),500*(fx-fY),200*(fY-fz)];
    }
    fail("unknown output format");
}
