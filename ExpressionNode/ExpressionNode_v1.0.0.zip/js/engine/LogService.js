const isDebugmode = false;

class LogService {
    static init() {
        if (!isDebugmode) return;
        
        // Nút Toggle
        const btnToggle = document.createElement("button");
        btnToggle.id = "btn-debug-console";
        btnToggle.className = "bg-error text-on-primary px-3 py-1 rounded shadow z-[9999] font-mono-label text-mono-label hover:bg-error/80 transition-colors";
        btnToggle.innerText = "Dev Console";
        (document.getElementById("panel-actions") || document.body).appendChild(btnToggle);

        // Màn hình Console
        const consoleContainer = document.createElement("div");
        consoleContainer.id = "debug-console";
        // Dùng CSS Transform để trượt ra vào. translate-x-full sẽ giấu nó sang bên phải.
        consoleContainer.className = "fixed top-0 right-0 w-96 h-full bg-[#1e1e1e] border-l border-outline-variant/30 z-[39] p-2 flex flex-col transition-transform duration-300 translate-x-full shadow-2xl";
        consoleContainer.innerHTML = `
            <div class="h-8 border-b border-outline-variant/30 flex justify-between items-center shrink-0 mb-2">
                <span class="font-mono-label text-mono-label text-[#4af626]">Console Debugger</span>
                <button id="btn-clear-console" class="text-on-surface-variant hover:text-error material-symbols-outlined text-[16px]">delete</button>
            </div>
            <div id="debug-logs" class="flex-1 overflow-y-auto font-mono text-[11px] text-on-surface-variant break-all space-y-1 pb-10 select-text"></div>
        `;
        document.body.appendChild(consoleContainer);

        // Logic Toggle
        let isConsoleOpen = false;
        btnToggle.addEventListener("click", () => {
            isConsoleOpen = !isConsoleOpen;
            if (isConsoleOpen) {
                window.dispatchEvent(new Event("debug-console-opened"));
                consoleContainer.classList.remove("translate-x-full");
            } else {
                consoleContainer.classList.add("translate-x-full");
            }
        });

        window.addEventListener("shortcut-help-opened", () => {
            isConsoleOpen = false;
            consoleContainer.classList.add("translate-x-full");
        });

        document.getElementById("btn-clear-console").addEventListener("click", () => {
            document.getElementById("debug-logs").innerHTML = "";
        });

        // Ghi đè phương thức console.log        // Override console methods
        const originalLog = console.log;
        const originalWarn = console.warn;
        const originalError = console.error;

        console.log = (...args) => {
            originalLog(...args);
            this.print("LOG", args);
        };

        console.warn = (...args) => {
            originalWarn(...args);
            this.print("WARN", args);
        };

        console.error = (...args) => {
            originalError(...args);
            this.print("ERROR", args);
        };

        // Catch unhandled errors
        window.addEventListener("error", (e) => {
            this.print("ERROR", ["Unhandled Exception:", e.message, "at", e.filename + ":" + e.lineno]);
        });

        window.addEventListener("unhandledrejection", (e) => {
            this.print("ERROR", ["Unhandled Promise Rejection:", e.reason]);
        });
        
        console.log("LogService Initialized. isDebugmode:", isDebugmode);
    }

    static print(type, args) {
        const logsDiv = document.getElementById("debug-logs");
        if (!logsDiv) return;

        // Chuyển object thành string để in
        const msg = args.map(a => typeof a === 'object' ? JSON.stringify(a) : a).join(" ");
        const el = document.createElement("div");
        const color = type === "ERROR" ? "text-error font-bold" : "text-[#4af626]";
        
        const now = new Date();
        const time = `${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}.${now.getMilliseconds()}`;

        el.textContent = `[${time}] ${msg}`;
        el.className = color;
        logsDiv.appendChild(el);
        logsDiv.scrollTop = logsDiv.scrollHeight;
    }
}

// Chạy khởi tạo ngay khi tải xong DOM
document.addEventListener("DOMContentLoaded", () => {
    LogService.init();
});
