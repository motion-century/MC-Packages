class RandomNode extends Node {
  constructor() {
    super("Random", {
      width: 180,
      headerBgClass: "bg-[#e53935]", // Đỏ cho Randomizer
      headerBorderClass: "border-[#e53935]/30",
      headerTextClass: "text-[#ffebee]",
    });

    this.group = "Randomizer";
    this.icon = "shuffle";

    const portMin = this.addInput("", "ANY_NUM");
    const portMax = this.addInput("", "ANY_NUM");
    const portOut = this.addOutput("", "ANY");

    portMin.el.remove();
    portMax.el.remove();
    portOut.el.remove();

    const container = document.createElement("div");
    container.className = "flex flex-col space-y-2 mb-2 gap-2 mt-2";

    // Method Dropdown
    this.methodSelect = document.createElement("select");
    this.methodSelect.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none";
    
    const methods = [
      { value: "random", text: "Random" },
      { value: "gaussRandom", text: "Gauss Random" }
    ];

    methods.forEach(m => {
      const option = document.createElement("option");
      option.value = m.value;
      option.innerText = m.text;
      this.methodSelect.appendChild(option);
    });

    container.appendChild(this.methodSelect);

    const createInputRow = (port, labelText, defaultValue, hasPort = false) => {
        const row = document.createElement("div");
        row.className = "w-full flex items-center relative";
        
        if (hasPort) {
            port.el.className = "relative flex items-center";
            row.appendChild(port.el);
        }
        
        const label = document.createElement("span");
        label.className = `font-label-caps text-label-caps text-on-surface-variant w-10 text-left ${hasPort ? 'mx-1' : 'mr-1'}`;
        label.innerText = labelText;
        row.appendChild(label);

        const input = document.createElement("input");
        input.className = "flex-1 min-w-0 bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
        input.type = "text";
        input.value = defaultValue;
        row.appendChild(input);

        UIUtils.makeInputDraggable(input);
        return { row, input };
    };

    // Min / Max Inputs
    this.inputsWrapper = document.createElement("div");
    this.inputsWrapper.className = "flex flex-col space-y-2 w-full";
    this.rowMin = createInputRow(portMin, "Min", "0", true);
    this.rowMax = createInputRow(portMax, "Max", "100", true);
    this.inputsWrapper.appendChild(this.rowMin.row);
    this.inputsWrapper.appendChild(this.rowMax.row);
    container.appendChild(this.inputsWrapper);

    // Seed Settings
    const seedContainer = document.createElement("div");
    seedContainer.className = "flex flex-col space-y-2 mt-2 pt-2 border-t border-outline-variant/30 gap-2";

    this.state = { useSeed: false, timeless: false };

    const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;

    // Use Seed Checkbox
    const seedWrapper = document.createElement("div");
    seedWrapper.className = "flex items-center space-x-2 cursor-pointer group";
    this.iconSeed = document.createElement("div");
    this.iconSeed.innerHTML = inactiveSVG;
    
    const seedLabel = document.createElement("span");
    seedLabel.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
    seedLabel.innerText = "Use Seed";
    
    seedWrapper.appendChild(this.iconSeed);
    seedWrapper.appendChild(seedLabel);
    seedContainer.appendChild(seedWrapper);

    // Seed Options (Offset & Timeless)
    this.seedOptsWrapper = document.createElement("div");
    this.seedOptsWrapper.className = "flex flex-col space-y-2 pl-6 hidden";

    // Offset Input
    const offsetRow = document.createElement("div");
    offsetRow.className = "flex items-center space-x-2";
    const offsetLabel = document.createElement("span");
    offsetLabel.className = "font-label-caps text-label-caps text-on-surface-variant w-10 text-left";
    offsetLabel.innerText = "Offset";
    this.offsetInput = document.createElement("input");
    this.offsetInput.className = "flex-1 min-w-0 bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
    this.offsetInput.type = "text";
    this.offsetInput.value = "1";
    UIUtils.makeInputDraggable(this.offsetInput);
    offsetRow.appendChild(offsetLabel);
    offsetRow.appendChild(this.offsetInput);
    this.seedOptsWrapper.appendChild(offsetRow);

    // Timeless Checkbox
    const timelessWrapper = document.createElement("div");
    timelessWrapper.className = "flex items-center space-x-2 cursor-pointer group mt-1";
    this.iconTimeless = document.createElement("div");
    this.iconTimeless.innerHTML = inactiveSVG;
    const timelessLabel = document.createElement("span");
    timelessLabel.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
    timelessLabel.innerText = "Timeless";
    timelessWrapper.appendChild(this.iconTimeless);
    timelessWrapper.appendChild(timelessLabel);
    this.seedOptsWrapper.appendChild(timelessWrapper);

    seedContainer.appendChild(this.seedOptsWrapper);
    container.appendChild(seedContainer);

    // Output row
    const outRow = document.createElement("div");
    outRow.className = "w-full flex justify-end items-center relative mt-2 pt-2 border-t border-outline-variant/30";
    portOut.el.className = "relative flex items-center";
    outRow.appendChild(portOut.el);
    container.appendChild(outRow);

    this.bodyEl.appendChild(container);

    const updateCheckboxes = () => {
        this.iconSeed.innerHTML = this.state.useSeed ? activeSVG : inactiveSVG;
        this.iconTimeless.innerHTML = this.state.timeless ? activeSVG : inactiveSVG;
        if (this.state.useSeed) {
            this.seedOptsWrapper.classList.remove("hidden");
        } else {
            this.seedOptsWrapper.classList.add("hidden");
        }
        this.updatePosition();
    };

    seedWrapper.addEventListener("click", () => {
        this.state.useSeed = !this.state.useSeed;
        updateCheckboxes();
        if (window.triggerAutoSave) window.triggerAutoSave();
    });
    timelessWrapper.addEventListener("click", () => {
        this.state.timeless = !this.state.timeless;
        updateCheckboxes();
        if (window.triggerAutoSave) window.triggerAutoSave();
    });
    this.methodSelect.addEventListener("change", () => {
        if (window.triggerAutoSave) window.triggerAutoSave();
    });
  }

  onConnectionChanged(port) {
    if (port === this.inputs[0]) {
        if (port.wires.length > 0) this.rowMin.input.classList.add("hidden");
        else this.rowMin.input.classList.remove("hidden");
    } else if (port === this.inputs[1]) {
        if (port.wires.length > 0) this.rowMax.input.classList.add("hidden");
        else this.rowMax.input.classList.remove("hidden");
    }
    this.updatePosition();
  }

  getValues() {
    return [
        this.methodSelect.value,
        this.rowMin.input.value,
        this.rowMax.input.value,
        this.state.useSeed,
        this.offsetInput.value,
        this.state.timeless
    ];
  }

  setValues(values) {
    if (values && values.length >= 6) {
      this.methodSelect.value = values[0];
      this.rowMin.input.value = values[1];
      this.rowMax.input.value = values[2];
      this.state.useSeed = values[3];
      this.offsetInput.value = values[4];
      this.state.timeless = values[5];
      
      const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
      const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;
      this.iconSeed.innerHTML = this.state.useSeed ? activeSVG : inactiveSVG;
      this.iconTimeless.innerHTML = this.state.timeless ? activeSVG : inactiveSVG;
      if (this.state.useSeed) {
          this.seedOptsWrapper.classList.remove("hidden");
      } else {
          this.seedOptsWrapper.classList.add("hidden");
      }
    }
  }
}
