class InterpolationNode extends Node {
  constructor() {
    super("Interpolation", {
      width: 220,
      headerBgClass: "bg-node-math",
      headerBorderClass: "border-node-math/30",
      headerTextClass: "text-[#e3f2fd]",
    });

    this.group = "Math";
    this.icon = "animation";

    const portT = this.addInput("", "1D");
    const portTMin = this.addInput("", "1D");
    const portTMax = this.addInput("", "1D");
    const portVal1 = this.addInput("", "ANY_NUM");
    const portVal2 = this.addInput("", "ANY_NUM");
    const portOut = this.addOutput("", "ANY");

    portT.el.remove();
    portTMin.el.remove();
    portTMax.el.remove();
    portVal1.el.remove();
    portVal2.el.remove();
    portOut.el.remove();

    const container = document.createElement("div");
    container.className = "flex flex-col space-y-2 mb-2 gap-2 mt-2";

    // Method Dropdown
    this.methodSelect = document.createElement("select");
    this.methodSelect.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none";
    
    const methods = [
      { value: "linear", text: "Linear" },
      { value: "ease", text: "Ease" },
      { value: "easeIn", text: "Ease In" },
      { value: "easeOut", text: "Ease Out" }
    ];

    methods.forEach(m => {
      const option = document.createElement("option");
      option.value = m.value;
      option.innerText = m.text;
      this.methodSelect.appendChild(option);
    });

    container.appendChild(this.methodSelect);

    const createInputRow = (port, labelText, defaultValue) => {
        const row = document.createElement("div");
        row.className = "w-full flex items-center relative";
        port.el.className = "relative flex items-center";
        row.appendChild(port.el);
        
        const label = document.createElement("span");
        label.className = "font-label-caps text-label-caps text-on-surface-variant w-12 text-left mx-1";
        label.innerText = labelText;
        row.appendChild(label);

        const input = document.createElement("input");
        input.className = "flex-1 min-w-0 bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
        input.type = "text";
        input.value = defaultValue;
        row.appendChild(input);

        UIUtils.makeInputDraggable(input);
        return { row, input };
    };

    const createDivider = (text) => {
        const wrap = document.createElement("div");
        wrap.className = "flex items-center space-x-2 my-1";
        const hr1 = document.createElement("hr");
        hr1.className = "flex-1 border-outline-variant/30";
        wrap.appendChild(hr1);
        if (text) {
            const span = document.createElement("span");
            span.className = "font-mono-label text-[9px] text-on-surface-variant uppercase";
            span.innerText = text;
            wrap.appendChild(span);
            const hr2 = document.createElement("hr");
            hr2.className = "flex-1 border-outline-variant/30";
            wrap.appendChild(hr2);
        }
        return wrap;
    };

    this.rowT = createInputRow(portT, "t", "0");
    container.appendChild(this.rowT.row);
    
    container.appendChild(createDivider(""));

    this.rowTMin = createInputRow(portTMin, "t Min", "0");
    container.appendChild(this.rowTMin.row);

    this.rowTMax = createInputRow(portTMax, "t Max", "1");
    container.appendChild(this.rowTMax.row);

    container.appendChild(createDivider("to"));

    this.rowVal1 = createInputRow(portVal1, "Value 1", "0");
    container.appendChild(this.rowVal1.row);

    this.rowVal2 = createInputRow(portVal2, "Value 2", "100");
    container.appendChild(this.rowVal2.row);

    // Output row
    const outRow = document.createElement("div");
    outRow.className = "w-full flex justify-end items-center relative mt-2 pt-2 border-t border-outline-variant/30";
    portOut.el.className = "relative flex items-center";
    outRow.appendChild(portOut.el);
    container.appendChild(outRow);

    this.bodyEl.appendChild(container);

    this.methodSelect.addEventListener("change", () => {
      if (window.triggerAutoSave) window.triggerAutoSave();
    });
  }

  onConnectionChanged(port) {
    if (port === this.inputs[0]) {
        if (port.wires.length > 0) this.rowT.input.classList.add("hidden");
        else this.rowT.input.classList.remove("hidden");
    } else if (port === this.inputs[1]) {
        if (port.wires.length > 0) this.rowTMin.input.classList.add("hidden");
        else this.rowTMin.input.classList.remove("hidden");
    } else if (port === this.inputs[2]) {
        if (port.wires.length > 0) this.rowTMax.input.classList.add("hidden");
        else this.rowTMax.input.classList.remove("hidden");
    } else if (port === this.inputs[3]) {
        if (port.wires.length > 0) this.rowVal1.input.classList.add("hidden");
        else this.rowVal1.input.classList.remove("hidden");
    } else if (port === this.inputs[4]) {
        if (port.wires.length > 0) this.rowVal2.input.classList.add("hidden");
        else this.rowVal2.input.classList.remove("hidden");
    }
    this.updatePosition();
  }

  getValues() {
    return [
        this.methodSelect.value,
        this.rowT.input.value,
        this.rowTMin.input.value,
        this.rowTMax.input.value,
        this.rowVal1.input.value,
        this.rowVal2.input.value
    ];
  }

  setValues(values) {
    if (values && values.length >= 6) {
      this.methodSelect.value = values[0];
      this.rowT.input.value = values[1];
      this.rowTMin.input.value = values[2];
      this.rowTMax.input.value = values[3];
      this.rowVal1.input.value = values[4];
      this.rowVal2.input.value = values[5];
    }
  }
}
