/**
 * Custom Nodes
 * Kế thừa từ Node cơ bản và thiết kế lại giao diện Body
 */

class MathNode extends Node {
  constructor() {
    super("Math", {
      width: 180,
      headerBgClass: "bg-node-math/20",
      headerBorderClass: "border-node-math/30",
      headerTextClass: "text-node-math",
    });

    // Xóa cổng mặc định nếu có, tạo cổng thật
    this.addInput("Value", "1D");
    this.addOutput("", "1D"); // Output port không cần label hiển thị

    // Render thêm DOM dropdown (Thẻ select thật để getValues đọc được)
    const controlDiv = document.createElement("div");
    controlDiv.className = "mt-2";
    controlDiv.innerHTML = `
            <select class="w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none">
                <option value="Add">Add</option>
                <option value="Subtract">Subtract</option>
                <option value="Multiply">Multiply</option>
                <option value="Divide">Divide</option>
            </select>
        `;

    const inputDiv = document.createElement("div");
    inputDiv.className = "flex items-center space-x-2 mt-2";
    inputDiv.innerHTML = `
            <input class="w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface focus:border-secondary focus:ring-0" type="number" value="0">
        `;

    this.bodyEl.appendChild(controlDiv);
    this.bodyEl.appendChild(inputDiv);
  }
}

function createSearchableDropdown(placeholder) {
  const container = document.createElement("div");
  container.className = "relative w-1/2 flex items-center";

  const btn = document.createElement("button");
  btn.className =
    "w-full text-left truncate bg-transparent text-on-surface font-mono-label text-[11px] focus:outline-none cursor-pointer hover:bg-surface-variant/50 rounded px-1 py-0.5 transition-colors";
  btn.innerText = placeholder;

  const menu = document.createElement("div");
  menu.className =
    "hidden absolute top-full left-0 mt-1 w-48 bg-surface-container-low/95 backdrop-blur-md rounded shadow-[0_8px_24px_rgba(0,0,0,0.5)] border border-outline-variant/30 flex flex-col z-[100]";

  const searchHeader = document.createElement("div");
  searchHeader.className = "p-1 border-b border-outline-variant/30 relative";
  searchHeader.innerHTML = `
        <span class="material-symbols-outlined absolute left-2 top-1/2 -translate-y-1/2 text-on-surface-variant text-[14px]">search</span>
        <input class="w-full bg-surface-container-lowest/50 text-on-surface font-body-sm text-[11px] pl-6 pr-2 py-1 rounded border border-transparent focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none transition-colors placeholder:text-on-surface-variant/50" placeholder="Search..." type="text"/>
    `;

  const listContainer = document.createElement("div");
  listContainer.className =
    "p-1 flex flex-col gap-0.5 max-h-[160px] overflow-y-auto custom-scrollbar";

  menu.appendChild(searchHeader);
  menu.appendChild(listContainer);
  container.appendChild(btn);
  container.appendChild(menu);

  let isOpen = false;
  let options = [];
  let currentValue = "";
  const searchInput = searchHeader.querySelector("input");

  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    isOpen = !isOpen;
    if (isOpen) {
      // Đóng các dropdown khác
      document
        .querySelectorAll(".searchable-dropdown-menu")
        .forEach((el) => el.classList.add("hidden"));
      menu.classList.remove("hidden");
      searchInput.value = "";
      renderList(options);
      setTimeout(() => searchInput.focus(), 50);
    } else {
      menu.classList.add("hidden");
    }
  });

  menu.classList.add("searchable-dropdown-menu");

  searchInput.addEventListener("input", (e) => {
    const query = e.target.value.toLowerCase();
    renderList(options.filter((o) => o.label.toLowerCase().includes(query)));
  });

  searchInput.addEventListener("click", (e) => e.stopPropagation());
  listContainer.addEventListener("click", (e) => e.stopPropagation());

  const closeMenu = () => {
    if (isOpen) {
      isOpen = false;
      menu.classList.add("hidden");
    }
  };
  document.addEventListener("click", closeMenu);

  let onChangeCb = null;

  const renderList = (items) => {
    listContainer.innerHTML = "";
    items.forEach((item) => {
      const btnItem = document.createElement("button");
      btnItem.className =
        "w-full text-left px-2 py-1.5 rounded font-body-md text-body-md text-on-surface hover:bg-primary-container/20 hover:text-primary transition-colors flex items-center justify-between group";
      btnItem.innerHTML = `<span class="truncate">${item.label}</span>`;
      if (item.value === currentValue)
        btnItem.classList.add("bg-primary-container/20", "text-primary");

      btnItem.addEventListener("click", (e) => {
        e.stopPropagation();
        currentValue = item.value;
        btn.innerText = item.label;
        btn.title = item.label; // Tooltip in case it's long
        isOpen = false;
        menu.classList.add("hidden");
        if (onChangeCb) onChangeCb(currentValue);
      });
      listContainer.appendChild(btnItem);
    });
  };

  return {
    container,
    dispose: () => { document.removeEventListener("click", closeMenu); closeMenu(); onChangeCb = null; },
    setValue: (val, label) => {
      currentValue = val;
      btn.innerText = label || val;
      btn.title = label || val;
    },
    getValue: () => currentValue,
    setOptions: (opts) => {
      options = opts;
      renderList(opts);
    },
    onChange: (cb) => (onChangeCb = cb),
  };
}

const escapeAEString = (str) => {
  return str
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/\n/g, "\\n")
    .replace(/\r/g, "\\r");
};

class SourceLayerNode extends Node {
  constructor() {
    super("Source Layer", {
      width: 240,
      headerBgClass: "bg-[#0f4a7a]", // Blue color for source
      headerBorderClass: "border-primary/30",
      headerTextClass: "text-[#cce4ff]",
    });

    const uiContainer = document.createElement("div");
    uiContainer.className =
      "flex items-center space-x-1 mt-2 mb-3 bg-surface-dim p-1 rounded border border-outline-variant relative";

    this.compDropdown = createSearchableDropdown("This Comp");
    const slash = document.createElement("span");
    slash.innerText = "/";
    slash.className = "text-outline-variant font-bold text-[11px]";
    this.layerDropdown = createSearchableDropdown("-- Select Layer --");

    uiContainer.appendChild(this.compDropdown.container);
    uiContainer.appendChild(slash);
    uiContainer.appendChild(this.layerDropdown.container);

    // Thêm port Layer (loại LAYER) ngay trong container
    this.layerOutputPort = this.addOutput("Layer", "LAYER", "");
    this.layerOutputPort.el.remove();
    this.layerOutputPort.el.className = "absolute right-[-6px] top-1/2 -translate-y-1/2 z-20";
    uiContainer.appendChild(this.layerOutputPort.el);

    this.bodyEl.appendChild(uiContainer);

    this.propsContainer = document.createElement("div");
    this.propsContainer.className = "flex flex-col mt-2 space-y-1";
    this.bodyEl.appendChild(this.propsContainer);

    this.fetchedData = { activeCompId: -1, comps: [] };
    this._savedGroupStates = {};
    this.cachedTreeData = [];

    this.refreshData();

    this.compDropdown.onChange((val) => {
      this.updateLayerDropdown();
      this.checkErrorState();
      if (window.triggerAutoSave) window.triggerAutoSave();
    });

    this.layerDropdown.onChange((val) => {
      this.checkErrorState();

      // Kích hoạt cơ chế Sync cho tất cả các node khác khi đổi Layer
      if (window.graph) {
        window.graph.nodes.forEach((node) => {
          if (typeof node.refreshData === "function" && node !== this) {
            node.refreshData();
          }
        });
      }

      if (window.triggerAutoSave) window.triggerAutoSave();
    });
  }

  refreshData() {
    if (!window.csInterface || this.disposed) return;
    this.requestVersion++;
    this.requestHost(`getCompsAndLayers(${JSON.stringify(window.graphSession ? window.graphSession.owner : "")})`, (res) => {
      try {
        this.fetchedData = JSON.parse(res);

        const currentComp = this.compDropdown.getValue() || "THIS_COMP";
        const currentLayer = this.layerDropdown.getValue();

        let compOpts = [{ value: "THIS_COMP", label: "This Comp" }];
        this.fetchedData.comps.forEach((c) => {
          compOpts.push({ value: c.name, label: c.name });
        });

        if (currentComp && !compOpts.find((o) => o.value === currentComp)) {
          compOpts.push({ value: currentComp, label: currentComp });
        }
        this.compDropdown.setOptions(compOpts);
        this.compDropdown.setValue(
          currentComp,
          compOpts.find((o) => o.value === currentComp)?.label || currentComp,
        );

        this.updateLayerDropdown(currentLayer);

        const updatedComp = this.compDropdown.getValue() || "THIS_COMP";
        const updatedLayer = this.layerDropdown.getValue();
        if (updatedComp && updatedLayer) {
          const safeComp = escapeAEString(updatedComp);
          const safeLayer = escapeAEString(updatedLayer);
          this.requestHost(
            `getLayerPropertyTree("${safeComp}", "${safeLayer}", ${JSON.stringify(window.graphSession ? window.graphSession.owner : "")})`,
            (treeRes) => {
              try {
                const data = JSON.parse(treeRes);
                this.cachedTreeData = data.properties || [];
                this.renderPropertyTree(this.cachedTreeData);
              } catch (e) {
                console.error("Parse property tree error", e);
              }
            },
          );
        } else {
          this.cachedTreeData = [];
          this.renderPropertyTree([]);
        }
      } catch (e) {
        console.error("Parse comp data error", e);
      }
    });
  }

  updateLayerDropdown(preserveLayer) {
    const compVal = this.compDropdown.getValue();
    let targetComp = null;
    if (compVal === "THIS_COMP") {
      targetComp = this.fetchedData.comps.find(
        (c) => c.id === this.fetchedData.activeCompId,
      );
    } else {
      targetComp = this.fetchedData.comps.find((c) => c.name === compVal);
    }

    let layerOpts = [];
    if (targetComp) {
      targetComp.layers.forEach((l) => {
        layerOpts.push({ value: l.name, label: l.name }); // Use name as value for expressions
      });
    }

    if (preserveLayer && !layerOpts.find((o) => o.value === preserveLayer)) {
      layerOpts.push({ value: preserveLayer, label: preserveLayer });
    }

    this.layerDropdown.setOptions(layerOpts);

    if (preserveLayer) {
      this.layerDropdown.setValue(
        preserveLayer,
        layerOpts.find((o) => o.value === preserveLayer)?.label ||
          preserveLayer,
      );
    } else if (layerOpts.length > 0) {
      this.layerDropdown.setValue(layerOpts[0].value, layerOpts[0].label);
    } else {
      this.layerDropdown.setValue("", "-- Select Layer --");
    }
  }

  checkErrorState() {
    const compVal = this.compDropdown.getValue();
    const layerVal = this.layerDropdown.getValue();

    let isError = false;
    let targetComp = null;
    if (compVal === "THIS_COMP") {
      targetComp = this.fetchedData.comps.find(
        (c) => c.id === this.fetchedData.activeCompId,
      );
    } else {
      targetComp = this.fetchedData.comps.find((c) => c.name === compVal);
    }

    if (!targetComp) {
      isError = true;
    } else {
      const layerExists = targetComp.layers.find((l) => l.name === layerVal);
      if (!layerExists) isError = true;
    }

    if (isError) {
      this.el.classList.add("border-error");
      this.el.classList.add("bg-error-container/20");
    } else {
      this.el.classList.remove("border-error");
      this.el.classList.remove("bg-error-container/20");
    }
  }

  renderPropertyTree(properties) {
    const oldWires = [];
    this.outputs.forEach((p) => {
      if (p.name !== "Layer") {
        p.wires.forEach((w) => oldWires.push(w));
        p.el.remove();
      }
    });

    this.outputs = this.outputs.filter((p) => p.name === "Layer");
    this.propsContainer.innerHTML = "";

    const buildTree = (items, container, pathPrefix, isRoot) => {
      // Sort items so Transform is first
      if (isRoot) {
        items.sort((a, b) => {
          if (a.matchName === "ADBE Transform Group") return -1;
          if (b.matchName === "ADBE Transform Group") return 1;
          return 0;
        });
      }

      items.forEach((item) => {
        const currentPath = pathPrefix
          ? `${pathPrefix}/${item.matchName}`
          : item.matchName;

        if (item.type === "PROPERTY") {
          const port = this.addOutput(currentPath, item.portType, item.name);
          container.appendChild(port.el);
        } else if (item.type === "GROUP") {
          if (isRoot && item.matchName === "ADBE Transform Group") {
            const hr = document.createElement("hr");
            hr.className = "border-outline-variant/30 my-2 w-[90%] mx-auto";
            container.appendChild(hr);

            const label = document.createElement("div");
            label.className =
              "text-[10px] font-mono-label text-on-surface-variant mb-1 px-1";
            label.innerText = item.name;
            container.appendChild(label);

            buildTree(item.children, container, currentPath, false);

            const hr2 = document.createElement("hr");
            hr2.className = "border-outline-variant/30 my-2 w-[90%] mx-auto";
            container.appendChild(hr2);
            return;
          }

          const details = document.createElement("details");
          details.className =
            "group border border-outline-variant/30 rounded bg-surface-dim/30 my-1";

          if (this._savedGroupStates[currentPath]) {
            details.open = true;
          }

          const summary = document.createElement("summary");
          summary.className =
            "cursor-pointer bg-surface-dim/50 px-2 py-1 text-[10px] font-bold text-on-surface select-none flex items-center justify-between hover:bg-surface-variant/50 transition-colors relative";
          summary.innerHTML = `
            <span class="truncate pr-2">${item.name}</span>
            <span class="material-symbols-outlined text-[12px] transition-transform group-open:rotate-180">expand_more</span>
            <div class="summary-port absolute right-[-5px] w-2 h-2 rounded-full bg-port-1d border border-outline-variant/80 block" style="top: 50%; transform: translateY(-50%);"></div>
          `;

          details.addEventListener("toggle", () => {
            this._savedGroupStates[currentPath] = details.open;
            if (window.graph) {
              requestAnimationFrame(() =>
                window.graph.wires.forEach((w) => w.updatePath()),
              );
            }
            if (window.triggerAutoSave) window.triggerAutoSave();
          });

          const childrenContainer = document.createElement("div");
          childrenContainer.className =
            "p-1 flex flex-col pl-2 border-l border-outline-variant/20 ml-1";

          buildTree(item.children, childrenContainer, currentPath, false);

          details.appendChild(summary);
          details.appendChild(childrenContainer);
          container.appendChild(details);
        }
      });
    };

    buildTree(properties, this.propsContainer, "", true);

    this.outputs.forEach((p) => {
      const matchingWires = oldWires.filter(
        (w) => w.sourcePort && w.sourcePort.name === p.name,
      );
      matchingWires.forEach((w) => {
        w.sourcePort = p;
        p.wires.push(w);
        w.updatePath();
      });
    });

    oldWires.forEach((w) => {
      if (w.sourcePort && !this.outputs.find((p) => p === w.sourcePort)) {
        if (window.graph) window.graph.removeWire(w);
      }
    });

    this.updatePosition();
    if (window.graph && window.graph.resolvePendingWires) {
      window.graph.resolvePendingWires();
    }
  }

  getValues() {
    return [
      this.compDropdown.getValue(),
      this.layerDropdown.getValue(),
      this._savedGroupStates,
      this.cachedTreeData,
    ];
  }

  setValues(values) {
    if (values && values.length >= 2) {
      this.compDropdown.setValue(values[0], values[0]);
      this.layerDropdown.setValue(values[1], values[1]);

      if (values.length >= 4) {
        this._savedGroupStates = values[2] || {};
        this.cachedTreeData = values[3] || [];
        if (this.cachedTreeData.length > 0) {
          this.renderPropertyTree(this.cachedTreeData);
        }
      }
      this.refreshData(); // Fetch live just in case
    }
  }
}

class TargetLayerNode extends Node {
  constructor() {
    super("Target Layer", {
      width: 220,
      headerBgClass: "bg-primary/20",
      headerBorderClass: "border-primary/30",
      headerTextClass: "text-primary",
      nodeBorderClass: "border-primary",
      nodeBgClass: "bg-surface-container-lowest/90",
    });

    this._savedGroupStates = {};
    this.cachedTreeData = [];

    this.propsContainer = document.createElement("div");
    this.propsContainer.className = "flex flex-col mt-2 space-y-1";
    this.bodyEl.appendChild(this.propsContainer);

    // Property requests are scoped to the graph owner and node lifetime.

    this.refreshData();
  }

  applyTargetColor(isSuccess) {
    if (!this.el) return;
    if (isSuccess) {
      this.el.classList.remove("border-primary");
      this.el.classList.add("border-[var(--color-success)]");
      this.el.style.borderColor = "#00E676";
      this.el.style.boxShadow = "0 0 15px rgba(0, 230, 118, 0.4)";
      setTimeout(() => {
        this.el.classList.remove("border-[var(--color-success)]");
        this.el.classList.add("border-primary");
        this.el.style.borderColor = "";
        this.el.style.boxShadow = "";
      }, 1000);
    }
  }

  refreshData() {
    if (!window.csInterface || this.disposed) return;
    this.requestVersion++;
    const owner = window.graphSession && window.graphSession.owner;
    if (!owner) return;
    this.requestHost("getOwnerPropertyTree(" + JSON.stringify(owner) + ")", res => {
      const data = JSON.parse(res);
      if (data.error) throw Error(data.error);
      this.cachedTreeData = data.properties || [];
      this.renderPropertyTree(this.cachedTreeData);
    });
  }

  renderPropertyTree(properties) {
    const oldWires = [];
    this.inputs.forEach((p) => {
      p.wires.forEach((w) => oldWires.push(w));
      p.el.remove();
    });

    this.inputs = [];
    this.propsContainer.innerHTML = "";

    const buildTree = (items, container, pathPrefix, isRoot) => {
      // Sort items so Transform is first
      if (isRoot) {
        items.sort((a, b) => {
          if (a.matchName === "ADBE Transform Group") return -1;
          if (b.matchName === "ADBE Transform Group") return 1;
          return 0;
        });
      }

      items.forEach((item) => {
        const currentPath = pathPrefix
          ? `${pathPrefix}/${item.matchName}`
          : item.matchName;

        if (item.type === "PROPERTY") {
          const port = this.addInput(currentPath, item.portType, item.name);
          container.appendChild(port.el);
        } else if (item.type === "GROUP") {
          if (isRoot && item.matchName === "ADBE Transform Group") {
            const hr = document.createElement("hr");
            hr.className = "border-outline-variant/30 my-2 w-[90%] mx-auto";
            container.appendChild(hr);

            const label = document.createElement("div");
            label.className =
              "text-[10px] font-mono-label text-on-surface-variant mb-1 px-1";
            label.innerText = item.name;
            container.appendChild(label);

            buildTree(item.children, container, currentPath, false);

            const hr2 = document.createElement("hr");
            hr2.className = "border-outline-variant/30 my-2 w-[90%] mx-auto";
            container.appendChild(hr2);
            return;
          }

          const details = document.createElement("details");
          details.className =
            "group border border-outline-variant/30 rounded bg-surface-dim/30 my-1";

          if (this._savedGroupStates[currentPath]) {
            details.open = true;
          }

          const summary = document.createElement("summary");
          summary.className =
            "cursor-pointer bg-surface-dim/50 px-2 py-1 text-[10px] font-bold text-on-surface select-none flex items-center justify-between hover:bg-surface-variant/50 transition-colors relative";
          summary.innerHTML = `
            <div class="summary-port absolute left-[-5px] w-2 h-2 rounded-full bg-port-1d border border-outline-variant/80 block" style="top: 50%; transform: translateY(-50%);"></div>
            <span class="truncate pr-2">${item.name}</span>
            <span class="material-symbols-outlined text-[12px] transition-transform group-open:rotate-180">expand_more</span>
          `;

          details.addEventListener("toggle", () => {
            this._savedGroupStates[currentPath] = details.open;
            if (window.graph) {
              requestAnimationFrame(() =>
                window.graph.wires.forEach((w) => w.updatePath()),
              );
            }
            if (window.triggerAutoSave) window.triggerAutoSave();
          });

          const childrenContainer = document.createElement("div");
          childrenContainer.className =
            "p-1 flex flex-col pl-2 border-l border-outline-variant/20 ml-1";

          buildTree(item.children, childrenContainer, currentPath, false);

          details.appendChild(summary);
          details.appendChild(childrenContainer);
          container.appendChild(details);
        }
      });
    };

    buildTree(properties, this.propsContainer, "", true);

    this.inputs.forEach((p) => {
      const matchingWires = oldWires.filter(
        (w) => w.targetPort && w.targetPort.name === p.name,
      );
      matchingWires.forEach((w) => {
        w.targetPort = p;
        p.wires.push(w);
        w.updatePath();
      });
    });

    oldWires.forEach((w) => {
      if (w.targetPort && !this.inputs.find((p) => p === w.targetPort)) {
        if (window.graph) window.graph.removeWire(w);
      }
    });

    this.updatePosition();
    if (window.graph && window.graph.resolvePendingWires) {
      window.graph.resolvePendingWires();
    }
  }

  getValues() {
    return [this._savedGroupStates, this.cachedTreeData];
  }

  setValues(values) {
    if (values && values.length >= 2) {
      this._savedGroupStates = values[0] || {};
      this.cachedTreeData = values[1] || [];
      if (this.cachedTreeData.length > 0) {
        this.renderPropertyTree(this.cachedTreeData);
      }
    }
  }
}
