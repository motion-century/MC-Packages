class ColorNode extends Node {
    constructor() {
        super("Color", {
            width: 150,
            headerBgClass: "bg-surface-variant/80",
            headerBorderClass: "border-outline-variant/30",
            headerTextClass: "text-on-surface"
        });

        const portOut = this.addOutput("", "Color");
        portOut.el.remove();
        portOut.el.style.position = "absolute";
        portOut.el.style.right = "-6px";
        portOut.el.style.top = "50%";
        portOut.el.style.transform = "translateY(-50%)";
        this.el.appendChild(portOut.el);

        const container = document.createElement("div");
        container.className = "flex flex-col space-y-2 mt-2 gap-2";

        // Color Swatch UI
        this.swatchContainer = document.createElement("div");
        this.swatchContainer.className = "flex items-center justify-center p-2";
        this.swatchBtn = document.createElement("button");
        this.swatchBtn.className = "w-full h-8 rounded-lg border border-surface-bright relative overflow-hidden transition-transform hover:scale-[1.02] active:scale-[0.98]";
        this.swatchBtn.style.backgroundImage = "linear-gradient(45deg, #3b3743 25%, transparent 25%, transparent 75%, #3b3743 75%, #3b3743), linear-gradient(45deg, #3b3743 25%, transparent 25%, transparent 75%, #3b3743 75%, #3b3743)";
        this.swatchBtn.style.backgroundSize = "8px 8px";
        this.swatchBtn.style.backgroundPosition = "0 0, 4px 4px";
        
        this.swatchColor = document.createElement("div");
        this.swatchColor.className = "absolute inset-0";
        
        this.swatchBtn.appendChild(this.swatchColor);
        this.swatchContainer.appendChild(this.swatchBtn);
        container.appendChild(this.swatchContainer);

        // Msg Container
        this.kfMsg = document.createElement("div");
        this.kfMsg.className = "w-full bg-green-500/20 border border-green-500/50 rounded py-2 text-center text-green-300 font-body-sm hidden";
        this.kfMsg.innerText = "Managed by AE Keyframes";
        container.appendChild(this.kfMsg);

        // Checkboxes Container
        const cbContainer = document.createElement("div");
        cbContainer.className = "flex flex-col space-y-2 mt-2 pt-2 border-t border-outline-variant/30";

        const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
        const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;

        // Control Checkbox
        const rowControl = document.createElement("div");
        rowControl.className = "flex items-center space-x-2 cursor-pointer group";
        this.iconControl = document.createElement("div");
        this.iconControl.innerHTML = inactiveSVG;
        const lblControl = document.createElement("span");
        lblControl.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
        lblControl.innerText = "Use Control";
        rowControl.appendChild(this.iconControl);
        rowControl.appendChild(lblControl);
        cbContainer.appendChild(rowControl);

        // Keyframe Checkbox
        const rowKf = document.createElement("div");
        rowKf.className = "flex items-center space-x-2 cursor-pointer group";
        this.iconKf = document.createElement("div");
        this.iconKf.innerHTML = inactiveSVG;
        const lblKf = document.createElement("span");
        lblKf.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
        lblKf.innerText = "Use Keyframe";
        rowKf.appendChild(this.iconKf);
        rowKf.appendChild(lblKf);
        cbContainer.appendChild(rowKf);

        container.appendChild(cbContainer);
        this.bodyEl.insertBefore(container, this.bodyEl.lastElementChild);

        // State (value is [r,g,b,a] in 0-1)
        this.state = { value: [0.486, 0.302, 1, 1], control: false, kf: false };

        // Events
        rowControl.addEventListener("click", () => {
            this.state.control = !this.state.control;
            if (!this.state.control) this.state.kf = false;
            this.updateCheckboxes();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        rowKf.addEventListener("click", () => {
            this.state.kf = !this.state.kf;
            if (this.state.kf) this.state.control = true;
            this.updateCheckboxes();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        this.swatchBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            const rect = this.swatchBtn.getBoundingClientRect();
            if (window.ColorPickerModal) {
                const generation = this.sessionGeneration;
                ColorPickerModal.show(rect.right, rect.top, this.state.value, (newRgba) => {
                    if (this.disposed || (window.graphSession && (generation !== window.graphSession.generation || !window.canEditGraph()))) return;
                    this.state.value = ColorNode.opaqueColor(newRgba);
                    this.updateSwatch();
                    if (window.triggerAutoSave) window.triggerAutoSave(); // Maybe too frequent if dragging?
                });
            }
        });

        this.updateCheckboxes();
        this.updateSwatch();
    }

    static opaqueColor(value) {
        return [value[0], value[1], value[2], 1];
    }

    updateSwatch() {
        this.state.value = ColorNode.opaqueColor(this.state.value);
        const [r, g, b, a] = this.state.value;
        this.swatchColor.style.backgroundColor = `rgba(${r*255}, ${g*255}, ${b*255}, ${a})`;
    }

    updateCheckboxes() {
        const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
        const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;
        
        this.iconControl.innerHTML = this.state.control ? activeSVG : inactiveSVG;
        this.iconKf.innerHTML = this.state.kf ? activeSVG : inactiveSVG;
        
        if (this.state.kf) {
            this.swatchContainer.classList.add("hidden");
            this.swatchContainer.classList.remove("flex");
            this.kfMsg.classList.remove("hidden");
        } else {
            this.swatchContainer.classList.add("flex");
            this.swatchContainer.classList.remove("hidden");
            this.kfMsg.classList.add("hidden");
        }
    }

    serialize() {
        this.state.value = ColorNode.opaqueColor(this.state.value);
        const data = super.serialize();
        data.state = this.state;
        return data;
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.state) {
            this.state = data.state;
            this.updateSwatch();
            this.updateCheckboxes();
        }
    }

    getValues() {
        this.state.value = ColorNode.opaqueColor(this.state.value);
        return [this.state];
    }

    setValues(values) {
        if (values && values.length > 0) {
            this.state = values[0];
            this.updateSwatch();
            this.updateCheckboxes();
        }
    }

    getControlPayload() {
        if (!this.state.control && !this.state.kf) return null;
        return {
            type: "ADBE Color Control",
            value: ColorNode.opaqueColor(this.state.value),
            useKeyframe: this.state.kf
        };
    }
}
