class SplitVectorNode extends Node {
    constructor() {
        super("Split Vector", {
            width: 180,
            headerBgClass: "bg-node-math/20",
            headerBorderClass: "border-node-math/30",
            headerTextClass: "text-node-math"
        });

        const portIn = this.addInput("Input", "3D");
        
        const portX = this.addOutput("X", "1D");
        const portY = this.addOutput("Y", "1D");
        const portZ = this.addOutput("Z", "1D");

        portX.el.remove();
        portY.el.remove();
        portZ.el.remove();

        const container = document.createElement("div");
        container.className = "flex flex-col space-y-2 mb-2 gap-2 mt-2";

        // Dropdown
        this.dimSelect = document.createElement("select");
        this.dimSelect.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none";
        this.dimSelect.innerHTML = `
            <option value="2D">2D Vector</option>
            <option value="3D" selected>3D Vector</option>
        `;
        container.appendChild(this.dimSelect);

        // Inputs Area
        this.inputsContainer = document.createElement("div");
        this.inputsContainer.className = "flex flex-col space-y-2 pb-2 border-b border-outline-variant/30";
        container.appendChild(this.inputsContainer);

        // Outputs Area
        const createOutRow = (port, label) => {
            const row = document.createElement("div");
            row.className = "w-full flex justify-end items-center relative";
            
            const span = document.createElement("span");
            span.className = "font-label-caps text-label-caps text-on-surface-variant w-4 text-center mx-1";
            span.innerText = label;
            row.appendChild(span);

            port.el.className = "relative flex items-center justify-end";
            row.appendChild(port.el);
            return row;
        };

        this.rowX = createOutRow(portX, "X");
        this.rowY = createOutRow(portY, "Y");
        this.rowZ = createOutRow(portZ, "Z");

        container.appendChild(this.rowX);
        container.appendChild(this.rowY);
        container.appendChild(this.rowZ);

        this.bodyEl.insertBefore(container, this.bodyEl.lastElementChild);

        this.state = { dim: "3D", values: [0, 0, 0] };
        this.inputEls = [];

        this.dimSelect.addEventListener("change", (e) => {
            this.state.dim = e.target.value;
            this.updateDim();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        this.updateDim();
    }

    renderInputs() {
        this.inputsContainer.innerHTML = "";
        this.inputEls = [];
        
        // Luôn kiểm tra xem cổng in có đang nối hay không
        const isConnected = this.inputs[0].wires.length > 0;
        
        if (isConnected) {
            // Chỉ hiển thị label mờ
            const lbl = document.createElement("div");
            lbl.className = "text-center text-on-surface-variant font-mono-label text-mono-label italic text-xs";
            lbl.innerText = "Driven by Input";
            this.inputsContainer.appendChild(lbl);
        } else {
            const count = this.state.dim === "3D" ? 3 : 2;
            const labels = ["X", "Y", "Z"];
            for (let i = 0; i < count; i++) {
                const row = document.createElement("div");
                row.className = "flex items-center space-x-2";
                
                const lbl = document.createElement("span");
                lbl.className = "font-label-caps text-label-caps text-on-surface-variant w-4 text-center";
                lbl.innerText = labels[i];

                const input = document.createElement("input");
                input.className = "flex-1 min-w-0 bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
                input.type = "text";
                input.value = this.state.values[i];
                
                UIUtils.makeInputDraggable(input);
                input.addEventListener("change", (e) => {
                    this.state.values[i] = parseFloat(e.target.value) || 0;
                    if (window.triggerAutoSave) window.triggerAutoSave();
                });

                row.appendChild(lbl);
                row.appendChild(input);
                this.inputsContainer.appendChild(row);
                this.inputEls.push(input);
            }
        }
    }

    onConnectionChanged(port) {
        if (port === this.inputs[0]) {
            this.renderInputs();
        }
        this.updatePosition();
    }

    updateDim() {
        if (this.state.dim === "2D") {
            this.rowZ.classList.add("hidden");
            this.outputs[2].el.style.display = "none";
            this.inputs[0].updateType("2D");
        } else {
            this.rowZ.classList.remove("hidden");
            this.outputs[2].el.style.display = "";
            this.inputs[0].updateType("3D");
        }
        this.renderInputs();
        this.updatePosition();
    }

    getValues() {
        return [this.state.dim, this.state.values[0], this.state.values[1], this.state.values[2]];
    }

    setValues(values) {
        if (values && values.length >= 4) {
            this.state.dim = values[0];
            this.state.values[0] = parseFloat(values[1]) || 0;
            this.state.values[1] = parseFloat(values[2]) || 0;
            this.state.values[2] = parseFloat(values[3]) || 0;
            this.dimSelect.value = this.state.dim;
            this.updateDim();
        }
    }
}
