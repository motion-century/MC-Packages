class SimpleMathNode extends Node {
  constructor() {
    super("Simple Math", {
      width: 180,
      headerBgClass: "bg-node-math/20",
      headerBorderClass: "border-node-math/30",
      headerTextClass: "text-node-math",
    });

    // Add ports (pass empty string to hide name)
    const portA = this.addInput("", "1D");
    const portB = this.addInput("", "1D");
    this.addOutput("", "1D"); // Output port (cứ để dưới cùng)

    // Lấy port.el ra khỏi bodyEl để custom vị trí
    portA.el.remove();
    portB.el.remove();

    // UI Container
    const container = document.createElement("div");
    container.className = "flex flex-col space-y-2 mb-2 gap-2";

    // Operator Dropdown
    this.operatorSelect = document.createElement("select");
    this.operatorSelect.className =
      "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none";
    this.operatorSelect.innerHTML = `
            <option value="Add">Add (+)</option>
            <option value="Subtract">Subtract (-)</option>
            <option value="Multiply">Multiply (*)</option>
            <option value="Divide">Divide (/)</option>
            <option value="Modulo">Modulo (%)</option>
        `;
    container.appendChild(this.operatorSelect);

    // Input A
    this.inputAContainer = document.createElement("div");
    this.inputAContainer.className = "w-full flex items-center relative";

    // Nhét Port A vào đầu Row
    portA.el.className = "relative flex items-center"; // Remove margin
    this.inputAContainer.appendChild(portA.el);

    this.inputA = document.createElement("input");
    this.inputA.className =
      "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
    this.inputA.type = "text"; // Đổi thành text để bỏ mũi tên tăng giảm số mặc định của trình duyệt
    this.inputA.value = "0";
    this.inputAContainer.appendChild(this.inputA);
    container.appendChild(this.inputAContainer);

    // Input B
    this.inputBContainer = document.createElement("div");
    this.inputBContainer.className = "w-full flex items-center relative mt-2";

    // Nhét Port B vào đầu Row
    portB.el.className = "relative flex items-center";
    this.inputBContainer.appendChild(portB.el);

    this.inputB = document.createElement("input");
    this.inputB.className =
      "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
    this.inputB.type = "text";
    this.inputB.value = "0";
    this.inputBContainer.appendChild(this.inputB);
    container.appendChild(this.inputBContainer);

    // Insert container BEFORE the output port
    this.bodyEl.insertBefore(container, this.bodyEl.lastElementChild);

    // Make inputs draggable using our shared utility
    UIUtils.makeInputDraggable(this.inputA);
    UIUtils.makeInputDraggable(this.inputB);

    // Lắng nghe sự thay đổi dropdown
    this.operatorSelect.addEventListener("change", () => {
      if (window.triggerAutoSave) window.triggerAutoSave();
    });
  }

  onConnectionChanged(port) {
    if (port === this.inputs[0]) {
      if (port.wires.length > 0) {
        this.inputA.classList.add("hidden");
      } else {
        this.inputA.classList.remove("hidden");
      }
    } else if (port === this.inputs[1]) {
      if (port.wires.length > 0) {
        this.inputB.classList.add("hidden");
      } else {
        this.inputB.classList.remove("hidden");
      }
    }
    this.updatePosition(); // update port heights
  }

  getValues() {
    return [this.inputA.value, this.inputB.value, this.operatorSelect.value];
  }

  setValues(values) {
    if (values && values.length >= 3) {
      this.inputA.value = values[0];
      this.inputB.value = values[1];
      this.operatorSelect.value = values[2];
    }
  }
}
