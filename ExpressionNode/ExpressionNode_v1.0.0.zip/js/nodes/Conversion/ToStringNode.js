class ToStringNode extends Node {
    constructor() {
        super("To String", {
            width: 180,
            headerBgClass: "bg-surface-variant/80",
            headerBorderClass: "border-outline-variant/30",
            headerTextClass: "text-on-surface"
        });
        const input = this.addInput("Value", "ANY");
        input.acceptedSourceTypes = ["1D", "2D", "3D", "COLOR", "LAYER", "ANY_NUM", "ANY", "COLOR_HSL", "COLOR_LAB"];
        this.addOutput("Text", "STRING");
    }
}
