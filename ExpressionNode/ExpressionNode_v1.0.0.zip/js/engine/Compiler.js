class Compiler {
    static getEffectName(node) {
        if (node.customName) {
            return `Node_${node.id} (${node.customName})`;
        }
        return `Node_${node.id}`;
    }

    static getAePropertyPath(matchNamePath) {
        const map = {
            "ADBE Transform Group": ".transform",
            "ADBE Position": ".position",
            "ADBE Anchor Point": ".anchorPoint",
            "ADBE Scale": ".scale",
            "ADBE Opacity": ".opacity",
            "ADBE Rotate Z": ".rotation",
            "ADBE Rotate X": ".xRotation",
            "ADBE Rotate Y": ".yRotation",
            "ADBE Audio Group": ".audio",
            "ADBE Audio Levels": ".audioLevels"
        };
        
        let path = "";
        let varName = "";
        const parts = matchNamePath.split("/");
        
        parts.forEach(part => {
            if (map[part]) {
                path += map[part];
                if (part === "ADBE Transform Group") varName += "t_";
                else varName += part.replace("ADBE ", "").replace(/ /g, "");
            } else {
                path += `("${part}")`;
                varName += "_" + part.replace(/[^a-zA-Z0-9]/g, "");
            }
        });
        
        varName = varName.replace(/^_/, "").replace(/_$/, "");
        if (!varName) varName = "prop";
        return { path, varName };
    }

    static compileGraph(graph) {
        const expressions = {};
        const controls = {};

        const targetNode = graph.nodes.find(n => n instanceof TargetLayerNode);
        if (targetNode) {
            // Duyệt qua từng cổng Input của TargetLayerNode
            targetNode.inputs.forEach(port => {
                if (port.wires.length > 0) {
                    const sourceWire = port.wires[0];
                    const code = this.compilePort(sourceWire.sourcePort, port.type);
                    expressions[port.name] = code;
                } else {
                    // Xóa expression nếu không có dây nối
                    expressions[port.name] = "";
                }
            });
        }

        // Thu thập các controls từ tất cả các node trong graph (nếu có)
        graph.nodes.forEach(node => {
            if (typeof node.getControlPayload === "function") {
                const payload = node.getControlPayload();
                if (payload) {
                    controls[Compiler.getEffectName(node)] = payload;
                }
            }
        });

        return { expressions, controls };
    }

    static compilePort(startSourcePort, expectedType) {
        // 1. Thuật toán Topological Sort (DFS)
        const orderedNodes = [];
        const visited = new Set();
        const neededOutputPorts = new Set();
        neededOutputPorts.add(startSourcePort.id);
        
        function visit(node) {
            if (visited.has(node.id)) return;
            // Duyệt sâu vào các dependency (các dây nối vào input của node hiện tại)
            node.inputs.forEach(inPort => {
                if (inPort.wires.length > 0) {
                    const sourcePort = inPort.wires[0].sourcePort;
                    neededOutputPorts.add(sourcePort.id);
                    visit(sourcePort.node);
                }
            });
            visited.add(node.id);
            orderedNodes.push(node);
        }
        
        visit(startSourcePort.node);

        // 2. Sinh mã SSA (Gán biến tuần tự)
        let codeLines = [];
        if (orderedNodes.some(node => node.constructor.name === "ColorConversionNode")) {
            codeLines.push(convertNodeColor.toString());
        }
        let varCounter = 1;
        const portVarMap = {}; // Lưu mapping: node.id + "_" + portName -> tên biến "v1", "v2"

        orderedNodes.forEach(node => {
            const v = "v" + varCounter++;
            let expressionString = "";

            if (node instanceof SimpleMathNode || node.constructor.name === "MathNode") {
                const inputs = node.getValues();
                const mathOp = inputs[2] || "Add";
                
                // Input A
                let inA = `${inputs[0] || 0}`;
                const portA = node.inputs[0];
                if (portA.wires.length > 0) {
                    const sourcePort = portA.wires[0].sourcePort;
                    inA = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                }

                // Input B
                let inB = `${inputs[1] || 0}`;
                const portB = node.inputs[1];
                if (portB.wires.length > 0) {
                    const sourcePort = portB.wires[0].sourcePort;
                    inB = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                }
                
                if (mathOp === "Add") expressionString = `${inA} + ${inB}`;
                else if (mathOp === "Subtract") expressionString = `${inA} - ${inB}`;
                else if (mathOp === "Multiply") expressionString = `${inA} * ${inB}`;
                else if (mathOp === "Divide") expressionString = `${inA} / ${inB}`;
                else if (mathOp === "Modulo") expressionString = `${inA} % ${inB}`;

                codeLines.push(`var ${v} = ${expressionString};`);
                // Ghi nhận biến cho cổng output
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "JSMathNode") {
                const inputs = node.getValues();
                const mathOp = inputs[2] || "sin";
                
                let inA = `${inputs[0] || 0}`;
                const portA = node.inputs[0];
                if (portA.wires.length > 0) {
                    const sourcePort = portA.wires[0].sourcePort;
                    inA = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                }

                let inB = `${inputs[1] || 0}`;
                const portB = node.inputs[1];
                if (portB.wires.length > 0) {
                    const sourcePort = portB.wires[0].sourcePort;
                    inB = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                }
                
                const funcs2 = ["pow", "min", "max", "atan2"];
                if (funcs2.includes(mathOp)) {
                    codeLines.push(`var ${v} = Math.${mathOp}(${inA}, ${inB});`);
                } else {
                    codeLines.push(`var ${v} = Math.${mathOp}(${inA});`);
                }
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "JSConstantNode") {
                const inputs = node.getValues();
                const constant = inputs[0] || "PI";
                codeLines.push(`var ${v} = Math.${constant};`);
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "ColorConversionNode") {
                const mode = node.state.mode;
                const input = node.inputs[0];
                let inputCode;
                if (input.wires.length) {
                    const source = input.wires[0].sourcePort;
                    inputCode = portVarMap[source.node.id + "_" + source.name];
                } else {
                    const literal = node.state.literals[mode];
                    convertNodeColor(literal, mode, "RGB");
                    inputCode = JSON.stringify(literal);
                }
                codeLines.push(`var ${v} = convertNodeColor(${inputCode}, ${JSON.stringify(mode)}, "RGB");`);
                node.outputs.forEach(output => {
                    if (!neededOutputPorts.has(output.id)) return;
                    const name = `${v}_${output.name}`;
                    codeLines.push(`var ${name} = ${output.name === "RGB" ? v : `convertNodeColor(${v}, "RGB", ${JSON.stringify(output.name)})`};`);
                    portVarMap[node.id + "_" + output.name] = name;
                });
            }
            else if (node.constructor.name === "ToStringNode") {
                const input = node.inputs[0];
                let conversion = '""';
                if (input.wires.length > 0) {
                    const source = input.wires[0].sourcePort;
                    const sourceVar = portVarMap[source.node.id + "_" + source.name];
                    const type = source.type.toUpperCase();
                    if (type === "LAYER") {
                        conversion = `(function(x) { return x && typeof x.name === "string" ? x.name : ""; })(${sourceVar})`;
                    } else if (type === "COLOR") {
                        conversion = `(function(x) { if (x != null && typeof x.value !== "undefined") x = x.value; return x && x.length === 4 ? String(x[0]) + ", " + String(x[1]) + ", " + String(x[2]) + ", " + String(x[3]) : ""; })(${sourceVar})`;
                    } else if (type === "COLOR_HSL" || type === "COLOR_LAB") {
                        conversion = `(function(x) { if (x != null && typeof x.value !== "undefined") x = x.value; return x && x.length === 3 ? String(x[0]) + ", " + String(x[1]) + ", " + String(x[2]) : ""; })(${sourceVar})`;
                    } else if (input.acceptedSourceTypes.includes(type)) {
                        conversion = `(function(x) { if (x != null && typeof x.value !== "undefined") x = x.value; if (x != null && typeof x !== "string" && typeof x.length === "number") x = x[0]; return typeof x === "number" ? String(x) : ""; })(${sourceVar})`;
                    }
                }
                codeLines.push(`var ${v} = ${conversion};`);
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "AngleConversionNode") {
                const inputs = node.getValues();
                const mathOp = inputs[1] || "degreesToRadians";
                let inA = `${inputs[0] || 0}`;
                const portA = node.inputs[0];
                if (portA.wires.length > 0) {
                    const sourcePort = portA.wires[0].sourcePort;
                    inA = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                }
                codeLines.push(`var ${v} = ${mathOp}(${inA});`);
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "CombineVectorNode") {
                const inputs = node.getValues();
                const dim = inputs[3] || "3D";
                
                let getInCode = (index) => {
                    let val = `${inputs[index] || 0}`;
                    const port = node.inputs[index];
                    if (port && port.wires.length > 0) {
                        const sourcePort = port.wires[0].sourcePort;
                        val = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                    }
                    return val;
                };

                const x = getInCode(0);
                const y = getInCode(1);
                const z = getInCode(2);
                
                if (dim === "2D") {
                    codeLines.push(`var ${v} = [${x}, ${y}];`);
                } else {
                    codeLines.push(`var ${v} = [${x}, ${y}, ${z}];`);
                }
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "SplitVectorNode") {
                const inputs = node.getValues();
                const dim = inputs[0] || "3D";
                
                let inVec = "";
                const portA = node.inputs[0];
                if (portA.wires.length > 0) {
                    const sourcePort = portA.wires[0].sourcePort;
                    inVec = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                } else {
                    // Manual values
                    const x = inputs[1] || 0;
                    const y = inputs[2] || 0;
                    const z = inputs[3] || 0;
                    if (dim === "2D") {
                        codeLines.push(`var ${v}_temp = [${x}, ${y}];`);
                    } else {
                        codeLines.push(`var ${v}_temp = [${x}, ${y}, ${z}];`);
                    }
                    inVec = `${v}_temp`;
                }

                codeLines.push(`var ${v} = ${inVec};`);
                
                // Assign X
                const varX = `${v}_X`;
                codeLines.push(`var ${varX} = ${v}[0];`);
                portVarMap[node.id + "_X"] = varX;
                
                // Assign Y
                const varY = `${v}_Y`;
                codeLines.push(`var ${varY} = ${v}[1];`);
                portVarMap[node.id + "_Y"] = varY;

                if (dim === "3D") {
                    const varZ = `${v}_Z`;
                    codeLines.push(`var ${varZ} = ${v}[2];`);
                    portVarMap[node.id + "_Z"] = varZ;
                }
            }
            else if (node.constructor.name === "InterpolationNode") {
                const inputs = node.getValues();
                const method = inputs[0] || "linear";

                let getInCode = (index, defaultVal) => {
                    const port = node.inputs[index];
                    if (port && port.wires.length > 0) {
                        const sourcePort = port.wires[0].sourcePort;
                        return portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                    }
                    return `${defaultVal}`;
                };

                const tCode = getInCode(0, inputs[1] || "0");
                const tMinCode = getInCode(1, inputs[2] || "0");
                const tMaxCode = getInCode(2, inputs[3] || "1");
                const val1Code = getInCode(3, inputs[4] || "0");
                const val2Code = getInCode(4, inputs[5] || "100");

                codeLines.push(`var ${v} = ${method}(${tCode}, ${tMinCode}, ${tMaxCode}, ${val1Code}, ${val2Code});`);
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "WigglerNode") {
                const state = node.getValues();
                const loopMode = state[0];
                const sepDim = state[1];

                let getInCode = (index, defaultVal) => {
                    const port = node.inputs[index];
                    if (port && port.wires.length > 0) {
                        const sourcePort = port.wires[0].sourcePort;
                        return portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                    }
                    return `${defaultVal}`;
                };

                const freq = getInCode(0, state[2] || "2");
                const amp = getInCode(1, state[3] || "50");

                let outVar = `${v}_w`;
                codeLines.push(`var ${outVar} = wiggle(${freq}, ${amp});`);
                
                if (loopMode) {
                    const pVar = `${v}_p`;
                    const ftVar = `${v}_ft`;
                    codeLines.push(`var ${ftVar} = thisComp.duration < 2 ? thisComp.duration * 0.25 : 1;`);
                    codeLines.push(`var ${pVar} = linear(time, 0, ${ftVar}, 0, 1) * linear(time, thisComp.duration - ${ftVar}, thisComp.duration, 1, 0);`);
                    codeLines.push(`${outVar} = ${outVar} * ${pVar} + value * (1 - ${pVar});`);
                }

                if (!sepDim) {
                    codeLines.push(`var ${v} = [${outVar}[0], ${outVar}[0]];`);
                } else {
                    codeLines.push(`var ${v} = ${outVar};`);
                }
                
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "RandomNode") {
                const state = node.getValues();
                const method = state[0] || "random";
                const useSeed = state[3];
                const offset = state[4] || "1";
                const timeless = state[5];

                if (useSeed) {
                    codeLines.push(`seedRandom(${offset}, ${timeless ? "true" : "false"});`);
                }

                let getInCode = (index, defaultVal) => {
                    const port = node.inputs[index];
                    if (port && port.wires.length > 0) {
                        const sourcePort = port.wires[0].sourcePort;
                        return portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                    }
                    return `${defaultVal}`;
                };

                const minCode = getInCode(0, state[1] || "0");
                const maxCode = getInCode(1, state[2] || "100");

                codeLines.push(`var ${v} = ${method}(${minCode}, ${maxCode});`);
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "NoiseNode") {
                const state = node.getValues();
                const mode = state[0] || "time";
                
                if (mode === "time") {
                    const speed = state[1] || "1";
                    codeLines.push(`var ${v} = noise(time * ${speed});`);
                } else {
                    const port = node.inputs[0];
                    let val = "0";
                    if (port && port.wires.length > 0) {
                        const sourcePort = port.wires[0].sourcePort;
                        val = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                    }
                    codeLines.push(`var ${v} = noise(${val});`);
                }
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "ValueNode") {
                const dim = node.state.dim || "1D";
                const useControl = node.state.control;
                let valCode = "";
                
                if (useControl) {
                    const effectName = Compiler.getEffectName(node);
                    if (dim === "1D") valCode = `effect("${effectName}")("Slider")`;
                    else if (dim === "2D") valCode = `effect("${effectName}")("Point")`;
                    else if (dim === "3D") valCode = `effect("${effectName}")("3D Point")`;
                } else {
                    const vals = node.state.values;
                    if (dim === "1D") valCode = `${vals[0] || 0}`;
                    else if (dim === "2D") valCode = `[${vals[0] || 0}, ${vals[1] || 0}]`;
                    else if (dim === "3D") valCode = `[${vals[0] || 0}, ${vals[1] || 0}, ${vals[2] || 0}]`;
                }
                
                codeLines.push(`var ${v} = ${valCode};`);
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "AngleNode") {
                const useControl = node.state.control;
                let valCode = "";
                if (useControl) {
                    valCode = `effect("${Compiler.getEffectName(node)}")("Angle")`;
                } else {
                    valCode = `${node.state.value}`;
                }
                codeLines.push(`var ${v} = ${valCode};`);
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "CheckboxNode") {
                const useControl = node.state.control;
                let valCode = "";
                if (useControl) {
                    valCode = `effect("${Compiler.getEffectName(node)}")("Checkbox") == 1 ? 1 : 0`;
                } else {
                    valCode = node.state.value ? "1" : "0";
                }
                if (node.state.mode === "100") {
                    valCode = `(${valCode}) * 100`;
                }
                codeLines.push(`var ${v} = ${valCode};`);
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "ColorNode") {
                const useControl = node.state.control;
                let valCode = "";
                if (useControl) {
                    const colorVar = `${v}_color`;
                    codeLines.push(`var ${colorVar} = effect("${Compiler.getEffectName(node)}")("Color").value;`);
                    valCode = `[${colorVar}[0], ${colorVar}[1], ${colorVar}[2], 1]`;
                } else {
                    const c = node.state.value;
                    valCode = `[${c[0]}, ${c[1]}, ${c[2]}, 1]`;
                }
                codeLines.push(`var ${v} = ${valCode};`);
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "ThisLayerValueNode") {
                const portTime = node.inputs[0];
                let timeCode = "";
                if (portTime && portTime.wires.length > 0) {
                    const sourcePort = portTime.wires[0].sourcePort;
                    timeCode = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                } else {
                    const timeVal = node.getValues()[0];
                    if (timeVal !== "") timeCode = timeVal;
                }

                node.outputs.forEach(outPort => {
                    if (!neededOutputPorts.has(outPort.id)) return;
                    const portVar = `${v}_${outPort.name}`;
                    let valCode = "";
                    if (outPort.name === "Value") {
                        valCode = timeCode ? `valueAtTime(${timeCode})` : "value";
                    } else if (outPort.name === "Index") {
                        valCode = "index";
                    }
                    codeLines.push(`var ${portVar} = ${valCode};`);
                    portVarMap[node.id + "_" + outPort.name] = portVar;
                });
            }
            else if (node.constructor.name === "TimeNode") {
                codeLines.push(`var ${v} = time;`);
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "SpeedVelocityNode") {
                const portProp = node.inputs[0];
                let propCode = "";
                if (portProp && portProp.wires.length > 0) {
                    const sourcePort = portProp.wires[0].sourcePort;
                    propCode = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                }
                
                const portTime = node.inputs[1];
                let timeCode = "";
                if (portTime && portTime.wires.length > 0) {
                    const sourcePort = portTime.wires[0].sourcePort;
                    timeCode = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                } else {
                    const timeVal = node.getValues()[1];
                    if (timeVal !== "") timeCode = timeVal;
                }

                const funcName = node.getValues()[0] === "Velocity" ? "velocityAtTime" : "speedAtTime";
                
                if (propCode) {
                    codeLines.push(`var ${v} = ${timeCode ? `${propCode}.${funcName}(${timeCode})` : `${propCode}.${funcName}(time)`};`);
                } else {
                    codeLines.push(`var ${v} = 0;`);
                }
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
            else if (node.constructor.name === "SourceRectAtTimeNode") {
                const portLayer = node.inputs[0];
                let layerCode = "thisLayer";
                if (portLayer && portLayer.wires.length > 0) {
                    const sourcePort = portLayer.wires[0].sourcePort;
                    const val = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                    
                    if (sourcePort.node.constructor.name === "SourceLayerNode") {
                        layerCode = val;
                    } else {
                        layerCode = `thisComp.layer(${val})`;
                    }
                }

                const portTime = node.inputs[1];
                let timeCode = "";
                if (portTime && portTime.wires.length > 0) {
                    const sourcePort = portTime.wires[0].sourcePort;
                    timeCode = portVarMap[sourcePort.node.id + "_" + sourcePort.name];
                } else {
                    const timeVal = node.getValues()[0];
                    if (timeVal !== "") timeCode = timeVal;
                }

                const rectVar = `${v}_rect`;
                codeLines.push(`var ${rectVar} = ${timeCode ? `${layerCode}.sourceRectAtTime(${timeCode}, false)` : `${layerCode}.sourceRectAtTime(time, false)`};`);
                
                node.outputs.forEach(outPort => {
                    const portVar = `${v}_${outPort.name.toLowerCase()}`;
                    codeLines.push(`var ${portVar} = ${rectVar}.${outPort.name.toLowerCase()};`);
                    portVarMap[node.id + "_" + outPort.name] = portVar;
                });
            }
            else if (node instanceof SourceLayerNode) {
                const values = node.getValues();
                const compName = values[0];
                const layerName = values[1];
                
                if (!layerName) {
                    codeLines.push(`var ${v} = 0;`);
                    // Fallback tất cả các cổng
                    node.outputs.forEach(outPort => {
                        portVarMap[node.id + "_" + outPort.name] = v;
                    });
                } else {
                    let layerCode = "";
                    if (compName === "THIS_COMP") {
                        layerCode = `thisComp.layer("${layerName}")`;
                    } else {
                        layerCode = `comp("${compName}").layer("${layerName}")`;
                    }
                    codeLines.push(`var ${v} = ${layerCode};`);
                    
                    // Source Layer Node có nhiều cổng Output
                    node.outputs.forEach(outPort => {
                        if (!neededOutputPorts.has(outPort.id)) return;
                        if (outPort.name === "Layer") {
                            portVarMap[node.id + "_Layer"] = v;
                        } else {
                            const propData = this.getAePropertyPath(outPort.name);
                            const portVar = `${v}_${propData.varName}`;
                            codeLines.push(`var ${portVar} = ${v}${propData.path};`);
                            portVarMap[node.id + "_" + outPort.name] = portVar;
                        }
                    });
                }
            } else {
                codeLines.push(`var ${v} = 0;`);
                portVarMap[node.id + "_" + node.outputs[0].name] = v;
            }
        });

        // Ghép dòng cuối cùng: gọi tên biến chứa kết quả mong muốn và ép kiểu theo TargetLayerNode yêu cầu
        const finalVar = portVarMap[startSourcePort.node.id + "_" + startSourcePort.name];
        const finalCode = this.castType(finalVar, startSourcePort.type, expectedType);
        codeLines.push(finalCode);

        return codeLines.join("\n");
    }

    static castType(code, fromType, toType) {
        if (fromType === toType) return code;
        
        // Downcast: 3D/2D -> 1D (Lấy giá trị X)
        if ((fromType === "3D" || fromType === "2D") && toType === "1D") {
            return `${code}[0]`;
        }

        // Upcast: 1D -> 3D
        if (fromType === "1D" && toType === "3D") {
            return `[${code}, ${code}, ${code}]`;
        }
        
        // Upcast: 1D -> 2D
        if (fromType === "1D" && toType === "2D") {
            return `[${code}, ${code}]`;
        }

        return code;
    }
}
