class CombineVectorNode extends Node {
    constructor() {
        super("Combine Vector", {
            width: 180,
            headerBgClass: "bg-node-math/20",
            headerBorderClass: "border-node-math/30",
            headerTextClass: "text-node-math"
        });

        // Tạm thời add các port, sau đó sẽ custom lại vị trí
        const portX = this.addInput("", "1D");
        const portY = this.addInput("", "1D");
        const portZ = this.addInput("", "1D");
        const portOut = this.addOutput("", "3D");

        portX.el.remove();
        portY.el.remove();
        portZ.el.remove();
        portOut.el.remove();

        const container = document.createElement("div");
        container.className = "flex flex-col space-y-2 mb-2 gap-2";

        // Dimension Dropdown
        this.dimSelect = document.createElement("select");
        this.dimSelect.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none";
        this.dimSelect.innerHTML = `
            <option value="2D">2D Vector</option>
            <option value="3D" selected>3D Vector</option>
        `;
        container.appendChild(this.dimSelect);

        const createInputRow = (port, label, index) => {
            const row = document.createElement("div");
            row.className = "w-full flex items-center relative";
            port.el.className = "relative flex items-center";
            row.appendChild(port.el);
            
            const span = document.createElement("span");
            span.className = "font-label-caps text-label-caps text-on-surface-variant w-4 text-center mx-1";
            span.innerText = label;
            row.appendChild(span);

            const input = document.createElement("input");
            input.className = "flex-1 min-w-0 bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
            input.type = "text";
            input.value = "0";
            row.appendChild(input);

            UIUtils.makeInputDraggable(input);
            return { row, input };
        };

        this.rowX = createInputRow(portX, "X", 0);
        this.rowY = createInputRow(portY, "Y", 1);
        this.rowZ = createInputRow(portZ, "Z", 2);

        container.appendChild(this.rowX.row);
        container.appendChild(this.rowY.row);
        container.appendChild(this.rowZ.row);

        // Output row
        const outRow = document.createElement("div");
        outRow.className = "w-full flex justify-end items-center relative mt-2 pt-2 border-t border-outline-variant/30";
        portOut.el.className = "relative flex items-center";
        outRow.appendChild(portOut.el);
        container.appendChild(outRow);

        this.bodyEl.insertBefore(container, this.bodyEl.lastElementChild);

        this.dimSelect.addEventListener("change", () => {
            this.updateDim();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        this.updateDim();
    }

    updateDim() {
        if (this.dimSelect.value === "2D") {
            this.rowZ.row.classList.add("hidden");
            this.inputs[2].el.style.display = "none";
            this.outputs[0].updateType("2D");
        } else {
            this.rowZ.row.classList.remove("hidden");
            this.inputs[2].el.style.display = "";
            this.outputs[0].updateType("3D");
        }
        this.updatePosition();
    }

    onConnectionChanged(port) {
        if (port === this.inputs[0]) {
            if (port.wires.length > 0) this.rowX.input.classList.add("hidden");
            else this.rowX.input.classList.remove("hidden");
        } else if (port === this.inputs[1]) {
            if (port.wires.length > 0) this.rowY.input.classList.add("hidden");
            else this.rowY.input.classList.remove("hidden");
        } else if (port === this.inputs[2]) {
            if (port.wires.length > 0) this.rowZ.input.classList.add("hidden");
            else this.rowZ.input.classList.remove("hidden");
        }
        this.updatePosition();
    }

    getValues() {
        return [this.rowX.input.value, this.rowY.input.value, this.rowZ.input.value, this.dimSelect.value];
    }

    setValues(values) {
        if (values && values.length >= 4) {
            this.rowX.input.value = values[0];
            this.rowY.input.value = values[1];
            this.rowZ.input.value = values[2];
            this.dimSelect.value = values[3];
            this.updateDim();
        }
    }
}
