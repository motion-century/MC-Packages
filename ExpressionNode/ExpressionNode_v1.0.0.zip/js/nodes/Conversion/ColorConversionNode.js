class ColorConversionNode extends Node {
    constructor() {
        super("Color Conversion", {width:210});
        const purple = [0.486,0.302,1,1];
        this.state = {mode:"RGB", literals:{RGB:purple,HEX:convertNodeColor(purple,"RGB","HEX"),
            HSL:convertNodeColor(purple,"RGB","HSL"),LAB:convertNodeColor(purple,"RGB","LAB")}};
        this.input = this.addInput("RGB", "COLOR");
        this.modeSelect = document.createElement("select");
        this.modeSelect.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 text-on-surface font-mono-label text-mono-label";
        this.modeSelect.setAttribute("aria-label", "Input Format");
        for (const mode of ["RGB","HEX","HSL","LAB"]) {
            const option = document.createElement("option"); option.value=mode; option.textContent=mode; this.modeSelect.appendChild(option);
        }
        this.bodyEl.insertBefore(this.modeSelect, this.input.el);
        this.editor = document.createElement("div");
        this.editor.className = "flex flex-col gap-2";
        this.bodyEl.appendChild(this.editor);
        this.errorLabel = document.createElement("div");
        this.errorLabel.className = "text-error text-[10px]";
        this.bodyEl.appendChild(this.errorLabel);
        this.addOutput("RGB","COLOR"); this.addOutput("HEX","STRING");
        this.addOutput("HSL","COLOR_HSL"); this.addOutput("LAB","COLOR_LAB");
        this.input.setDisplayColor("#eab308");
        this.outputs.forEach(port => {
            port.setDisplayColor("#eab308");
            port.el.style.justifyContent = "flex-end";
            const label = port.el.querySelector("span");
            label.style.textAlign = "right";
        });
        this.modeSelect.addEventListener("change", event => {
            event.stopPropagation();
            if (!window.canEditGraph()) return;
            this.state.mode = this.modeSelect.value;
            this.configure();
            if (this.graph) {
                const wasRestoring=this.graph.isRestoring;
                this.graph.isRestoring=true;
                this.input.wires.slice().forEach(wire => {
                    if (!this.input.canConnectTo(wire.sourcePort)) this.graph.removeWire(wire);
                });
                this.graph.isRestoring=wasRestoring;
            }
            this.renderEditor();
            window.triggerAutoSave();
        });
        this.configure(); this.renderEditor();
    }

    configure() {
        const types={RGB:"COLOR",HEX:"STRING",HSL:"COLOR_HSL",LAB:"COLOR_LAB"};
        const mode=this.state.mode;
        this.input.updateType(types[mode]);
        this.input.acceptedSourceTypes = mode==="RGB" ? ["COLOR"] : mode==="HEX" ? ["STRING"] : [types[mode],"3D"];
        this.input.name=mode;
        const label=this.input.el.querySelector("span");
        if (label) label.textContent=mode;
        this.modeSelect.value=mode;
    }

    renderEditor() {
        this.editor.innerHTML="";
        if (this.input.wires.length) { this.validate(); return; }
        const mode=this.state.mode;
        if (mode==="RGB") {
            const button=document.createElement("button"); button.type="button";
            button.className="w-full h-8 rounded border border-surface-bright";
            button.setAttribute("aria-label","RGB color");
            const color=this.state.literals.RGB;
            button.style.backgroundColor=`rgb(${color[0]*255},${color[1]*255},${color[2]*255})`;
            button.addEventListener("click", event => {
                event.stopPropagation();
                const rect=button.getBoundingClientRect(), generation=this.sessionGeneration;
                ColorPickerModal.show(rect.right,rect.top,color,rgba => {
                    if (this.disposed || !window.canEditGraph() || (window.graphSession && generation!==window.graphSession.generation)) return;
                    this.state.literals.RGB=[rgba[0],rgba[1],rgba[2],1];
                    button.style.backgroundColor=`rgb(${rgba[0]*255},${rgba[1]*255},${rgba[2]*255})`;
                    this.validate(); window.triggerAutoSave();
                });
            });
            this.editor.appendChild(button);
        } else {
            const labels=mode==="HEX" ? ["HEX"] : mode==="HSL" ? ["H °","S","L"] : ["L","a","b"];
            labels.forEach((label,index) => {
                const row=document.createElement("label"); row.className="flex items-center gap-2 text-on-surface-variant font-mono-label text-mono-label";
                const caption=document.createElement("span"); caption.textContent=label; caption.style.width="28px";
                const input=document.createElement("input"); input.type="text";
                input.className="min-w-0 flex-1 bg-surface-dim border border-outline-variant rounded px-2 py-1 text-on-surface";
                input.value=mode==="HEX" ? this.state.literals.HEX : this.state.literals[mode][index];
                input.addEventListener("change",event => {
                    event.stopPropagation();
                    if (mode==="HEX") this.state.literals.HEX=input.value;
                    else this.state.literals[mode][index]=input.value.trim()==="" ? "" : Number(input.value);
                    this.validate(); window.triggerAutoSave();
                });
                row.appendChild(caption);row.appendChild(input);this.editor.appendChild(row);
            });
        }
        this.validate();
    }

    validate() {
        this.errorLabel.textContent="";
        if (!this.input.wires.length) {
            try { convertNodeColor(this.state.literals[this.state.mode],this.state.mode,"RGB"); }
            catch(error) { this.errorLabel.textContent=error.message; }
        }
        this.updatePosition();
    }

    onConnectionChanged() { this.renderEditor(); }
    getValues() { return [this.state]; }
    setValues(values) {
        if (!values || !values[0]) return;
        const state=values[0];
        if (!["RGB","HEX","HSL","LAB"].includes(state.mode) || !state.literals) throw Error("Invalid Color Conversion state");
        this.state=JSON.parse(JSON.stringify(state));
        this.configure();this.renderEditor();
    }
}
