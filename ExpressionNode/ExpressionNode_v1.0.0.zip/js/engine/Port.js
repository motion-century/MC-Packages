/**
 * Port - Quản lý Cổng kết nối của Node
 */
class Port {
    constructor(node, name, type, direction, labelStr) {
        this.node = node;
        this.name = name;
        this.labelStr = (labelStr !== undefined && labelStr !== null) ? labelStr : name;
        this.type = type;
        this.direction = direction; // 'in' or 'out'
        this.wires = [];
        
        // Tạo ID duy nhất nhưng có tính ổn định để Deserialize
        const list = direction === 'in' ? node.inputs : node.outputs;
        const index = list ? list.length : 0;
        this.id = `${node.id}_${direction}_${index}`;
        
        this.el = this.createDOM();
        this.initEvents();
    }

    createDOM() {
        const el = document.createElement("div");
        el.className = "relative flex items-center justify-between mt-2";

        const portDot = document.createElement("div");
        // Màu động dựa vào type (vd: 1D -> port-1d)
        const typeClass = this.type ? `bg-port-${this.type.toLowerCase()}` : "bg-port-1d";
        portDot.className = `port port-${this.direction} ${typeClass} z-20`;
        
        const label = document.createElement("span");
        label.className = `font-mono-label text-mono-label text-on-surface-variant ${this.direction === 'in' ? 'ml-2' : 'mr-2'}`;
        label.innerText = this.labelStr;
        if (["COLOR", "COLOR_HSL", "COLOR_LAB"].includes((this.type || "").toUpperCase())) label.style.color = "#eab308";

        if (this.direction === 'in') {
            el.appendChild(portDot);
            el.appendChild(label);
            this.dotEl = portDot;
        } else {
            el.appendChild(label);
            el.appendChild(portDot);
            this.dotEl = portDot;
        }

        return el;
    }

    setDisplayColor(color) {
        this.displayColor = color;
        this.dotEl.style.backgroundColor = color;
        const label = this.el.querySelector("span");
        if (label) label.style.color = color;
        this.wires.forEach(wire => wire.updateColor());
    }

    updateType(newType) {
        if (!this.dotEl) return;
        if (this.type) {
            this.dotEl.classList.remove(`bg-port-${this.type.toLowerCase()}`);
        } else {
            this.dotEl.classList.remove("bg-port-1d");
        }
        
        this.type = newType;
        
        if (this.type) {
            this.dotEl.classList.add(`bg-port-${this.type.toLowerCase()}`);
        } else {
            this.dotEl.classList.add("bg-port-1d");
        }
    }

    initEvents() {
        this.dotEl.addEventListener("mousedown", (e) => {
            e.stopPropagation();
            if (e.button !== 0) return;

            const graph = this.node.graph;
            
            // Xóa dây cũ nếu cổng Input đã có dây (tạm thời để 1-to-many cho Output, 1-to-1 cho Input)
            if (this.direction === 'in' && this.wires.length > 0) {
                const w = this.wires[0];
                graph.removeWire(w);
            }

            // Bắt đầu vẽ dây ảo
            const startPos = this.getGlobalPosition();
            const tempWire = new Wire(this, null);
            graph.addWire(tempWire);
            
            // Fix lỗi dây nhảy về tọa độ origin khi chưa nhích chuột
            const initialMouseWorld = graph.screenToWorld(e.clientX, e.clientY);
            tempWire.updatePath(startPos, initialMouseWorld);

            const generation = window.graphSession ? window.graphSession.generation : 0;
            const valid = () => !this.node.disposed && (!window.graphSession || (generation === window.graphSession.generation && window.canEditGraph()));
            const onMouseMove = (moveEvent) => {
                if (!valid()) return;
                const mouseWorld = graph.screenToWorld(moveEvent.clientX, moveEvent.clientY);
                tempWire.updatePath(startPos, mouseWorld);
            };

            const onMouseUp = (upEvent) => {
                window.removeEventListener("mousemove", onMouseMove);
                window.removeEventListener("mouseup", onMouseUp);

                window.removeEventListener("graph-session-ending", cancel);
                if (!valid()) { graph.removeWire(tempWire); return; }
                // Tìm xem có thả vào cổng nào không
                // Đơn giản hóa: ta dùng document.elementFromPoint
                // Tạm thời ẩn cái node-layer / svg-layer để elementFromPoint đâm xuyên qua dây
                graph.svgLayer.style.pointerEvents = "none";
                const targetEl = document.elementFromPoint(upEvent.clientX, upEvent.clientY);
                
                // Cần 1 cách mapping từ DOM element -> Port Object
                // Tạm thời gán thuộc tính _portObj vào DOM
                let targetPort = null;
                if (targetEl && targetEl._portObj) {
                    targetPort = targetEl._portObj;
                } else if (targetEl && targetEl.parentElement && targetEl.parentElement._portObj) {
                    targetPort = targetEl.parentElement._portObj;
                }

                if (targetPort && targetPort !== this && targetPort.direction !== this.direction) {
                    // Kiểm tra luật ép kiểu
                    if (this.canConnectTo(targetPort)) {
                        // Nối dây thành công
                        if (this.direction === 'out') {
                            tempWire.targetPort = targetPort;
                        } else {
                            // Kéo từ Input sang Output, đảo ngược lại
                            tempWire.targetPort = this;
                            tempWire.sourcePort = targetPort;
                        }
                        
                        // Cập nhật lại màu dây dựa vào Output Port
                        tempWire.updateColor();

                        // Xóa dây cũ của Target Input nếu có
                        const inPort = tempWire.targetPort;
                        if (inPort.wires.length > 0) {
                            graph.removeWire(inPort.wires[0]);
                        }

                        inPort.wires.push(tempWire);
                        tempWire.sourcePort.wires.push(tempWire);
                        tempWire.updatePath();
                        
                        if (inPort.node.onConnectionChanged) inPort.node.onConnectionChanged(inPort);
                        if (tempWire.sourcePort.node.onConnectionChanged) tempWire.sourcePort.node.onConnectionChanged(tempWire.sourcePort);

                        if (window.triggerAutoSave) window.triggerAutoSave();
                    } else {
                        // Vi phạm luật ép kiểu
                        graph.removeWire(tempWire);
                    }
                } else {
                    // Không có target hoặc thả ra ngoài
                    graph.removeWire(tempWire);
                }
            };

            const cancel = () => {
                window.removeEventListener("mousemove", onMouseMove);
                window.removeEventListener("mouseup", onMouseUp);
                window.removeEventListener("graph-session-ending", cancel);
                graph.removeWire(tempWire);
            };
            window.addEventListener("graph-session-ending", cancel);
            window.addEventListener("mousemove", onMouseMove);
            window.addEventListener("mouseup", onMouseUp);
        });

        // Gắn reference để dễ tìm
        this.dotEl._portObj = this;
    }

    canConnectTo(otherPort) {
        if (!otherPort) return false;
        if (this.direction === otherPort.direction) return false;

        // Apply destination restrictions before the generic ANY shortcut.
        const input = this.direction === "in" ? this : otherPort;
        const output = this.direction === "out" ? this : otherPort;
        if (input.node === output.node) return false;
        if (input.acceptedSourceTypes &&
            !input.acceptedSourceTypes.includes(output.type.toUpperCase())) return false;
        const semanticTypes = ["COLOR_HSL", "COLOR_LAB"];
        if (input.node.constructor.name === "ColorConversionNode") return true;
        if (semanticTypes.includes(input.type.toUpperCase()) || semanticTypes.includes(output.type.toUpperCase())) {
            return input.type.toUpperCase() === output.type.toUpperCase() ||
                !!(input.acceptedSourceTypes && input.acceptedSourceTypes.includes(output.type.toUpperCase()));
        }
        
        // Cờ đặc biệt: node chỉ nhận kết nối từ một loại node cố định (ví dụ: SourceLayerNode)
        if (this.acceptsOnlyNode && otherPort.node.constructor.name !== this.acceptsOnlyNode) return false;
        if (otherPort.acceptsOnlyNode && this.node.constructor.name !== otherPort.acceptsOnlyNode) return false;

        const typeA = this.type.toUpperCase();
        const typeB = otherPort.type.toUpperCase();

        if (typeA === typeB) return true;
        
        if (typeA === "ANY" || typeB === "ANY") return true;

        if (typeA === "LAYER" || typeB === "LAYER") {
            // LAYER có thể nhận STRING hoặc 1D
            const accepted = ["LAYER", "STRING", "1D"];
            if (accepted.includes(typeA) && accepted.includes(typeB)) return true;
            return false;
        }

        const mathTypes = ["1D", "2D", "3D", "COLOR", "ANY_NUM"];
        const numericTypes = ["1D", "2D", "3D", "ANY_NUM"]; // Loại bỏ color

        if (typeA === "ANY_NUM") {
            return numericTypes.includes(typeB);
        }
        if (typeB === "ANY_NUM") {
            return numericTypes.includes(typeA);
        }

        // Luật 1: Cấm String nối với bất kỳ cái gì khác ngoài String
        if (typeA === "STRING" || typeB === "STRING") return false;

        // Luật 2: Nhóm toán học được nối chéo thoải mái
        if (mathTypes.includes(typeA) && mathTypes.includes(typeB)) return true;

        return false;
    }

    getGlobalPosition() {
        // Trả về toạ độ World của cục Dot
        let rect = this.dotEl.getBoundingClientRect();
        
        // Traverse up to find the top-most closed <details> element
        let current = this.dotEl;
        let topClosedDetails = null;
        
        while (current && current !== document.body) {
            if (current.tagName === 'DETAILS' && !current.open) {
                topClosedDetails = current; // Keep overwriting to find the highest one
            }
            current = current.parentElement;
        }

        if (topClosedDetails) {
            // Tìm summary-port bên trong phần summary của details bị đóng này
            const summaryPort = topClosedDetails.querySelector(":scope > summary .summary-port");
            if (summaryPort) {
                rect = summaryPort.getBoundingClientRect();
            }
        }
        
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        return this.node.graph.screenToWorld(centerX, centerY);
    }

    updateWires() {
        this.wires.forEach(w => w.updatePath());
    }
}
