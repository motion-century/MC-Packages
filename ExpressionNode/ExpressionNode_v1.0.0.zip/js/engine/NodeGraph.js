/**
 * NodeGraph - Main Engine class
 * Handles Zoom/Pan, DOM manipulation, and Nodes/Wires arrays
 */
class NodeGraph {
    constructor(containerId, workspaceId) {
        this.container = document.getElementById(containerId);
        this.workspace = document.getElementById(workspaceId);
        this.nodesLayer = document.getElementById("nodes-layer");
        this.svgLayer = document.getElementById("svg-layer");
        this.selectionBoxEl = document.getElementById("selection-box");

        this.panZoomEnabled = true;

        this.history = [];
        this.historyIndex = -1;

        this.nodes = [];
        this.wires = [];
        this.pendingWires = [];
        this.selectedNodes = new Set();

        // Transform state
        this.transform = { x: 0, y: 0, scale: 1 };

        // Interaction state
        this.isPanning = false;
        this.isBoxSelecting = false;
        this.panStart = { x: 0, y: 0 };
        this.selectionStart = { x: 0, y: 0 };

        this.initEvents();
        this.updateTransform();
    }

    initEvents() {
        // 1. Zoom (Lăn chuột)
        this.container.addEventListener("wheel", (e) => {
            e.preventDefault();
            const zoomSensitivity = 0.001;
            const delta = -e.deltaY * zoomSensitivity;
            const newScale = Math.min(Math.max(0.1, this.transform.scale * (1 + delta)), 3);

            // Zoom around mouse cursor
            const rect = this.container.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;

            const xs = (mouseX - this.transform.x) / this.transform.scale;
            const ys = (mouseY - this.transform.y) / this.transform.scale;

            this.transform.scale = newScale;
            this.transform.x = mouseX - xs * this.transform.scale;
            this.transform.y = mouseY - ys * this.transform.scale;

            this.updateTransform();
        });

        // 2. Mousedown: Pan hoặc Box Select
        this.container.addEventListener("mousedown", (e) => {
            // Chỉ bắt sự kiện nếu click vào khoảng trống (container) chứ không phải vào node
            if (e.target !== this.container && e.target !== this.workspace && e.target !== this.svgLayer && e.target.id !== "nodes-layer") return;

            // Click khoảng trống thì Deselect toàn bộ node
            if (!e.shiftKey) this.deselectAll();

            if (e.button === 1 || (e.button === 0 && e.altKey)) {
                // Middle click -> Pan
                e.preventDefault();
                this.isPanning = true;
                this.panStart = { x: e.clientX - this.transform.x, y: e.clientY - this.transform.y };
                this.container.style.cursor = "grabbing";
            } else if (e.button === 0) {
                // Left click -> Box Select
                this.isBoxSelecting = true;
                const rect = this.container.getBoundingClientRect();
                this.selectionStart = { x: e.clientX - rect.left, y: e.clientY - rect.top };
                
                if (!e.shiftKey) this.clearSelection();

                this.selectionBoxEl.style.left = `${this.selectionStart.x}px`;
                this.selectionBoxEl.style.top = `${this.selectionStart.y}px`;
                this.selectionBoxEl.style.width = "0px";
                this.selectionBoxEl.style.height = "0px";
                this.selectionBoxEl.classList.remove("hidden");
            }
        });

        window.addEventListener("mousemove", (e) => {
            if (this.isPanning) {
                this.transform.x = e.clientX - this.panStart.x;
                this.transform.y = e.clientY - this.panStart.y;
                this.updateTransform();
            } else if (this.isBoxSelecting) {
                const rect = this.container.getBoundingClientRect();
                const currentX = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
                const currentY = Math.max(0, Math.min(e.clientY - rect.top, rect.height));

                const x = Math.min(this.selectionStart.x, currentX);
                const y = Math.min(this.selectionStart.y, currentY);
                const w = Math.abs(currentX - this.selectionStart.x);
                const h = Math.abs(currentY - this.selectionStart.y);

                this.selectionBoxEl.style.left = `${x}px`;
                this.selectionBoxEl.style.top = `${y}px`;
                this.selectionBoxEl.style.width = `${w}px`;
                this.selectionBoxEl.style.height = `${h}px`;
            }
        });

        window.addEventListener("mouseup", (e) => {
            if (this.isPanning) {
                this.isPanning = false;
                this.container.style.cursor = "default";
            }
            if (this.isBoxSelecting) {
                this.isBoxSelecting = false;
                this.selectionBoxEl.classList.add("hidden");
                this.applyBoxSelection();
            }
        });
    }

    updateTransform() {
        this.workspace.style.transform = `translate(${this.transform.x}px, ${this.transform.y}px) scale(${this.transform.scale})`;
        
        // Update background grid position so it pans with the workspace
        this.container.style.backgroundPosition = `${this.transform.x}px ${this.transform.y}px`;
        // Scale grid background?
        const baseSize = 40;
        this.container.style.backgroundSize = `${baseSize * this.transform.scale}px ${baseSize * this.transform.scale}px`;
    }

    // Tọa độ Screen (từ chuột) sang World (tọa độ trong Workspace)
    screenToWorld(clientX, clientY) {
        const rect = this.container.getBoundingClientRect();
        const x = (clientX - rect.left - this.transform.x) / this.transform.scale;
        const y = (clientY - rect.top - this.transform.y) / this.transform.scale;
        return { x, y };
    }

    addNode(node) {
        if (node instanceof TargetLayerNode) {
            // Check Singleton
            const existing = this.nodes.find(n => n instanceof TargetLayerNode);
            if (existing) {
                console.warn("Chỉ cho phép 1 Target Layer Node!");
                return;
            }
        }

        this.nodes.push(node);
        node.graph = this;
        this.nodesLayer.appendChild(node.el);
        node.updatePosition();
    }

    removeNode(node) {
        node.disposed = true;
        if (node.dispose) node.dispose();
        this.wires.filter(w => w.sourcePort.node === node || (w.targetPort && w.targetPort.node === node)).forEach(w => this.removeWire(w));
        this.nodes = this.nodes.filter(n => n !== node);
        if(node.el && node.el.parentNode) {
            node.el.parentNode.removeChild(node.el);
        }
        this.selectedNodes.delete(node);
        // TODO: Xóa các dây nối liên quan
    }

    addWire(wire) {
        this.wires.push(wire);
        this.svgLayer.appendChild(wire.el);
        wire.updatePath();
    }

    removeWire(wire) {
        if (!wire) return;
        
        // Kiểm tra xem đây có phải là dây thật (đã nối xong vào Target Port) không
        const isRealWire = wire.sourcePort && wire.targetPort;

        this.wires = this.wires.filter(w => w !== wire);
        if(wire.el && wire.el.parentNode) {
            wire.el.parentNode.removeChild(wire.el);
        }
        
        // Remove from port's array
        if (wire.sourcePort) {
            wire.sourcePort.wires = wire.sourcePort.wires.filter(w => w !== wire);
            if (wire.sourcePort.node.onConnectionChanged) wire.sourcePort.node.onConnectionChanged(wire.sourcePort);
        }
        if (wire.targetPort) {
            wire.targetPort.wires = wire.targetPort.wires.filter(w => w !== wire);
            if (wire.targetPort.node.onConnectionChanged) wire.targetPort.node.onConnectionChanged(wire.targetPort);
        }
        
        // Nếu là dây thật bị rút, tự động lưu
        if (isRealWire && window.triggerAutoSave && !this.isClearing && !this.isRestoring) {
            window.triggerAutoSave();
        }
    }

    clearSelection() {
        this.selectedNodes.forEach(node => node.setSelected(false));
        this.selectedNodes.clear();
    }

    selectNode(node, add = false) {
        if (!add) this.clearSelection();
        node.setSelected(true);
        this.selectedNodes.add(node);
        // Move to top
        this.nodesLayer.appendChild(node.el);
    }

    applyBoxSelection() {
        const rect = this.container.getBoundingClientRect();
        
        const boxLeft = parseFloat(this.selectionBoxEl.style.left);
        const boxTop = parseFloat(this.selectionBoxEl.style.top);
        const boxWidth = parseFloat(this.selectionBoxEl.style.width);
        const boxHeight = parseFloat(this.selectionBoxEl.style.height);

        // Chuyển ô vuông Box Selection từ tọa độ Container sang tọa độ World
        const p1 = this.screenToWorld(rect.left + boxLeft, rect.top + boxTop);
        const p2 = this.screenToWorld(rect.left + boxLeft + boxWidth, rect.top + boxTop + boxHeight);
        
        const worldBox = {
            left: Math.min(p1.x, p2.x),
            right: Math.max(p1.x, p2.x),
            top: Math.min(p1.y, p2.y),
            bottom: Math.max(p1.y, p2.y)
        };

        this.nodes.forEach(node => {
            if (node.x + node.width > worldBox.left && node.x < worldBox.right &&
                node.y + node.height > worldBox.top && node.y < worldBox.bottom) {
                node.setSelected(true);
                this.selectedNodes.add(node);
            }
        });
    }

    clearAll() {
        this.restoreVersion = (this.restoreVersion || 0) + 1;
        this.pendingWires = [];
        this.isClearing = true;
        // Xóa hết Wires
        while (this.wires.length > 0) {
            this.removeWire(this.wires[0]);
        }
        // Xóa hết Nodes
        while (this.nodes.length > 0) {
            this.removeNode(this.nodes[0]);
        }
        this.transform = { x: 0, y: 0, scale: 1 };
        this.updateTransform();
        this.isClearing = false;
    }

    serialize() {
        const data = {
            transform: this.transform,
            nodes: this.nodes.map(n => {
                if (typeof n.serialize === "function") {
                    return n.serialize();
                } else {
                    return {
                        id: n.id,
                        type: n.constructor.name,
                        x: n.x,
                        y: n.y,
                        customName: n.customName,
                        values: n.getValues()
                    };
                }
            }),
            wires: this.wires.filter(w => w.sourcePort && w.targetPort).map(w => ({
                sourcePortId: w.sourcePort.id,
                targetPortId: w.targetPort.id
            }))
        };
        return JSON.stringify(data);
    }

    serializeSelection() {
        const selectedArr = Array.from(this.selectedNodes);
        if (selectedArr.length === 0) return null;

        // Chỉ copy các wires nằm nội bộ trong nhóm các node được chọn
        const selectedWires = this.wires.filter(w => 
            this.selectedNodes.has(w.sourcePort.node) && 
            this.selectedNodes.has(w.targetPort.node)
        );

        // Tính bounding box để tí nữa dán ra vị trí mới tương đối
        let minX = Infinity;
        let minY = Infinity;
        selectedArr.forEach(n => {
            if (n.x < minX) minX = n.x;
            if (n.y < minY) minY = n.y;
        });

        const data = {
            isSelection: true,
            minX: minX,
            minY: minY,
            nodes: selectedArr.map(n => {
                if (typeof n.serialize === "function") {
                    return n.serialize();
                } else {
                    return {
                        id: n.id,
                        type: n.constructor.name,
                        x: n.x,
                        y: n.y,
                        customName: n.customName,
                        values: n.getValues()
                    };
                }
            }),
            wires: selectedWires.map(w => ({
                sourcePortId: w.sourcePort.id,
                targetPortId: w.targetPort.id
            }))
        };
        return JSON.stringify(data);
    }

    deserializeSelection(jsonStr, targetWorldX, targetWorldY) {
        try {
            const data = JSON.parse(jsonStr);
            if (!data.isSelection || !data.nodes || data.nodes.length === 0) return null;

            this.clearSelection();

            const oldToNewIdMap = {};
            const newNodes = [];

            // Tính offset dời khối node tới vị trí chuột
            const offsetX = targetWorldX - data.minX;
            const offsetY = targetWorldY - data.minY;

            data.nodes.forEach(nData => {
                if (typeof window.instantiateNode !== "function") return;
                
                const node = window.instantiateNode(nData.type);
                if (node) {
                    oldToNewIdMap[nData.id] = node.id; // Map ID cũ -> ID mới ngẫu nhiên của node vừa sinh
                    
                    if (nData.customName) node.customName = nData.customName;
                    
                    // Phục hồi giá trị
                    if (nData.values && typeof node.setValues === "function") {
                        node.setValues(nData.values);
                    } else if (typeof node.deserialize === "function") {
                        const freshId = node.id; // Lưu lại ID mới
                        node.deserialize(nData);
                        node.id = freshId; // Trả lại ID mới, tránh bị đè bằng ID cũ
                    }

                    // Tọa độ mới
                    node.x = nData.x + offsetX;
                    node.y = nData.y + offsetY;
                    node.updatePosition();
                    
                    this.addNode(node);
                    this.selectNode(node, true);
                    newNodes.push(node);
                }
            });

            // Phục hồi dây nối nội bộ, chú ý phải update ID cổng vì node.id đã đổi!
            if (data.wires) {
                data.wires.forEach(wData => {
                    // ID cũ của node chứa cổng đó
                    const oldSourceNodeId = wData.sourcePortId.replace(/_out_\d+$/, "");
                    const oldTargetNodeId = wData.targetPortId.replace(/_in_\d+$/, "");

                    const newSourceNodeId = oldToNewIdMap[oldSourceNodeId];
                    const newTargetNodeId = oldToNewIdMap[oldTargetNodeId];

                    if (newSourceNodeId && newTargetNodeId) {
                        const sourceNode = this.nodes.find(n => n.id === newSourceNodeId);
                        const targetNode = this.nodes.find(n => n.id === newTargetNodeId);

                        if (sourceNode && targetNode) {
                            // Tạo ID cổng mới tương ứng với ID node mới
                            const newSourcePortId = wData.sourcePortId.replace(oldSourceNodeId, newSourceNodeId);
                            const newTargetPortId = wData.targetPortId.replace(oldTargetNodeId, newTargetNodeId);

                            const sourcePort = sourceNode.outputs.find(p => p.id === newSourcePortId);
                            const targetPort = targetNode.inputs.find(p => p.id === newTargetPortId);
                            
                            if (sourcePort && targetPort) {
                                const wire = new Wire(sourcePort, targetPort);
                                sourcePort.wires.push(wire);
                                targetPort.wires.push(wire);
                                this.addWire(wire);
                                if (targetPort.node.onConnectionChanged) targetPort.node.onConnectionChanged(targetPort);
                            }
                        }
                    }
                });
            }

            return newNodes;
        } catch (e) {
            console.error("Deserialize selection failed:", e);
            return null;
        }
    }

    deserialize(jsonStr, keepViewport = false) {
        const wasRestoring = this.isRestoring;
        this.isRestoring = true;
        try {
            const data = JSON.parse(jsonStr);

            // Lưu lại tọa độ viewport cũ nếu đang Undo
            const oldX = this.transform.x;
            const oldY = this.transform.y;
            const oldScale = this.transform.scale;

            this.clearAll();

            if (keepViewport) {
                this.transform.x = oldX;
                this.transform.y = oldY;
                this.transform.scale = oldScale;
            } else if (data.transform) {
                this.transform = data.transform;
            }
            this.updateTransform();

            const portMap = {}; // Lưu trữ tham chiếu từ ID -> Port Object

            // 1. Phục hồi Nodes
            data.nodes.forEach(nData => {
                let node;
                
                if (typeof window.instantiateNode === "function") {
                    node = window.instantiateNode(nData.type);
                }
                
                if (!node) {
                    // Fallback for older nodes or if createNode fails
                    if (nData.type === "MathNode") node = new MathNode();
                else if (nData.type === "OperatorsNode" || nData.type === "SimpleMathNode") node = new SimpleMathNode();
                else if (nData.type === "ValueNode") node = new ValueNode();
                else if (nData.type === "AngleNode") node = new AngleNode();
                else if (nData.type === "CheckboxNode") node = new CheckboxNode();
                else if (nData.type === "ColorNode") node = new ColorNode();
                else if (nData.type === "SourceLayerNode") node = new SourceLayerNode();
                else if (nData.type === "TargetLayerNode") node = new TargetLayerNode();
                else if (nData.type === "JSMathNode") node = new JSMathNode();
                else if (nData.type === "JSConstantNode") node = new JSConstantNode();
                else if (nData.type === "ConversionMathNode" || nData.type === "AngleConversionNode") node = new AngleConversionNode();
                else if (nData.type === "ToStringNode") node = new ToStringNode();
                else if (nData.type === "ColorConversionNode") node = new ColorConversionNode();
                else if (nData.type === "CombineVectorNode") node = new CombineVectorNode();
                else if (nData.type === "SplitVectorNode") node = new SplitVectorNode();
                else if (nData.type === "SelfValueNode") node = new SelfValueNode();
                else if (nData.type === "InterpolationNode") node = new InterpolationNode();
                else if (nData.type === "WigglerNode") node = new WigglerNode();
                else if (nData.type === "RandomNode") node = new RandomNode();
                else if (nData.type === "NoiseNode") node = new NoiseNode();
                else node = new Node("Unknown");
                } // End if (!node)

                node.id = nData.id;
                node.x = nData.x;
                node.y = nData.y;
                if (nData.customName) {
                    node.customName = nData.customName;
                    if (node.updateTitle) node.updateTitle();
                }
                if (node.setValues && nData.values) node.setValues(nData.values);

                // FIX LỖI MẤT WIRE: Cập nhật lại ID của các cổng theo node.id mới nạp
                node.inputs.forEach((p, i) => p.id = `${node.id}_in_${i}`);
                node.outputs.forEach((p, i) => p.id = `${node.id}_out_${i}`);

                this.addNode(node);

            });

            // 2. Phục hồi Wires (Lưu vào pending thay vì nối ngay)
            if (data.wires) {
                this.pendingWires = data.wires;
                const version = this.restoreVersion;
                requestAnimationFrame(() => {
                    if (version !== this.restoreVersion) return;
                    this.resolvePendingWires();
                    if (!wasRestoring) this.isRestoring = false;
                    if (window.graphSession) window.graphSession.finishLoad();
                });
            }
        } catch (e) {
            this.isRestoring = wasRestoring;
            throw e;
        }
    }

    resolvePendingWires() {
        if (!this.pendingWires || this.pendingWires.length === 0) return;
        const remaining = [];
        
        this.pendingWires.forEach(wData => {
            let sourcePort = null;
            let targetPort = null;
            
            this.nodes.forEach(n => {
                n.outputs.forEach(p => { if (p.id === wData.sourcePortId) sourcePort = p; });
                n.inputs.forEach(p => { if (p.id === wData.targetPortId) targetPort = p; });
            });

            if (sourcePort && targetPort) {
                const wire = new Wire(sourcePort, targetPort);
                wire.updateColor();
                targetPort.wires.push(wire);
                sourcePort.wires.push(wire);
                this.addWire(wire);
                
                if (targetPort.node.onConnectionChanged) targetPort.node.onConnectionChanged(targetPort);
                if (sourcePort.node.onConnectionChanged) sourcePort.node.onConnectionChanged(sourcePort);
            } else {
                remaining.push(wData);
            }
        });
        
        this.pendingWires = remaining;
    }

    pushHistory() {
        const state = this.serialize();
        if (this.historyIndex < this.history.length - 1) {
            this.history = this.history.slice(0, this.historyIndex + 1);
        }
        if (this.history.length > 0 && this.history[this.history.length - 1] === state) return;

        this.history.push(state);
        if (this.history.length > 20) {
            this.history.shift();
        } else {
            this.historyIndex++;
        }
    }

    undo() {
        if (this.historyIndex > 0) {
            this.historyIndex--;
            if (window.graphSession) window.graphSession.restoreHistory(this.history[this.historyIndex]);
            else this.deserialize(this.history[this.historyIndex], true);
        }
    }

    redo() {
        if (this.historyIndex < this.history.length - 1) {
            this.historyIndex++;
            if (window.graphSession) window.graphSession.restoreHistory(this.history[this.historyIndex]);
            else this.deserialize(this.history[this.historyIndex], true);
        }
    }

    selectAll() {
        this.clearSelection();
        this.nodes.forEach(node => this.selectNode(node, true));
    }

    deselectAll() {
        this.clearSelection();
    }

    deleteSelected() {
        const selectedNodes = this.nodes.filter(n => n.el.classList.contains("selected"));
        if (selectedNodes.length === 0) return;
        
        // Gọi Custom Modal thay vì confirm()
        if (typeof ModalService !== "undefined") {
            ModalService.confirm(
                "Confirm Delete",
                `Are you sure that these ${selectedNodes.length} node(s) will be deleted? This action can be undone.`,
                () => {
                    selectedNodes.forEach(n => this.removeNode(n));
                    window.triggerAutoSave();
                }
            );
        } else {
            if(confirm(`Are you sure you want to delete ${selectedNodes.length} nodes?`)) {
                selectedNodes.forEach(n => this.removeNode(n));
                window.triggerAutoSave();
            }
        }
    }
}
