/**
 * Node - Lớp cơ sở cho mọi Node
 */
class Node {
    constructor(title, options = {}) {
        this.title = title || "Node";
        this.id = "node_" + Math.random().toString(36).substr(2, 9);
        this.graph = null;
        this.x = 0;
        this.y = 0;
        
        // Cấu hình giao diện (Tailwind classes)
        this.width = options.width || 180;
        this.height = options.height || 100;
        this.headerBgClass = options.headerBgClass || "bg-surface-variant/50";
        this.headerBorderClass = options.headerBorderClass || "border-outline-variant/30";
        this.headerTextClass = options.headerTextClass || "text-on-surface";
        this.nodeBorderClass = options.nodeBorderClass || "border-outline-variant/30";
        this.nodeBgClass = options.nodeBgClass || "bg-surface-container/80";
        
        this.inputs = [];
        this.outputs = [];
        this.customName = "";
        this.sessionGeneration = window.graphSession ? window.graphSession.generation : 0;
        this.requestVersion = 0;
        this.disposed = false;
        
        this.el = this.createDOM();
        this.initEvents();
    }

    requestHost(script, callback) {
        if (!window.csInterface) return;
        if (window.graphSession) window.graphSession.nodeRequest(this, script, callback);
        else window.csInterface.evalScript(script, callback);
    }

    dispose() {
        this.bodyEl.querySelectorAll("input").forEach(input => { if (input.disposeDrag) input.disposeDrag(); });
        for (const dropdown of [this.compDropdown, this.layerDropdown]) {
            if (dropdown && dropdown.dispose) dropdown.dispose();
        }
    }

    createDOM() {
        const el = document.createElement("div");
        // Class chuẩn theo DESIGN.md (Soft Minimalism)
        el.className = `node absolute ${this.nodeBgClass} backdrop-blur-md rounded border ${this.nodeBorderClass} flex flex-col pointer-events-auto`;
        el.style.width = `${this.width}px`;
        
        // Header
        const header = document.createElement("div");
        header.className = `node-header h-6 ${this.headerBgClass} border-b ${this.headerBorderClass} rounded-t px-2 flex items-center select-none`;
        
        this.titleSpan = document.createElement("span");
        this.titleSpan.className = `font-mono-label text-mono-label ${this.headerTextClass}`;
        this.titleSpan.innerText = this.title;
        header.appendChild(this.titleSpan);
        
        // Body (Ports & Controls)
        const body = document.createElement("div");
        body.className = "node-body p-2 space-y-2 relative flex-1";

        el.appendChild(header);
        el.appendChild(body);
        
        this.headerEl = header;
        this.bodyEl = body;
        
        return el;
    }

    initEvents() {
        // Dragging the node
        this.el.addEventListener("mousedown", (e) => {
            if (e.button !== 0 || (window.canEditGraph && !window.canEditGraph())) return;
            e.stopPropagation(); // Ngăn Box Selection của Graph

            if (!this.graph) return;

            // Nếu Node chưa được chọn, chọn nó. Nếu ko ấn Shift, xóa chọn cũ.
            if (!this.graph.selectedNodes.has(this)) {
                this.graph.selectNode(this, e.shiftKey);
            }

            // Lưu tọa độ ban đầu của MỌI node đang chọn
            this.graph.selectedNodes.forEach(n => {
                n._dragStart = { x: n.x, y: n.y };
            });

            // Tọa độ chuột ban đầu (World)
            const startWorld = this.graph.screenToWorld(e.clientX, e.clientY);

            let moved = false;
            const generation = this.sessionGeneration;
            const valid = () => !this.disposed && (!window.graphSession || (generation === window.graphSession.generation && window.canEditGraph()));
            const onMouseMove = (moveEvent) => {
                if (!valid()) return;
                const currentWorld = this.graph.screenToWorld(moveEvent.clientX, moveEvent.clientY);
                const dx = currentWorld.x - startWorld.x;
                const dy = currentWorld.y - startWorld.y;
                moved = moved || dx !== 0 || dy !== 0;

                this.graph.selectedNodes.forEach(n => {
                    n.x = n._dragStart.x + dx;
                    n.y = n._dragStart.y + dy;
                    n.updatePosition();
                });
            };

            const cancel = () => {
                document.removeEventListener("mousemove", onMouseMove);
                document.removeEventListener("mouseup", finish);
                window.removeEventListener("graph-session-ending", cancel);
            };
            const finish = () => {
                cancel();
                if (moved && valid() && window.triggerAutoSave) window.triggerAutoSave();
            };
            window.addEventListener("graph-session-ending", cancel);
            document.addEventListener("mousemove", onMouseMove);
            document.addEventListener("mouseup", finish, { once: true });
        });

        // Bắt sự kiện đổi số (Change Value)
        this.bodyEl.addEventListener("change", (e) => {
            if (e.target.tagName === "INPUT" || e.target.tagName === "SELECT") {
                if (window.triggerAutoSave) window.triggerAutoSave();
            }
        });
    }

    updatePosition() {
        this.el.style.transform = `translate(${this.x}px, ${this.y}px)`;
        // Update Wires
        this.inputs.forEach(p => p.updateWires());
        this.outputs.forEach(p => p.updateWires());
    }

    setSelected(isSelected) {
        if (isSelected) {
            this.el.classList.add("selected");
        } else {
            this.el.classList.remove("selected");
        }
    }

    addInput(name, type, labelStr = null) {
        const port = new Port(this, name, type, 'in', labelStr);
        this.inputs.push(port);
        this.bodyEl.appendChild(port.el);
        return port;
    }

    addOutput(name, type, labelStr = null) {
        const port = new Port(this, name, type, 'out', labelStr);
        this.outputs.push(port);
        this.bodyEl.appendChild(port.el);
        return port;
    }

    getValues() {
        // Quét toàn bộ thẻ input/select trong bodyEl
        const inputs = Array.from(this.bodyEl.querySelectorAll("input, select"));
        return inputs.map(el => el.value);
    }

    setValues(values) {
        if (!values) return;
        const inputs = Array.from(this.bodyEl.querySelectorAll("input, select"));
        inputs.forEach((el, index) => {
            if (values[index] !== undefined) el.value = values[index];
        });
    }

    updateTitle() {
        if (this.customName) {
            this.titleSpan.innerText = this.customName;
        } else {
            this.titleSpan.innerText = this.title;
        }
    }

    serialize() {
        return {
            id: this.id,
            type: this.constructor.name,
            x: this.x,
            y: this.y,
            customName: this.customName,
            values: this.getValues()
        };
    }

    deserialize(data) {
        this.id = data.id;
        this.x = data.x;
        this.y = data.y;
        if (data.customName) {
            this.customName = data.customName;
            this.updateTitle();
        }
        this.setValues(data.values);
        this.updatePosition();
    }
}
