class CheckboxNode extends Node {
    constructor() {
        super("Checkbox", {
            width: 180,
            headerBgClass: "bg-surface-variant/80",
            headerBorderClass: "border-outline-variant/30",
            headerTextClass: "text-on-surface"
        });

        const portOut = this.addOutput("", "1D");
        portOut.el.remove();
        portOut.el.style.position = "absolute";
        portOut.el.style.right = "-6px";
        portOut.el.style.top = "50%";
        portOut.el.style.transform = "translateY(-50%)";
        this.el.appendChild(portOut.el);

        const container = document.createElement("div");
        container.className = "flex flex-col space-y-2 mt-2 gap-2";

        // Mode Dropdown
        this.modeSelect = document.createElement("select");
        this.modeSelect.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none";
        this.modeSelect.innerHTML = `
            <option value="1">Output [0, 1]</option>
            <option value="100">Output [0, 100]</option>
        `;
        container.appendChild(this.modeSelect);

        // Checkbox UI
        this.checkContainer = document.createElement("div");
        this.checkContainer.className = "flex items-center justify-center py-2 cursor-pointer group";
        
        this.iconValue = document.createElement("div");
        this.checkContainer.appendChild(this.iconValue);
        container.appendChild(this.checkContainer);

        // Msg Container
        this.kfMsg = document.createElement("div");
        this.kfMsg.className = "w-full bg-green-500/20 border border-green-500/50 rounded py-2 text-center text-green-300 font-body-sm hidden";
        this.kfMsg.innerText = "Managed by AE Keyframes";
        container.appendChild(this.kfMsg);

        // Checkboxes Container (Control/Kf)
        const cbContainer = document.createElement("div");
        cbContainer.className = "flex flex-col space-y-2 mt-2 pt-2 border-t border-outline-variant/30";

        const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
        const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;
        
        const valueActiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
        const valueInactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent" class="group-hover:stroke-[#7C4DFF] transition-colors"/></svg>`;

        this.valueActiveSVG = valueActiveSVG;
        this.valueInactiveSVG = valueInactiveSVG;

        // Control Checkbox
        const rowControl = document.createElement("div");
        rowControl.className = "flex items-center space-x-2 cursor-pointer group";
        this.iconControl = document.createElement("div");
        this.iconControl.innerHTML = inactiveSVG;
        const lblControl = document.createElement("span");
        lblControl.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
        lblControl.innerText = "Use Control";
        rowControl.appendChild(this.iconControl);
        rowControl.appendChild(lblControl);
        cbContainer.appendChild(rowControl);

        // Keyframe Checkbox
        const rowKf = document.createElement("div");
        rowKf.className = "flex items-center space-x-2 cursor-pointer group";
        this.iconKf = document.createElement("div");
        this.iconKf.innerHTML = inactiveSVG;
        const lblKf = document.createElement("span");
        lblKf.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
        lblKf.innerText = "Use Keyframe";
        rowKf.appendChild(this.iconKf);
        rowKf.appendChild(lblKf);
        cbContainer.appendChild(rowKf);

        container.appendChild(cbContainer);
        this.bodyEl.insertBefore(container, this.bodyEl.lastElementChild);

        // State
        this.state = { mode: "1", value: false, control: false, kf: false };

        // Events
        this.modeSelect.addEventListener("change", (e) => {
            this.state.mode = e.target.value;
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        this.checkContainer.addEventListener("click", () => {
            this.state.value = !this.state.value;
            this.updateCheckboxes();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        rowControl.addEventListener("click", () => {
            this.state.control = !this.state.control;
            if (!this.state.control) this.state.kf = false;
            this.updateCheckboxes();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        rowKf.addEventListener("click", () => {
            this.state.kf = !this.state.kf;
            if (this.state.kf) this.state.control = true;
            this.updateCheckboxes();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        this.updateCheckboxes();
    }

    updateCheckboxes() {
        const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
        const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;
        
        this.iconControl.innerHTML = this.state.control ? activeSVG : inactiveSVG;
        this.iconKf.innerHTML = this.state.kf ? activeSVG : inactiveSVG;
        
        if (this.state.kf) {
            this.checkContainer.classList.add("hidden");
            this.checkContainer.classList.remove("flex");
            this.kfMsg.classList.remove("hidden");
        } else {
            this.checkContainer.classList.add("flex");
            this.checkContainer.classList.remove("hidden");
            this.kfMsg.classList.add("hidden");
        }
        this.iconValue.innerHTML = this.state.value ? this.valueActiveSVG : this.valueInactiveSVG;
    }

    serialize() {
        const data = super.serialize();
        data.state = this.state;
        return data;
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.state) {
            this.state = data.state;
            this.modeSelect.value = this.state.mode;
            this.updateCheckboxes();
        }
    }

    getControlPayload() {
        if (!this.state.control && !this.state.kf) return null;
        return {
            type: "ADBE Checkbox Control",
            value: this.state.value ? 1 : 0,
            useKeyframe: this.state.kf
        };
    }
}
