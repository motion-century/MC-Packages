/* Read-only reference; keyboard dispatch remains in the editor handlers. */
class ShortcutHelp {
    static entries = [
        ["Add Node", ["Shift", "A"], "Open Add Node at the pointer. Type to filter nodes by name or group."],
        ["Select All", ["A"], "Select every node while the canvas has focus."],
        ["Deselect All", ["A", "A"], "Press A twice within 300 ms to clear the selection."],
        ["Duplicate", ["Shift", "D"], "Duplicate selected nodes and their internal wires. Move the pointer, then left click to confirm or right click to reset placement."],
        ["Copy", ["Ctrl", "C"], "Copy selected nodes and their internal connections to the system clipboard."],
        ["Paste", ["Ctrl", "V"], "Paste compatible copied nodes at the pointer position."],
        ["Delete", ["Delete", "/", "X"], "Ask for confirmation before deleting selected nodes."],
        ["Rename", ["F2"], "Rename the node. Exactly one node must be selected."],
        ["Undo", ["Ctrl", "Z"], "Undo the latest graph edit. Editing is paused while the graph restores."],
        ["Sync", ["R"], "Refresh the graph and properties for the current owner. A pinned graph keeps its owner."],
        ["Search Results", ["↑", "/", "↓"], "Navigate filtered Add Node results while its search field is focused."],
        ["Add Result", ["Enter"], "Add the highlighted search result, or the first result when none is highlighted."],
        ["Close Menu", ["Esc"], "Close Add Node. Duplicate placement uses right click to reset instead."],
        ["Confirm", ["Enter"], "Confirm the focused Rename or Delete dialog."],
        ["Cancel", ["Esc"], "Cancel the focused Rename or Delete dialog."],
        ["Pan", ["MMB drag"], "Move the canvas with middle mouse drag, or Alt + left mouse drag."],
        ["Zoom", ["Wheel"], "Zoom the canvas around the pointer position."]
    ];

    static init() {
        if (this.button) return;
        this.button = document.getElementById("btn-shortcut-help");
        this.panel = document.getElementById("shortcut-help");
        this.tooltip = document.getElementById("shortcut-tooltip");
        this.list = document.getElementById("shortcut-list");
        if (!this.button || !this.panel || !this.tooltip || !this.list) return;
        this.entries.forEach(([label, keys, description]) => {
            const row = document.createElement("div");
            row.className = "shortcut-row";
            row.tabIndex = 0;
            row.setAttribute("role", "listitem");
            row.dataset.description = description;
            const name = document.createElement("span"); name.textContent = label;
            const combination = document.createElement("span"); combination.className = "shortcut-keys";
            keys.forEach((key, index) => {
                if (index && !keys.includes("/") && label !== "Deselect All") {
                    const plus = document.createElement("span"); plus.textContent = "+"; combination.appendChild(plus);
                }
                if (index && label === "Deselect All") {
                    const then = document.createElement("span"); then.textContent = ","; combination.appendChild(then);
                }
                const cap = document.createElement(key === "/" ? "span" : "kbd");
                cap.textContent = key; combination.appendChild(cap);
            });
            row.appendChild(name); row.appendChild(combination); this.list.appendChild(row);
        });
        this.button.addEventListener("click", () => this.isOpen() ? this.hide(true) : this.show());
        document.getElementById("btn-shortcut-close").addEventListener("click", () => this.hide(true));
        document.addEventListener("mousedown", event => {
            if (this.isOpen() && !this.containsTarget(event.target)) this.hide(false);
        });
        document.addEventListener("keydown", event => {
            if (!this.isOpen()) return;
            if (event.key === "Escape") {
                // Leave keys in a blocking editor dialog to that dialog.
                if (event.target.closest && event.target.closest("#rename-modal-overlay, #modal-container, #color-picker-container")) return;
                event.preventDefault(); event.stopImmediatePropagation(); this.hide(true);
            } else if (this.containsTarget(event.target)) {
                event.stopPropagation();
            }
        }, true);
        this.list.addEventListener("mouseover", event => {
            const row = event.target.closest(".shortcut-row");
            if (row && !row.contains(event.relatedTarget)) this.queueTooltip(row);
        });
        this.list.addEventListener("mouseout", event => {
            const row = event.target.closest(".shortcut-row");
            if (row && !row.contains(event.relatedTarget) && !row.contains(document.activeElement)) this.hideTooltip();
        });
        this.list.addEventListener("focusin", event => this.queueTooltip(event.target.closest(".shortcut-row"), true));
        this.list.addEventListener("focusout", () => this.hideTooltip());
        this.list.addEventListener("scroll", () => {
            const row = document.activeElement && document.activeElement.closest(".shortcut-row");
            if (row && this.list.contains(row)) this.queueTooltip(row, true);
            else this.hideTooltip();
        }, {passive:true});
        window.addEventListener("resize", () => this.hideTooltip());
        window.addEventListener("debug-console-opened", () => this.hide(false));
    }

    static containsTarget(target) {
        return !!(target && target.closest && target.closest("#panel-actions, #shortcut-help, #shortcut-tooltip, #debug-console"));
    }
    static isOpen() { return this.panel && !this.panel.hidden; }
    static show() {
        if (document.querySelector("#rename-modal-overlay:not(.hidden), #modal-container:not(.hidden), #color-picker-container:not(.hidden)")) return;
        window.dispatchEvent(new Event("shortcut-help-opened"));
        if (typeof hideAddNodeMenu === "function") hideAddNodeMenu();
        this.panel.hidden = false;
        this.button.setAttribute("aria-expanded", "true");
        this.list.scrollTop = 0;
    }
    static hide(restoreFocus) {
        if (!this.panel) return;
        this.hideTooltip(); this.panel.hidden = true;
        this.button.setAttribute("aria-expanded", "false");
        if (restoreFocus) this.button.focus();
    }
    static queueTooltip(row, immediate = false) {
        this.hideTooltip();
        if (!row) return;
        const show = () => {
            if (!this.isOpen() || !row.isConnected) return;
            this.activeRow = row;
            this.tooltip.textContent = row.dataset.description;
            this.tooltip.hidden = false;
            row.setAttribute("aria-describedby", "shortcut-tooltip");
            const rect = row.getBoundingClientRect(), tip = this.tooltip.getBoundingClientRect();
            let left = rect.left - tip.width - 10;
            if (left < 8) left = rect.right - tip.width;
            this.tooltip.style.left = Math.max(8, Math.min(left, window.innerWidth - tip.width - 8)) + "px";
            this.tooltip.style.top = Math.max(8, Math.min(rect.top, window.innerHeight - tip.height - 8)) + "px";
        };
        if (immediate) show(); else this.tooltipTimer = setTimeout(show, 180);
    }
    static hideTooltip() {
        clearTimeout(this.tooltipTimer);
        if (this.activeRow) this.activeRow.removeAttribute("aria-describedby");
        this.activeRow = null;
        if (this.tooltip) this.tooltip.hidden = true;
    }
}
