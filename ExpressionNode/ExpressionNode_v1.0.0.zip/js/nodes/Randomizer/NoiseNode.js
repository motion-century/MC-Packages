class NoiseNode extends Node {
  constructor() {
    super("Noise", {
      width: 180,
      headerBgClass: "bg-[#e53935]", // Đỏ cho Randomizer
      headerBorderClass: "border-[#e53935]/30",
      headerTextClass: "text-[#ffebee]",
    });

    this.group = "Randomizer";
    this.icon = "graphic_eq";

    const portIn = this.addInput("", "ANY_NUM");
    const portOut = this.addOutput("", "ANY");

    portIn.el.remove();
    portOut.el.remove();

    const container = document.createElement("div");
    container.className = "flex flex-col space-y-2 mb-2 gap-2 mt-2";

    // Type Dropdown
    this.typeSelect = document.createElement("select");
    this.typeSelect.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none";
    
    const types = [
      { value: "time", text: "Time" },
      { value: "custom", text: "Custom" }
    ];

    types.forEach(t => {
      const option = document.createElement("option");
      option.value = t.value;
      option.innerText = t.text;
      this.typeSelect.appendChild(option);
    });

    container.appendChild(this.typeSelect);

    // Time Mode: Speed Input
    this.timeWrapper = document.createElement("div");
    this.timeWrapper.className = "w-full flex flex-col space-y-1";

    const titleLabel = document.createElement("span");
    titleLabel.className = "font-label-caps text-label-caps text-on-surface-variant text-left";
    titleLabel.innerText = "Speed";
    this.timeWrapper.appendChild(titleLabel);

    const inputRow = document.createElement("div");
    inputRow.className = "w-full flex items-center";
    
    const speedLabel = document.createElement("span");
    speedLabel.className = "font-label-caps text-label-caps text-on-surface-variant w-4 text-center mr-1";
    speedLabel.innerText = "x";
    inputRow.appendChild(speedLabel);

    this.speedInput = document.createElement("input");
    this.speedInput.className = "flex-1 min-w-0 bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
    this.speedInput.type = "text";
    this.speedInput.value = "1";
    UIUtils.makeInputDraggable(this.speedInput);
    inputRow.appendChild(this.speedInput);

    this.timeWrapper.appendChild(inputRow);
    container.appendChild(this.timeWrapper);

    // Custom Mode: Input Port
    this.customWrapper = document.createElement("div");
    this.customWrapper.className = "w-full flex items-center relative py-1 hidden";
    portIn.el.className = "relative flex items-center";
    this.customWrapper.appendChild(portIn.el);
    const labelIn = document.createElement("span");
    labelIn.className = "font-label-caps text-label-caps text-on-surface-variant mx-1";
    labelIn.innerText = "Input";
    this.customWrapper.appendChild(labelIn);
    
    container.appendChild(this.customWrapper);

    // Output row
    const outRow = document.createElement("div");
    outRow.className = "w-full flex justify-end items-center relative mt-2 pt-2 border-t border-outline-variant/30";
    portOut.el.className = "relative flex items-center";
    outRow.appendChild(portOut.el);
    container.appendChild(outRow);

    this.bodyEl.appendChild(container);

    this.typeSelect.addEventListener("change", () => {
        this.updateMode();
        if (window.triggerAutoSave) window.triggerAutoSave();
    });
  }

  updateMode() {
      if (this.typeSelect.value === "time") {
          this.timeWrapper.classList.remove("hidden");
          this.customWrapper.classList.add("hidden");
      } else {
          this.timeWrapper.classList.add("hidden");
          this.customWrapper.classList.remove("hidden");
      }
      this.updatePosition();
  }

  getValues() {
    return [
        this.typeSelect.value,
        this.speedInput.value
    ];
  }

  setValues(values) {
    if (values && values.length >= 2) {
      this.typeSelect.value = values[0];
      this.speedInput.value = values[1];
      this.updateMode();
    }
  }
}
