class ValueNode extends Node {
    constructor() {
        super("Value", {
            width: 180,
            headerBgClass: "bg-surface-variant/80",
            headerBorderClass: "border-outline-variant/30",
            headerTextClass: "text-on-surface"
        });

        const portOut = this.addOutput("", "1D");
        portOut.el.remove();
        portOut.el.style.position = "absolute";
        portOut.el.style.right = "-6px";
        portOut.el.style.top = "50%";
        portOut.el.style.transform = "translateY(-50%)";
        this.el.appendChild(portOut.el);

        const container = document.createElement("div");
        container.className = "flex flex-col space-y-2 mt-2 gap-2";

        // Dimension Dropdown
        this.dimSelect = document.createElement("select");
        this.dimSelect.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none";
        this.dimSelect.innerHTML = `
            <option value="1D">1D (X)</option>
            <option value="2D">2D (X, Y)</option>
            <option value="3D">3D (X, Y, Z)</option>
        `;
        container.appendChild(this.dimSelect);

        // Inputs Container
        this.inputsContainer = document.createElement("div");
        this.inputsContainer.className = "flex flex-col space-y-2";
        container.appendChild(this.inputsContainer);

        // Checkboxes Container
        const cbContainer = document.createElement("div");
        cbContainer.className = "flex flex-col space-y-2 mt-2 pt-2 border-t border-outline-variant/30";

        const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
        const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;

        // Control Checkbox
        const rowControl = document.createElement("div");
        rowControl.className = "flex items-center space-x-2 cursor-pointer group";
        this.iconControl = document.createElement("div");
        this.iconControl.innerHTML = inactiveSVG;
        const lblControl = document.createElement("span");
        lblControl.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
        lblControl.innerText = "Use Control";
        rowControl.appendChild(this.iconControl);
        rowControl.appendChild(lblControl);
        cbContainer.appendChild(rowControl);

        // Keyframe Checkbox
        const rowKf = document.createElement("div");
        rowKf.className = "flex items-center space-x-2 cursor-pointer group";
        this.iconKf = document.createElement("div");
        this.iconKf.innerHTML = inactiveSVG;
        const lblKf = document.createElement("span");
        lblKf.className = "font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors";
        lblKf.innerText = "Use Keyframe";
        rowKf.appendChild(this.iconKf);
        rowKf.appendChild(lblKf);
        cbContainer.appendChild(rowKf);

        container.appendChild(cbContainer);
        this.bodyEl.insertBefore(container, this.bodyEl.lastElementChild);

        // State
        this.state = { dim: "1D", control: false, kf: false, values: [0, 0, 0] };
        this.inputEls = [];

        // Events
        this.dimSelect.addEventListener("change", (e) => {
            this.state.dim = e.target.value;
            this.renderInputs();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        rowControl.addEventListener("click", () => {
            this.state.control = !this.state.control;
            if (!this.state.control) this.state.kf = false; // Turn off kf if control is off
            this.updateCheckboxes();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        rowKf.addEventListener("click", () => {
            this.state.kf = !this.state.kf;
            if (this.state.kf) this.state.control = true; // Turn on control if kf is on
            this.updateCheckboxes();
            this.renderInputs();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        this.renderInputs();
        this.updateCheckboxes();
    }

    renderInputs() {
        this.inputsContainer.innerHTML = "";
        this.inputEls = [];

        if (this.state.kf) {
            const msg = document.createElement("div");
            msg.className = "w-full bg-green-500/20 border border-green-500/50 rounded py-2 text-center text-green-300 font-body-sm";
            msg.innerText = "Managed by AE Keyframes";
            this.inputsContainer.appendChild(msg);
            
            // Cập nhật type của port output
            this.outputs[0].updateType(this.state.dim);
            this.updatePosition();
            return;
        }

        const count = this.state.dim === "3D" ? 3 : (this.state.dim === "2D" ? 2 : 1);
        const labels = ["X", "Y", "Z"];
        
        for (let i = 0; i < count; i++) {
            const row = document.createElement("div");
            row.className = "flex items-center space-x-2";
            
            const lbl = document.createElement("span");
            lbl.className = "font-label-caps text-label-caps text-on-surface-variant w-4 text-center";
            lbl.innerText = labels[i];

            const input = document.createElement("input");
            input.className = "flex-1 min-w-0 bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
            input.type = "text";
            input.value = this.state.values[i];
            
            UIUtils.makeInputDraggable(input);
            input.addEventListener("change", (e) => {
                this.state.values[i] = parseFloat(e.target.value) || 0;
            });

            row.appendChild(lbl);
            row.appendChild(input);
            this.inputsContainer.appendChild(row);
            this.inputEls.push(input);
        }

        // Cập nhật type của port output
        this.outputs[0].updateType(this.state.dim);
        this.updatePosition();
    }

    updateCheckboxes() {
        const activeSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="2" width="20" height="20" rx="4" fill="#7C4DFF" stroke="#7C4DFF" stroke-width="2"/><path d="M7 12L10.5 15.5L17.5 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
        const inactiveSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" stroke="#595561" stroke-width="2" fill="transparent"/></svg>`;
        
        this.iconControl.innerHTML = this.state.control ? activeSVG : inactiveSVG;
        this.iconKf.innerHTML = this.state.kf ? activeSVG : inactiveSVG;
    }

    getValues() {
        return [
            this.state.dim,
            this.state.control,
            this.state.kf,
            this.state.values[0],
            this.state.values[1],
            this.state.values[2]
        ];
    }

    setValues(values) {
        if (values && values.length >= 6) {
            this.state.dim = values[0];
            this.state.control = values[1];
            this.state.kf = values[2];
            this.state.values[0] = parseFloat(values[3]) || 0;
            this.state.values[1] = parseFloat(values[4]) || 0;
            this.state.values[2] = parseFloat(values[5]) || 0;
            
            this.dimSelect.value = this.state.dim;
            this.renderInputs();
            this.updateCheckboxes();
        }
    }

    // Khi Compile expression
    getControlPayload() {
        if (!this.state.control) return null;
        
        let type = "ADBE Slider Control";
        if (this.state.dim === "2D") type = "ADBE Point Control";
        if (this.state.dim === "3D") type = "ADBE Point3D Control";

        let finalValue = [this.state.values[0]];
        if (this.state.dim === "2D") finalValue = [this.state.values[0], this.state.values[1]];
        if (this.state.dim === "3D") finalValue = [this.state.values[0], this.state.values[1], this.state.values[2]];

        return {
            type: type,
            value: finalValue,
            useKeyframe: this.state.kf
        };
    }
}
