class JSMathNode extends Node {
    constructor() {
        super("JS Math", {
            width: 180,
            headerBgClass: "bg-node-math/20",
            headerBorderClass: "border-node-math/30",
            headerTextClass: "text-node-math"
        });

        const portA = this.addInput("", "1D");
        const portB = this.addInput("", "1D");
        this.addOutput("", "1D");

        portA.el.remove();
        portB.el.remove();

        const container = document.createElement("div");
        container.className = "flex flex-col space-y-2 mb-2 gap-2";

        this.funcSelect = document.createElement("select");
        this.funcSelect.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-on-surface-variant cursor-pointer hover:bg-surface-variant transition-colors focus:outline-none appearance-none";
        
        const funcs1 = ["sin", "cos", "tan", "asin", "acos", "atan", "sqrt", "exp", "log", "abs", "round", "ceil", "floor"];
        const funcs2 = ["pow", "min", "max", "atan2"];
        
        funcs1.forEach(f => {
            const opt = document.createElement("option");
            opt.value = f;
            opt.innerText = `Math.${f}(a)`;
            this.funcSelect.appendChild(opt);
        });
        funcs2.forEach(f => {
            const opt = document.createElement("option");
            opt.value = f;
            opt.innerText = `Math.${f}(a, b)`;
            this.funcSelect.appendChild(opt);
        });
        
        container.appendChild(this.funcSelect);

        // Input A
        this.inputAContainer = document.createElement("div");
        this.inputAContainer.className = "w-full flex items-center relative";
        portA.el.className = "relative flex items-center";
        this.inputAContainer.appendChild(portA.el);
        this.inputA = document.createElement("input");
        this.inputA.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
        this.inputA.type = "text";
        this.inputA.value = "0";
        this.inputAContainer.appendChild(this.inputA);
        container.appendChild(this.inputAContainer);

        // Input B
        this.inputBContainer = document.createElement("div");
        this.inputBContainer.className = "w-full flex items-center relative";
        portB.el.className = "relative flex items-center";
        this.inputBContainer.appendChild(portB.el);
        this.inputB = document.createElement("input");
        this.inputB.className = "w-full bg-surface-dim border border-outline-variant rounded px-2 py-1 font-mono-label text-mono-label text-center text-on-surface focus:border-secondary focus:ring-0";
        this.inputB.type = "text";
        this.inputB.value = "0";
        this.inputBContainer.appendChild(this.inputB);
        container.appendChild(this.inputBContainer);

        this.bodyEl.insertBefore(container, this.bodyEl.lastElementChild);

        UIUtils.makeInputDraggable(this.inputA);
        UIUtils.makeInputDraggable(this.inputB);

        this.funcSelect.addEventListener("change", () => {
            this.updateInputBVisibility();
            if (window.triggerAutoSave) window.triggerAutoSave();
        });

        this.updateInputBVisibility();
    }

    updateInputBVisibility() {
        const funcs2 = ["pow", "min", "max", "atan2"];
        const needsB = funcs2.includes(this.funcSelect.value);
        if (needsB) {
            this.inputBContainer.classList.remove("hidden");
            this.inputs[1].el.style.display = "";
        } else {
            this.inputBContainer.classList.add("hidden");
            this.inputs[1].el.style.display = "none";
        }
        this.updatePosition();
    }

    onConnectionChanged(port) {
        if (port === this.inputs[0]) {
            if (port.wires.length > 0) this.inputA.classList.add("hidden");
            else this.inputA.classList.remove("hidden");
        } else if (port === this.inputs[1]) {
            if (port.wires.length > 0) this.inputB.classList.add("hidden");
            else this.inputB.classList.remove("hidden");
        }
        this.updatePosition();
    }

    getValues() {
        return [this.inputA.value, this.inputB.value, this.funcSelect.value];
    }

    setValues(values) {
        if (values && values.length >= 3) {
            this.inputA.value = values[0];
            this.inputB.value = values[1];
            this.funcSelect.value = values[2];
            this.updateInputBVisibility();
        }
    }
}
