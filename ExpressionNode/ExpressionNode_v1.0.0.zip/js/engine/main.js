/**
 * Main Engine Entry
 * Xử lý khởi tạo, phím tắt
 */

let graph;

window.startExpressionNodeWorkspace = function() {
  if (window.graph) return;
  // 1. Khởi tạo Graph
  graph = new NodeGraph("canvas-container", "canvas-workspace");
  window.graph = graph;
  window.graphSession = new GraphSession(graph);

  // Khởi tạo Shortcuts
  try {
  setupShortcuts();

  // 3. Khởi tạo CSInterface & Sync Logic
  setupCSInterface();
  } catch (error) {
    const label = document.getElementById("current-layer-name");
    if (label) { label.textContent = "Initialization failed"; label.title = error.message; }
    console.error("Expression Node initialization failed:", error);
    throw error;
  }
};

function setupCSInterface() {
  if (!window.__adobe_cep__) return;
  try {
    const csInterface = new CSInterface();
    window.csInterface = csInterface;
    // Reuse the bridge initialized by startup auth. Reloading compiled JSX would
    // reset owner references and can change host-global visibility.
    window.hostBridge = window.hostBridge || new HostBridge(csInterface);
    window.updateCEPKeyInterests();

    // Listen to layer selection changes (unreliable)
    csInterface.addEventListener("application:selectionChanged", () => {
      window.checkLayerSelection(false, true);
    });

    // Reliable fallback triggers
    window.addEventListener("focus", () => window.checkLayerSelection(false, true));
    window.addEventListener("mouseenter", () => window.checkLayerSelection(false, true));
    setInterval(() => window.checkLayerSelection(), 1000);

    // Initial check
    setTimeout(() => {
      window.checkLayerSelection();
    }, 500);

    // 2. Nút Pin Layer
    window.pinnedLayerUID = null;
    const btnPinLayer = document.getElementById("btn-pin-layer");
    if (btnPinLayer) {
      btnPinLayer.addEventListener("click", () => {
        if (window.pinnedLayerUID) {
          // Bỏ ghim
          window.pinnedLayerUID = null;
          btnPinLayer.classList.remove("text-primary", "bg-primary/20");
          btnPinLayer.classList.add("text-on-surface-variant");
          window.checkLayerSelection(true); // Cập nhật lại layer đang chọn
        } else if (
          window.currentLayerUID &&
          window.currentLayerUID !== "NONE" &&
          window.currentLayerUID !== "MULTIPLE"
        ) {
          // Ghim layer hiện tại
          window.pinnedLayerUID = window.currentLayerUID;
          btnPinLayer.classList.remove("text-on-surface-variant");
          btnPinLayer.classList.add("text-primary", "bg-primary/20");
        }
      });
    }



    // Rename Modal Events
    const renameOverlay = document.getElementById("rename-modal-overlay");
    const btnRenameCancel = document.getElementById("btn-rename-cancel");
    const btnRenameSave = document.getElementById("btn-rename-save");
    const renameInput = document.getElementById("rename-input");

    if (renameOverlay) {
      renameOverlay.addEventListener("mousedown", (e) => {
        if (e.target === renameOverlay) hideRenameModal();
      });
    }
    if (btnRenameCancel) btnRenameCancel.addEventListener("click", hideRenameModal);
    if (btnRenameSave) btnRenameSave.addEventListener("click", submitRename);
    if (renameInput) {
      renameInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") submitRename();
        if (e.key === "Escape") hideRenameModal();
      });
    }

    // Manual Sync Button
    const btnManualSync = document.getElementById("btn-manual-sync");
    if (btnManualSync) {
      btnManualSync.addEventListener("click", () => {
        if (!window.graph) return;
        window.checkLayerSelection(true, true);
      });
    }

    // 3. Nút Apply & Auto Apply Toggle
    const btnApply = document.getElementById("btn-apply");
    const btnToggleAutoApply = document.getElementById("btn-toggle-auto-apply");

    window.isAutoApply = true; // Mặc định bật

    if (btnToggleAutoApply) {
      const renderAutoApply = () => {
        btnToggleAutoApply.setAttribute("aria-checked", String(window.isAutoApply));
      };
      renderAutoApply();
      btnToggleAutoApply.addEventListener("click", (event) => {
        event.stopPropagation();
        window.isAutoApply = !window.isAutoApply;
        renderAutoApply();
        if (window.isAutoApply) {
          window.applyExpressionToLayer();
        }
      });
    }

    if (btnApply) {
      btnApply.addEventListener("click", () => {
        window.applyExpressionToLayer();
      });
    }
  } catch (e) {
    console.error("CSInterface setup error:", e);
    const label = document.getElementById("current-layer-name");
    if (label) { label.textContent = "Host connection failed"; label.title = e.message; }
    throw e;
  }
}

function setupShortcuts() {
  // Reuse the single editor graph.
  const graph = window.graph;
  if (typeof ShortcutHelp !== "undefined") ShortcutHelp.init();
  const isTypingTarget = target => !!(target && (target.isContentEditable || (target.closest && target.closest("input, textarea, select"))));
  const isUtilityTarget = target => !!(target && target.closest && target.closest("#panel-actions, #shortcut-help, #shortcut-tooltip, #debug-console"));
  const gate = event => {
    if (isUtilityTarget(event.target) || (event.target.closest && event.target.closest("#debug-console")) || window.canEditGraph() || (event.target.closest && event.target.closest("#btn-manual-sync, #btn-use-node, #btn-pin-layer"))) return;
    event.preventDefault(); event.stopImmediatePropagation();
  };
  for (const name of ["mousedown", "click", "keydown", "paste", "input", "change"]) document.addEventListener(name, gate, true);

  const addNodeMenu = document.getElementById("add-node-menu");
  const searchInput = document.getElementById("search-node-input");

  let mouseX = window.innerWidth / 2;
  let mouseY = window.innerHeight / 2;

  let isDuplicating = false;
  let duplicatedNodes = [];
  window.addEventListener("graph-session-ending", () => { isDuplicating = false; duplicatedNodes = []; });
  window.addEventListener("blur", () => { window.lastATime = 0; });
  window.addEventListener("graph-session-ending", () => { window.lastATime = 0; });
  let dupStartX = 0;
  let dupStartY = 0;

  window.addEventListener("mousemove", (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;

    if (window.canEditGraph() && isDuplicating && duplicatedNodes.length > 0) {
      const worldPos = graph.screenToWorld(mouseX, mouseY);
      const dx = worldPos.x - dupStartX;
      const dy = worldPos.y - dupStartY;
      
      duplicatedNodes.forEach(n => {
        n.x = n.originalX + dx;
        n.y = n.originalY + dy;
        n.updatePosition();
      });
      graph.wires.forEach(w => w.updatePath());
    }
  });

  window.addEventListener("mousedown", (e) => {
    if (isDuplicating) {
      e.stopPropagation();
      e.preventDefault();
      if (e.button === 0) { // Left click confirm
        isDuplicating = false;
        duplicatedNodes.forEach(n => { delete n.originalX; delete n.originalY; });
        duplicatedNodes = [];
        window.triggerAutoSave();
      } else if (e.button === 2) { // Right click cancel
        isDuplicating = false;
        duplicatedNodes.forEach(n => {
          n.x = n.originalX;
          n.y = n.originalY;
          n.updatePosition();
          delete n.originalX; delete n.originalY;
        });
        graph.wires.forEach(w => w.updatePath());
        duplicatedNodes = [];
        window.triggerAutoSave();
      }
    }
  }, true);

  // --- Node Menu Rendering & Search ---
  const menuList = document.getElementById("node-menu-list");

  function renderNodeMenu(searchQuery = "") {
    if (!menuList || !window.NODE_REGISTRY) return;
    menuList.innerHTML = "";

    const query = searchQuery.toLowerCase().trim();
    let html = "";

    if (query === "") {
      // Hiển thị theo Group
      const groups = {};
      window.NODE_REGISTRY.forEach((node) => {
        if (!groups[node.group]) groups[node.group] = [];
        groups[node.group].push(node);
      });
      for (const [groupName, nodes] of Object.entries(groups)) {
        if (groupName === "Root" || groupName === "") {
            nodes.forEach(node => {
                html += `
                <button id="btn-add-${node.id.toLowerCase()}" class="w-full text-left px-2 py-1.5 rounded hover:bg-surface-variant flex items-center space-x-2 transition-colors" data-node-type="${node.id}" onclick="createNode('${node.id}')">
                    <span class="material-symbols-outlined text-[16px] text-primary">${node.icon}</span>
                    <span class="font-mono-label text-mono-label text-on-surface">${node.name}</span>
                </button>
                `;
            });
        } else {
            let groupHtml = `
            <div class="relative group">
                <button class="w-full text-left px-2 py-1.5 rounded hover:bg-surface-variant flex items-center space-x-2 transition-colors">
                    <span class="material-symbols-outlined text-[16px] text-node-math">folder</span>
                    <span class="font-mono-label text-mono-label text-on-surface">${groupName}</span>
                    <span class="material-symbols-outlined text-[16px] text-on-surface-variant/50 ml-auto">chevron_right</span>
                </button>
                <!-- Sub-menu -->
                <div class="absolute left-full top-1/2 -translate-y-1/2 ml-1 hidden group-hover:block w-48 bg-surface border border-outline rounded-lg shadow-lg py-2 z-50">
            `;
            
            nodes.forEach(node => {
                groupHtml += `
                <div class="px-3 py-1.5 flex items-center space-x-2 text-on-surface-variant hover:bg-surface-bright cursor-pointer transition-colors" data-node-type="${node.id}" onclick="createNode('${node.id}')">
                    <span class="material-symbols-outlined text-[16px]">${node.icon}</span>
                    <span class="font-body-md text-body-md">${node.name}</span>
                    ${node.shortcut ? `<span class="ml-auto text-label-caps text-on-surface-variant/50">${node.shortcut}</span>` : ''}
                </div>
                `;
            });

            groupHtml += `</div></div>`;
            html += groupHtml;
        }
      }
    } else {
      // Tìm kiếm dạng Flat list
      const matchedNodes = window.NODE_REGISTRY.filter(
        (node) =>
          node.name.toLowerCase().includes(query) ||
          node.group.toLowerCase().includes(query),
      );
      if (matchedNodes.length === 0) {
        html = `<div class="px-2 py-1.5 text-on-surface-variant text-center font-body-sm text-body-sm">No matches</div>`;
      } else {
        matchedNodes.forEach((node, index) => {
          html += `
                    <div class="search-result-item px-2 py-1.5 rounded flex items-center space-x-2 text-on-surface hover:bg-surface-variant cursor-pointer transition-colors" data-node-type="${node.id}" onclick="createNode('${node.id}')">
                        <span class="material-symbols-outlined text-[16px] text-primary">${node.icon}</span>
                        <div class="flex flex-col">
                            <span class="font-mono-label text-mono-label">${node.name}</span>
                            <span class="text-[10px] text-on-surface-variant">${node.group}</span>
                        </div>
                        ${node.shortcut ? `<span class="ml-auto text-label-caps text-on-surface-variant/50">${node.shortcut}</span>` : ""}
                    </div>
                    `;
        });
      }
    }

    if (query === "") {
      menuList.classList.remove("overflow-y-auto");
      menuList.classList.add("overflow-visible");
    } else {
      menuList.classList.remove("overflow-visible");
      menuList.classList.add("overflow-y-auto");
    }

    menuList.innerHTML = html;
    currentSearchIndex = -1;
    applyNodeAvailability();
  }

  let currentSearchIndex = -1;
  let menuFocusTimer = null;
  let menuOpenVersion = 0;

  function applyNodeAvailability() {
    const hasTarget = graph.nodes.some(node => node.constructor.name === "TargetLayerNode");
    menuList.querySelectorAll('[data-node-type="TargetLayerNode"]').forEach(item => {
      item.classList.toggle("opacity-50", hasTarget);
      item.classList.toggle("pointer-events-none", hasTarget);
      item.setAttribute("aria-disabled", String(hasTarget));
      if (item.tagName === "BUTTON") item.disabled = hasTarget;
    });
  }

  function resetNodeMenu() {
    if (searchInput) searchInput.value = "";
    renderNodeMenu("");
    if (menuList) menuList.scrollTop = 0;
  }

  function closeNodeMenu() {
    menuOpenVersion++;
    clearTimeout(menuFocusTimer);
    if (searchInput && document.activeElement === searchInput) searchInput.blur();
    if (addNodeMenu) addNodeMenu.classList.add("hidden");
    resetNodeMenu();
  }
  window.addNodeMenuController = {hide: closeNodeMenu};

  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      renderNodeMenu(e.target.value);
    });

    searchInput.addEventListener("keydown", (e) => {
      const items = menuList.querySelectorAll('.search-result-item:not([aria-disabled="true"])');
      if (items.length === 0) return;

      if (e.key === "ArrowDown") {
        e.preventDefault();
        if (currentSearchIndex < items.length - 1) currentSearchIndex++;
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        if (currentSearchIndex > 0) currentSearchIndex--;
      } else if (e.key === "Enter") {
        e.preventDefault();
        if (currentSearchIndex >= 0 && currentSearchIndex < items.length) {
          items[currentSearchIndex].click();
        } else if (items.length > 0) {
          // Mặc định chọn item đầu tiên nếu chưa cuộn
          items[0].click();
        }
        return;
      } else {
        return; // Không phải phím điều hướng thì bỏ qua
      }

      // Xóa class highlight cũ
      items.forEach(item => item.classList.remove("bg-surface-variant", "ring-1", "ring-primary"));
      
      // Highlight item mới
      if (currentSearchIndex >= 0) {
        const activeItem = items[currentSearchIndex];
        activeItem.classList.add("bg-surface-variant", "ring-1", "ring-primary");
        activeItem.scrollIntoView({ block: "nearest" });
      }
    });
  }

  // Khởi tạo menu ban đầu
  renderNodeMenu();
  // ------------------------------------

  window.addEventListener("keydown", (e) => {
    if (e.key === "F5") {
      e.preventDefault();
      window.location.reload();
      return;
    }

    if (isTypingTarget(e.target) || isUtilityTarget(e.target)) return;

    // Xóa Node (Delete hoặc X)
    if (e.key === "Delete" || e.key === "x" || e.key === "X") {
      // Chỉ bắt khi không gõ chữ trong input
      if (!isTypingTarget(e.target)) {
        graph.deleteSelected();
      }
    }

    // Select All (A) hoặc Deselect All (Double tap A)
    if ((e.code === "KeyA" || e.key === "a" || e.key === "A") && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) {
      if (e.target.tagName !== "INPUT") {
        e.preventDefault();
        e.stopImmediatePropagation();
        if (e.repeat) return;
        const now = Date.now();
        if (window.lastATime && now - window.lastATime < 300) {
          // Double tap A -> Deselect
          graph.deselectAll();
          window.lastATime = 0;
        } else {
          // Single tap -> Select
          graph.selectAll();
          window.lastATime = now;
        }
      }
    }

    // Undo (Ctrl+Z)
    if (e.ctrlKey && (e.key === "z" || e.key === "Z")) {
      if (e.target.tagName !== "INPUT") {
        e.preventDefault();
        graph.undo();
      }
    }

    // Copy (Ctrl+C)
    if (e.ctrlKey && (e.key === "c" || e.key === "C")) {
      if (e.target.tagName !== "INPUT") {
        const jsonStr = graph.serializeSelection();
        if (jsonStr) {
          console.log("Copying to clipboard...");
          const textarea = document.createElement("textarea");
          textarea.value = jsonStr;
          textarea.style.position = "fixed";
          textarea.style.opacity = "0";
          document.body.appendChild(textarea);
          textarea.focus();
          textarea.select();
          try {
            const successful = document.execCommand('copy');
            if (successful) {
              console.log("Copy success (execCommand)");
            } else {
              console.error("Copy failed (execCommand returned false)");
            }
          } catch(err) {
            console.error("Copy error: " + err.message);
          }
          document.body.removeChild(textarea);
        } else {
          console.log("No nodes selected to copy.");
        }
      }
    }

    // Paste is now handled by the 'paste' event listener below

  });

  window.addEventListener("keyup", e => {
    if (isTypingTarget(e.target) || isUtilityTarget(e.target) || !window.canEditGraph()) return;
    if ((e.code === "KeyA" || e.key === "a" || e.key === "A") && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  });

  document.addEventListener("paste", (e) => {
    if (e.target.tagName !== "INPUT") {
      const text = e.clipboardData ? e.clipboardData.getData("text") : "";
      console.log("Paste event triggered, data length: ", text.length);
      handlePaste(text);
    }
  });

  function handlePaste(text) {
    if (text && text.includes("isSelection")) {
      const worldPos = graph.screenToWorld(mouseX, mouseY);
      const newNodes = graph.deserializeSelection(text, worldPos.x, worldPos.y);
      if (newNodes && newNodes.length > 0) {
        window.triggerAutoSave();
        console.log("Nodes successfully pasted!");
      }
    }
  }

  // Duplicate (Shift+D)
  window.addEventListener("keydown", (e) => {
    if (isUtilityTarget(e.target)) return;
    if (e.key === "Escape") { hideAddNodeMenu(); return; }
    if (isTypingTarget(e.target)) return;
    if (e.shiftKey && (e.key === "d" || e.key === "D")) {
      if (e.target.tagName !== "INPUT") {
        e.preventDefault();
        if (!isDuplicating) {
          const jsonStr = graph.serializeSelection();
          if (jsonStr) {
            const worldPos = graph.screenToWorld(mouseX, mouseY);
            const newNodes = graph.deserializeSelection(jsonStr, worldPos.x, worldPos.y);
            if (newNodes && newNodes.length > 0) {
              isDuplicating = true;
              duplicatedNodes = newNodes;
              dupStartX = worldPos.x;
              dupStartY = worldPos.y;
              newNodes.forEach(n => {
                n.originalX = n.x;
                n.originalY = n.y;
              });
            }
          }
        }
      }
    }

    // Rename Node (F2)
    if (e.key === "F2") {
      if (e.target.tagName !== "INPUT") {
        e.preventDefault();
        if (graph.selectedNodes.size === 1) {
          const selectedNode = Array.from(graph.selectedNodes)[0];
          showRenameModal(selectedNode);
        }
      }
    }

    // Manual Sync Shortcut (R)
    if (e.key === "r" || e.key === "R") {
      if (e.target.tagName !== "INPUT") {
        e.preventDefault();
        const btnManualSync = document.getElementById("btn-manual-sync");
        if (btnManualSync) btnManualSync.click();
      }
    }

    // Shift + A để mở bảng Menu
    if (e.shiftKey && (e.key === "a" || e.key === "A")) {
      e.preventDefault();
      showAddNodeMenu();
    }

    if (e.key === "Escape") {
      hideAddNodeMenu();
    }
  });

  document.addEventListener(
    "mousedown",
    (e) => {
      if (!addNodeMenu.classList.contains("hidden")) {
        if (!addNodeMenu.contains(e.target)) {
          hideAddNodeMenu();
        }
      }
    },
    true,
  );

  // Bắt sự kiện click vào các danh mục node trong menu
  const btnSource = document.getElementById("btn-add-source");
  if (btnSource) {
    btnSource.addEventListener("click", () => {
      const node = new SourceLayerNode();
      const worldPos = graph.screenToWorld(mouseX, mouseY);
      node.x = worldPos.x;
      node.y = worldPos.y;
      graph.addNode(node);
      window.triggerAutoSave();
      hideAddNodeMenu();
    });
  }

    window.instantiateNode = function(type) {
      let node;
      if (type === "SimpleMathNode") node = new SimpleMathNode();
      else if (type === "ValueNode") node = new ValueNode();
      else if (type === "ThisLayerValueNode") node = new ThisLayerValueNode();
      else if (type === "TimeNode") node = new TimeNode();
      else if (type === "SpeedVelocityNode") node = new SpeedVelocityNode();
      else if (type === "SourceRectAtTimeNode") node = new SourceRectAtTimeNode();
      else if (type === "AngleNode") node = new AngleNode();
      else if (type === "CheckboxNode") node = new CheckboxNode();
      else if (type === "ColorNode") node = new ColorNode();
      else if (type === "JSMathNode") node = new JSMathNode();
      else if (type === "JSConstantNode") node = new JSConstantNode();
      else if (type === "AngleConversionNode") node = new AngleConversionNode();
      else if (type === "ToStringNode") node = new ToStringNode();
      else if (type === "ColorConversionNode") node = new ColorConversionNode();
      else if (type === "CombineVectorNode") node = new CombineVectorNode();
      else if (type === "SplitVectorNode") node = new SplitVectorNode();
      else if (type === "InterpolationNode") node = new InterpolationNode();
      else if (type === "WigglerNode") node = new WigglerNode();
      else if (type === "RandomNode") node = new RandomNode();
      else if (type === "NoiseNode") node = new NoiseNode();
      else if (type === "SourceLayerNode") node = new SourceLayerNode();
      else if (type === "TargetLayerNode") node = new TargetLayerNode();
      return node;
    };

    window.createNode = function (type) {
      if (!window.canEditGraph()) return;
      if (type === "TargetLayerNode" && graph.nodes.some(node => node.constructor.name === type)) return;
      const node = window.instantiateNode(type);
      if (node) {
        const worldPos = graph.screenToWorld(mouseX, mouseY);
        node.x = worldPos.x;
        node.y = worldPos.y;
        graph.addNode(node);
        window.triggerAutoSave();
        hideAddNodeMenu();
      }
    };

    const btnValue = document.getElementById("btn-add-value");
  if (btnValue) {
    btnValue.addEventListener("click", () => {
      const node = new ValueNode();
      const worldPos = graph.screenToWorld(mouseX, mouseY);
      node.x = worldPos.x;
      node.y = worldPos.y;
      graph.addNode(node);
      window.triggerAutoSave();
      hideAddNodeMenu();
    });
  }

  const btnTarget = document.getElementById("btn-add-target");
  if (btnTarget) {
    btnTarget.addEventListener("click", () => {
      const hasTarget = window.graph.nodes.find(
        (n) => n.constructor.name === "TargetLayerNode",
      );
      if (hasTarget) return;

      const node = new TargetLayerNode();
      const worldPos = graph.screenToWorld(mouseX, mouseY);
      node.x = worldPos.x;
      node.y = worldPos.y;
      graph.addNode(node);
      window.triggerAutoSave();
      hideAddNodeMenu();
    });
  }

  function showAddNodeMenu() {
    if (!addNodeMenu) return;

    if (!window.canEditGraph()) return;
    if (typeof ShortcutHelp !== "undefined") ShortcutHelp.hide(false);
    resetNodeMenu();
    clearTimeout(menuFocusTimer);
    const openVersion = ++menuOpenVersion;
    const generation = window.graphSession ? window.graphSession.generation : 0;

    // Hiện menu tại vị trí con trỏ chuột
    addNodeMenu.style.left = `${mouseX}px`;
    addNodeMenu.style.top = `${mouseY}px`;

    // Chia 4 vùng 2x2 để chọn hướng bung menu
    const halfWidth = window.innerWidth / 2;
    const halfHeight = window.innerHeight / 2;

    let tx = "0";
    let ty = "0";

    if (mouseX >= halfWidth) tx = "-100%";
    if (mouseY >= halfHeight) ty = "-100%";

    addNodeMenu.style.transform = `translate(${tx}, ${ty})`;

    addNodeMenu.classList.remove("hidden");
    menuFocusTimer = setTimeout(() => {
      if (openVersion !== menuOpenVersion || addNodeMenu.classList.contains("hidden") || !window.canEditGraph()) return;
      if (window.graphSession && generation !== window.graphSession.generation) return;
      if (searchInput) searchInput.focus();
    }, 50);
  }
}

function hideAddNodeMenu() {
  if (window.addNodeMenuController) { window.addNodeMenuController.hide(); return; }
  const addNodeMenu = document.getElementById("add-node-menu");
  const searchInput = document.getElementById("search-node-input");
  if (addNodeMenu) {
    addNodeMenu.classList.add("hidden");
    if (searchInput) searchInput.value = "";
  }
}

// ================= RENAME MODAL LOGIC =================
let renameTargetNode = null;

function showRenameModal(node) {
  renameTargetNode = node;
  const overlay = document.getElementById("rename-modal-overlay");
  const modal = document.getElementById("rename-modal");
  const input = document.getElementById("rename-input");
  
  if (overlay && modal && input) {
    const currentName = node.customName || node.title;
    input.value = currentName;
    
    overlay.classList.remove("hidden");
    // Trigger transition
    setTimeout(() => {
      modal.classList.remove("scale-95", "opacity-0");
      modal.classList.add("scale-100", "opacity-100");
      input.focus();
      input.select();
    }, 10);
  }
}

function hideRenameModal() {
  const overlay = document.getElementById("rename-modal-overlay");
  const modal = document.getElementById("rename-modal");
  
  if (overlay && modal) {
    modal.classList.remove("scale-100", "opacity-100");
    modal.classList.add("scale-95", "opacity-0");
    setTimeout(() => {
      overlay.classList.add("hidden");
      renameTargetNode = null;
    }, 150); // wait for transition
  }
}

function submitRename() {
  const input = document.getElementById("rename-input");
  if (renameTargetNode && input) {
    const newName = input.value.trim();
    if (newName) {
      renameTargetNode.customName = newName;
    } else {
      renameTargetNode.customName = ""; // reset to default
    }
    if (typeof renameTargetNode.updateTitle === "function") renameTargetNode.updateTitle();
    if (window.triggerAutoSave) window.triggerAutoSave();
    hideRenameModal();
  }
}

// All persistence requests are bound to the graph owner.
// CEP must reserve keys before the host processes them; DOM prevention alone is insufficient.
window.updateCEPKeyInterests = (modalKeys = false) => {
  if (!window.csInterface || typeof window.csInterface.registerKeyEventsInterest !== "function") return;
  const isMac = typeof navigator !== "undefined" && /Mac/i.test(navigator.platform || "");
  const keys = [{ keyCode: isMac ? 0 : 65, ctrlKey: false, altKey: false, shiftKey: false, metaKey: false }];
  if (modalKeys) keys.push({ keyCode: isMac ? 36 : 13 }, { keyCode: isMac ? 53 : 27 });
  try {
    window.csInterface.registerKeyEventsInterest(JSON.stringify(keys));
  } catch (error) {
    console.error("CEP shortcut registration failed:", error.message);
  }
};
window.triggerAutoSave = history => window.graphSession && window.graphSession.markDirty(history);
window.saveToLayer = () => {
  if (window.graphSession && window.graphSession.canEdit()) window.graphSession.flush(window.isAutoApply, true);
};
window.applyExpressionToLayer = () => {
  if (window.graphSession && window.graphSession.canEdit()) window.graphSession.flush(true, true);
};
window.currentLayerUID = null;
window.checkLayerSelection = (force = false, urgent = false) => {
  if (window.graphSession) window.graphSession.check(force, urgent);
};
