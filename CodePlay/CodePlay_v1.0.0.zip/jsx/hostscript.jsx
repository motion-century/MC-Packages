//@include "motion-security.jsx"

var isAuthorized = false;

function setAuthorized(status) {
    if (status === true || status === "true" || status === 1) {
        isAuthorized = true;
        return "AUTHORIZED";
    } else {
        isAuthorized = false;
        return "UNAUTHORIZED";
    }
}

function generateNonce() {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

function verifyHost() {
    try {
        var ms = new MotionSecurity({ pluginId: "codeplay" });
        var nonce = generateNonce();
        var result = ms.verifyKey("dummy-key", nonce);
        if (result && result.status === 'active') {
            isAuthorized = true;
        }
    } catch(e) {
        isAuthorized = false;
    }
}

try {
    var plugplug = new ExternalObject("lib:PlugPlugExternalObject");
} catch(e) {}

// Console polyfill for ExtendScript
var console = {
    log: function(msg) {
        if (typeof CSXSEvent !== "undefined") {
            var eventObj = new CSXSEvent();
            eventObj.type = "codeplay.console.log";
            eventObj.data = (typeof msg === 'object') ? JSON.stringify(msg) : String(msg);
            eventObj.dispatch();
        }
    },
    error: function(msg) {
        if (typeof CSXSEvent !== "undefined") {
            var eventObj = new CSXSEvent();
            eventObj.type = "codeplay.console.error";
            eventObj.data = (typeof msg === 'object') ? JSON.stringify(msg) : String(msg);
            eventObj.dispatch();
        }
    }
};

function executeUserCode(codeStr) {
    if (!isAuthorized) {
        verifyHost();
    }
    if (!isAuthorized) {
        return "Error: Unlicensed version. Please verify license via Motion Century Manager.";
    }

    try {
        // Execute user script
        var result = eval(codeStr);
        if (result !== undefined) {
            return String(result);
        }
        return "undefined";
    } catch(e) {
        // Dispatch error event to CEP UI console
        if (typeof CSXSEvent !== "undefined") {
            var eventObj = new CSXSEvent();
            eventObj.type = "codeplay.console.error";
            eventObj.data = "Line " + e.line + ": " + e.message;
            eventObj.dispatch();
        }
        return "undefined";
    }
}
