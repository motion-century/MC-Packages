class UIUtils {
    static makeInputDraggable(inputEl) {
        let isDragging = false;
        let startX = 0;
        let startValue = 0;

        inputEl.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.clientX;
            startValue = parseFloat(inputEl.value) || 0;
            document.body.style.cursor = 'ew-resize';
            // Stop propagation to prevent Node dragging
            e.stopPropagation();
            // Không được preventDefault ở đây để user có thể click vào focus nếu họ ko kéo
        });

        const onMouseMove = (e) => {
            if (!isDragging || !inputEl.isConnected || (window.canEditGraph && !window.canEditGraph())) return;
            
            const deltaX = e.clientX - startX;
            let step = 1;
            if (e.shiftKey) step = 10;
            if (e.ctrlKey) step = 0.1;

            // Tính giá trị mới, làm tròn để tránh lỗi float của JS
            let newValue = startValue + deltaX * step;
            if (e.ctrlKey) {
                newValue = Math.round(newValue * 10) / 10; // Giữ 1 chữ số thập phân
            } else {
                newValue = Math.round(newValue);
            }

            // Chỉ cập nhật nếu có sự thay đổi thực sự
            if (newValue !== parseFloat(inputEl.value)) {
                inputEl.value = newValue;
                // Kích hoạt event change
                const event = new Event('change', { bubbles: true });
                inputEl.dispatchEvent(event);
            }
        };

        const onMouseUp = () => {
            if (isDragging) {
                isDragging = false;
                document.body.style.cursor = 'default';
            }
        };

        window.addEventListener('graph-session-ending', onMouseUp);
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
        inputEl.disposeDrag = () => {
            onMouseUp();
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
            window.removeEventListener('graph-session-ending', onMouseUp);
        };

        // Hỗ trợ phím lên xuống
        inputEl.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
                e.preventDefault(); // Ngăn hành vi cuộn trang
                let step = 1;
                if (e.shiftKey) step = 10;
                if (e.ctrlKey) step = 0.1;

                let currentValue = parseFloat(inputEl.value) || 0;
                let newValue = currentValue;

                if (e.key === 'ArrowUp') {
                    newValue += step;
                } else if (e.key === 'ArrowDown') {
                    newValue -= step;
                }

                if (e.ctrlKey) {
                    newValue = Math.round(newValue * 10) / 10;
                } else {
                    newValue = Math.round(newValue);
                }

                inputEl.value = newValue;
                const event = new Event('change', { bubbles: true });
                inputEl.dispatchEvent(event);
            }
        });
    }
}
